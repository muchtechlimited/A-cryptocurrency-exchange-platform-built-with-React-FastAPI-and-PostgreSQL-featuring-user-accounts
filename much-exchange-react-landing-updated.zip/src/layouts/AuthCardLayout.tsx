import type { ReactNode } from 'react';
import Logo from '../components/Logo';
import ThemeToggle from '../components/ThemeToggle';

export default function AuthCardLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-zinc-50 p-4 dark:bg-[#08090B]">
      <div className="fixed right-4 top-4 z-10 sm:right-6 sm:top-6">
        <ThemeToggle />
      </div>
      <div className="w-full max-w-[400px] rounded-3xl border border-zinc-200 bg-white p-8 shadow-2xl shadow-zinc-900/5 dark:border-white/10 dark:bg-[#101113] dark:shadow-black/40">
        <div className="mb-7 flex justify-center">
          <Logo size={40} />
        </div>
        {children}
      </div>
    </div>
  );
}
