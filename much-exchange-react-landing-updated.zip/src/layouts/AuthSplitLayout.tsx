import type { ReactNode } from 'react';
import ThemeToggle from '../components/ThemeToggle';

export default function AuthSplitLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-zinc-50 p-4 dark:bg-[#08090B] sm:p-8">
      <div className="fixed right-4 top-4 z-10 sm:right-6 sm:top-6">
        <ThemeToggle />
      </div>
      <div className="grid w-full max-w-[820px] overflow-hidden rounded-3xl border border-zinc-200 shadow-2xl shadow-zinc-900/5 dark:border-white/10 dark:shadow-black/40 sm:grid-cols-2">
        <div className="relative hidden flex-col items-center justify-center bg-[#0B0C0E] p-10 sm:flex">
          <div
            className="absolute inset-0 opacity-40"
            style={{
              backgroundImage:
                'radial-gradient(circle at 50% 35%, rgba(245,181,22,.18), transparent 60%)',
            }}
          />
          <svg width="120" height="120" viewBox="0 0 40 40" fill="none" className="relative">
            <circle cx="20" cy="20" r="19" fill="url(#split-gradient)" stroke="#B37E08" strokeWidth="0.4" />
            <path d="M11 27V13.5L20 22L29 13.5V27" stroke="#0B0C0E" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" fill="none" />
            <defs>
              <linearGradient id="split-gradient" x1="1" y1="1" x2="39" y2="39" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#FBD46B" />
                <stop offset="1" stopColor="#DE9E0A" />
              </linearGradient>
            </defs>
          </svg>
          <span className="relative mt-6 font-display text-lg font-bold tracking-tight text-white">MUCH</span>
          <span className="relative text-[10px] font-medium tracking-[0.3em] text-zinc-400">EXCHANGE</span>
        </div>
        <div className="bg-white px-7 py-10 dark:bg-[#101113] sm:px-10">{children}</div>
      </div>
    </div>
  );
}
