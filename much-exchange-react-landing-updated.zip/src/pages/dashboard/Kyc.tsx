import { useEffect, useState, type ChangeEvent } from 'react';
import { UploadCloud, X, Loader2, CheckCircle2, Clock, AlertTriangle } from 'lucide-react';
import DashboardLayout from '../../components/dashboard/DashboardLayout';
import Card from '../../components/ui/Card';
import Field from '../../components/ui/Field';
import Button from '../../components/ui/Button';
import {
  getMyKycSubmissions,
  submitKyc,
  type KYCSubmissionApi,
} from '../../lib/kycApi';
import { ApiError } from '../../lib/api';

type Step = 'details' | 'documents' | 'review';

const ID_TYPES: { label: string; value: string }[] = [
  { label: 'International Passport', value: 'passport' },
  { label: "Driver's License", value: 'drivers_license' },
  { label: 'National ID Card', value: 'national_id' },
  { label: "Voter's Card", value: 'voters_card' },
];

function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  } catch {
    return iso;
  }
}

export default function Kyc() {
  const [loadingStatus, setLoadingStatus] = useState(true);
  const [statusError, setStatusError] = useState('');
  const [latest, setLatest] = useState<KYCSubmissionApi | null>(null);

  useEffect(() => {
    getMyKycSubmissions()
      .then((subs) => setLatest(subs[0] ?? null))
      .catch((err) => setStatusError(err instanceof ApiError ? err.message : 'Failed to load KYC status.'))
      .finally(() => setLoadingStatus(false));
  }, []);

  if (loadingStatus) {
    return (
      <DashboardLayout title="KYC Verification" subtitle="Verify your identity to secure your account.">
        <div className="mx-auto flex max-w-xl items-center justify-center gap-2 py-16 text-[13px] text-zinc-400 dark:text-zinc-500">
          <Loader2 size={16} className="animate-spin" /> Checking your verification status…
        </div>
      </DashboardLayout>
    );
  }

  if (statusError) {
    return (
      <DashboardLayout title="KYC Verification" subtitle="Verify your identity to secure your account.">
        <div className="mx-auto max-w-xl rounded-xl border border-down-500/30 bg-down-500/5 px-4 py-3 text-[13px] text-down-600 dark:text-down-400">
          {statusError}
        </div>
      </DashboardLayout>
    );
  }

  // Approved, or a fresh review still pending — nothing more for the user to do.
  if (latest && (latest.status === 'approved' || latest.status === 'pending')) {
    return (
      <DashboardLayout title="KYC Verification" subtitle="Verify your identity to secure your account.">
        <div className="mx-auto max-w-xl">
          <Card className="flex flex-col items-center py-10 text-center">
            {latest.status === 'approved' ? (
              <>
                <CheckCircle2 size={40} className="mb-3 text-up-500" />
                <h3 className="text-[15px] font-semibold text-zinc-900 dark:text-white">You're verified</h3>
                <p className="mt-1.5 max-w-xs text-[13px] text-zinc-500 dark:text-zinc-400">
                  Your identity was verified on {latest.reviewed_at ? formatDate(latest.reviewed_at) : 'a previous review'}.
                  You have full access to trading.
                </p>
              </>
            ) : (
              <>
                <Clock size={40} className="mb-3 text-brand-500" />
                <h3 className="text-[15px] font-semibold text-zinc-900 dark:text-white">Submission under review</h3>
                <p className="mt-1.5 max-w-xs text-[13px] text-zinc-500 dark:text-zinc-400">
                  You submitted your documents on {formatDate(latest.created_at)}. Reviews are typically completed
                  within 24 hours — we'll notify you as soon as it's done.
                </p>
              </>
            )}
          </Card>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <KycForm
      priorRejection={latest && latest.status === 'rejected' ? latest : null}
      onSubmitted={(sub) => setLatest(sub)}
    />
  );
}

function KycForm({
  priorRejection,
  onSubmitted,
}: {
  priorRejection: KYCSubmissionApi | null;
  onSubmitted: (sub: KYCSubmissionApi) => void;
}) {
  const [step, setStep] = useState<Step>('details');
  const [idType, setIdType] = useState(ID_TYPES[0].value);
  const [documentNumber, setDocumentNumber] = useState('');

  const [front, setFront] = useState<File | null>(null);
  const [back, setBack] = useState<File | null>(null);
  const [selfie, setSelfie] = useState<File | null>(null);

  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');

  const steps: { key: Step; label: string }[] = [
    { key: 'details', label: 'ID Details' },
    { key: 'documents', label: 'Upload Documents' },
    { key: 'review', label: 'Review' },
  ];
  const activeIndex = steps.findIndex((s) => s.key === step);
  const idTypeLabel = ID_TYPES.find((t) => t.value === idType)?.label ?? idType;

  async function handleSubmit() {
    if (!front) {
      setSubmitError('An ID document (front) is required.');
      setStep('documents');
      return;
    }
    setSubmitting(true);
    setSubmitError('');
    try {
      const sub = await submitKyc({
        document_type: idType,
        document_number: documentNumber.trim(),
        document_front: front,
        document_back: back,
        selfie,
      });
      onSubmitted(sub);
    } catch (err) {
      setSubmitError(err instanceof ApiError ? err.message : 'Submission failed. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <DashboardLayout title="KYC Verification" subtitle="Verify your identity to secure your account.">
      <div className="mx-auto max-w-xl">
        {priorRejection && (
          <div className="mb-4 flex items-start gap-2.5 rounded-xl border border-down-500/30 bg-down-500/5 px-4 py-3 text-[13px] text-down-600 dark:text-down-400">
            <AlertTriangle size={16} className="mt-0.5 shrink-0" />
            <div>
              <p className="font-semibold">Your previous submission was rejected</p>
              <p className="mt-0.5 text-[12.5px] opacity-90">
                {priorRejection.rejection_reason || 'No reason was given.'} You can submit again below.
              </p>
            </div>
          </div>
        )}

        <Card>
          <div className="mb-6 flex items-center">
            {steps.map((s, i) => (
              <div key={s.key} className="flex flex-1 items-center last:flex-none">
                <div className="flex flex-col items-center gap-1.5">
                  <div
                    className={`flex h-7 w-7 items-center justify-center rounded-full text-[11px] font-bold ${
                      i <= activeIndex
                        ? 'bg-gradient-to-b from-brand-400 to-brand-500 text-zinc-900'
                        : 'bg-zinc-100 text-zinc-400 dark:bg-white/[0.06] dark:text-zinc-500'
                    }`}
                  >
                    {i + 1}
                  </div>
                  <span
                    className={`whitespace-nowrap text-[11px] font-medium ${
                      i <= activeIndex ? 'text-zinc-800 dark:text-zinc-100' : 'text-zinc-400 dark:text-zinc-500'
                    }`}
                  >
                    {s.label}
                  </span>
                </div>
                {i < steps.length - 1 && (
                  <div className={`mx-2 h-[2px] flex-1 ${i < activeIndex ? 'bg-brand-500' : 'bg-zinc-200 dark:bg-white/10'}`} />
                )}
              </div>
            ))}
          </div>

          {step === 'details' && (
            <>
              <label className="mb-1.5 block text-[13px] font-medium text-zinc-700 dark:text-zinc-300">ID Type</label>
              <select
                value={idType}
                onChange={(e) => setIdType(e.target.value)}
                className="mb-4 h-[42px] w-full rounded-lg border border-zinc-200 bg-zinc-50 px-3.5 text-[13.5px] text-zinc-900 outline-none focus:border-brand-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-white"
              >
                {ID_TYPES.map((t) => (
                  <option key={t.value} value={t.value}>{t.label}</option>
                ))}
              </select>
              <Field
                id="documentNumber"
                label="Document Number"
                value={documentNumber}
                onChange={(e) => setDocumentNumber(e.target.value)}
                placeholder="As shown on your document"
              />
              <Button
                fullWidth
                size="lg"
                disabled={!documentNumber.trim()}
                onClick={() => setStep('documents')}
              >
                Continue
              </Button>
            </>
          )}

          {step === 'documents' && (
            <>
              <UploadBox
                label={`Upload ${idTypeLabel} — Front`}
                required
                file={front}
                onChange={setFront}
              />
              <UploadBox
                label={`Upload ${idTypeLabel} — Back (optional)`}
                file={back}
                onChange={setBack}
              />
              <UploadBox
                label="Upload a Selfie (optional, speeds up review)"
                file={selfie}
                onChange={setSelfie}
              />

              {submitError && (
                <p className="mb-3 text-[12.5px] text-down-500">{submitError}</p>
              )}

              <div className="flex gap-3">
                <Button variant="secondary" fullWidth size="lg" onClick={() => setStep('details')}>Back</Button>
                <Button fullWidth size="lg" disabled={!front} onClick={() => { setSubmitError(''); setStep('review'); }}>
                  Continue
                </Button>
              </div>
            </>
          )}

          {step === 'review' && (
            <>
              <div className="mb-5 space-y-2 rounded-xl border border-zinc-200 p-4 text-[12.5px] dark:border-white/[0.08]">
                <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
                  <span>ID Type</span><span className="font-medium text-zinc-800 dark:text-zinc-100">{idTypeLabel}</span>
                </div>
                <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
                  <span>Document Number</span><span className="font-medium text-zinc-800 dark:text-zinc-100">{documentNumber}</span>
                </div>
                <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
                  <span>Front</span><span className="font-medium text-zinc-800 dark:text-zinc-100">{front?.name ?? '—'}</span>
                </div>
                <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
                  <span>Back</span><span className="font-medium text-zinc-800 dark:text-zinc-100">{back?.name ?? 'Not provided'}</span>
                </div>
                <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
                  <span>Selfie</span><span className="font-medium text-zinc-800 dark:text-zinc-100">{selfie?.name ?? 'Not provided'}</span>
                </div>
              </div>
              <p className="mb-5 text-center text-[12px] text-zinc-500 dark:text-zinc-400">
                Submissions are typically reviewed within 24 hours.
              </p>
              {submitError && (
                <p className="mb-3 text-center text-[12.5px] text-down-500">{submitError}</p>
              )}
              <div className="flex gap-3">
                <Button variant="secondary" fullWidth size="lg" disabled={submitting} onClick={() => setStep('documents')}>
                  Back
                </Button>
                <Button fullWidth size="lg" disabled={submitting} onClick={handleSubmit}>
                  {submitting ? <Loader2 size={16} className="animate-spin" /> : 'Submit for Review'}
                </Button>
              </div>
            </>
          )}
        </Card>
      </div>
    </DashboardLayout>
  );
}

function UploadBox({
  label,
  required,
  file,
  onChange,
}: {
  label: string;
  required?: boolean;
  file: File | null;
  onChange: (file: File | null) => void;
}) {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const inputId = `upload-${label.replace(/\W+/g, '-').toLowerCase()}`;

  useEffect(() => {
    if (!file) {
      setPreviewUrl(null);
      return;
    }
    if (!file.type.startsWith('image/')) {
      setPreviewUrl(null);
      return;
    }
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  function handleFileSelect(e: ChangeEvent<HTMLInputElement>) {
    const selected = e.target.files?.[0];
    onChange(selected ?? null);
    // allow re-selecting the same file later after removal
    e.target.value = '';
  }

  return (
    <div className="mb-4">
      <p className="mb-1.5 text-[13px] font-medium text-zinc-700 dark:text-zinc-300">
        {label}
        {required && <span className="text-down-500"> *</span>}
      </p>

      {file ? (
        <div className="flex items-center gap-3 rounded-xl border border-zinc-200 px-3.5 py-3 dark:border-white/10">
          {previewUrl ? (
            <img src={previewUrl} alt="" className="h-12 w-12 shrink-0 rounded-lg object-cover" />
          ) : (
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-zinc-100 text-zinc-400 dark:bg-white/[0.06]">
              <UploadCloud size={18} />
            </div>
          )}
          <div className="min-w-0 flex-1">
            <p className="truncate text-[12.5px] font-medium text-zinc-800 dark:text-zinc-100">{file.name}</p>
            <p className="text-[11px] text-zinc-400 dark:text-zinc-500">{(file.size / 1024).toFixed(0)} KB</p>
          </div>
          <button
            type="button"
            onClick={() => onChange(null)}
            aria-label="Remove file"
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-zinc-500 hover:bg-zinc-100 dark:text-zinc-400 dark:hover:bg-white/[0.06]"
          >
            <X size={15} />
          </button>
        </div>
      ) : (
        <label
          htmlFor={inputId}
          className="flex cursor-pointer flex-col items-center justify-center rounded-xl border border-dashed border-zinc-300 px-4 py-8 text-center hover:border-brand-500/60 dark:border-white/15"
        >
          <UploadCloud size={22} className="mb-2 text-zinc-400 dark:text-zinc-500" />
          <p className="text-[12.5px] text-zinc-500 dark:text-zinc-400">Click to upload</p>
          <p className="mt-0.5 text-[11px] text-zinc-400 dark:text-zinc-500">JPEG, PNG or WEBP</p>
          <input
            id={inputId}
            type="file"
            accept="image/jpeg,image/png,image/webp,application/pdf"
            className="hidden"
            onChange={handleFileSelect}
          />
        </label>
      )}
    </div>
  );
}
