import { useEffect, useMemo, useState } from 'react';
import { Download, Loader2 } from 'lucide-react';
import DashboardLayout from '../../components/dashboard/DashboardLayout';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { getMyTransactions, toUiTransaction } from '../../lib/walletApi';
import type { Transaction, TxStatus } from '../../data/activityMock';
import { ApiError } from '../../lib/api';

const typeOptions = ['All Types', 'Buy', 'Sell', 'Deposit', 'Withdraw'];
const statusOptions: ('All Status' | TxStatus)[] = ['All Status', 'Completed', 'Pending', 'Failed'];

function statusClasses(status: TxStatus) {
  if (status === 'Completed') return 'bg-up-500/10 text-up-500';
  if (status === 'Pending') return 'bg-pending-500/10 text-pending-500';
  return 'bg-down-500/10 text-down-500';
}

export default function Transactions() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [typeFilter, setTypeFilter] = useState('All Types');
  const [statusFilter, setStatusFilter] = useState<'All Status' | TxStatus>('All Status');

  useEffect(() => {
    getMyTransactions()
      .then((txs) => setTransactions(txs.map(toUiTransaction)))
      .catch((err) => setError(err instanceof ApiError ? err.message : 'Failed to load your transactions.'))
      .finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(
    () =>
      transactions.filter((t) => {
        const typeMatch = typeFilter === 'All Types' || t.type.includes(typeFilter);
        const statusMatch = statusFilter === 'All Status' || t.status === statusFilter;
        return typeMatch && statusMatch;
      }),
    [transactions, typeFilter, statusFilter],
  );

  return (
    <DashboardLayout title="Transaction History" subtitle="View all your transactions.">
      <Card className="!p-0">
        <div className="flex flex-col gap-3 border-b border-zinc-200 px-4 py-4 dark:border-white/[0.08] sm:flex-row sm:items-center sm:justify-between sm:px-5">
          <div className="flex gap-2">
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="h-9 flex-1 rounded-lg border border-zinc-200 bg-white px-3 text-[12.5px] text-zinc-700 outline-none dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-200 sm:flex-none"
            >
              {typeOptions.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as typeof statusFilter)}
              className="h-9 flex-1 rounded-lg border border-zinc-200 bg-white px-3 text-[12.5px] text-zinc-700 outline-none dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-200 sm:flex-none"
            >
              {statusOptions.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <Button variant="secondary" size="sm" className="shrink-0">
            <Download size={14} /> Export
          </Button>
        </div>

        {/* Mobile: stacked card list */}
        <div className="divide-y divide-zinc-100 dark:divide-white/[0.06] sm:hidden">
          {loading ? (
            <div className="flex items-center justify-center gap-2 py-10 text-[13px] text-zinc-400 dark:text-zinc-500">
              <Loader2 size={16} className="animate-spin" /> Loading transactions…
            </div>
          ) : error ? (
            <p className="px-5 py-8 text-center text-[13px] text-down-500">{error}</p>
          ) : (
            <>
              {filtered.map((t) => (
                <div key={t.id} className="flex items-center justify-between px-4 py-3.5">
                  <div className="min-w-0">
                    <p className="truncate text-[13px] font-semibold text-zinc-800 dark:text-zinc-100">{t.type}</p>
                    <p className="mt-0.5 text-[11.5px] text-zinc-400 dark:text-zinc-500">{t.date}</p>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-1">
                    <span className="font-mono text-[12.5px] text-zinc-700 dark:text-zinc-300">{t.amount}</span>
                    <span className={`rounded-full px-2 py-0.5 text-[10.5px] font-semibold ${statusClasses(t.status)}`}>
                      {t.status}
                    </span>
                  </div>
                </div>
              ))}
              {filtered.length === 0 && (
                <p className="px-5 py-8 text-center text-[13px] text-zinc-400 dark:text-zinc-500">
                  No transactions match these filters.
                </p>
              )}
            </>
          )}
        </div>

        {/* Desktop/tablet: table */}
        <div className="hidden overflow-x-auto sm:block">
          <table className="w-full text-left text-[12.5px]">
            <thead>
              <tr className="text-[11px] uppercase tracking-wide text-zinc-400 dark:text-zinc-500">
                <th className="px-5 py-3 font-medium">Type</th>
                <th className="px-5 py-3 font-medium">Amount</th>
                <th className="px-5 py-3 font-medium">Status</th>
                <th className="px-5 py-3 font-medium">Date</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={4} className="px-5 py-10 text-center text-zinc-400 dark:text-zinc-500">
                    <span className="inline-flex items-center gap-2"><Loader2 size={16} className="animate-spin" /> Loading transactions…</span>
                  </td>
                </tr>
              ) : error ? (
                <tr>
                  <td colSpan={4} className="px-5 py-8 text-center text-down-500">{error}</td>
                </tr>
              ) : (
                <>
                  {filtered.map((t) => (
                    <tr key={t.id} className="border-t border-zinc-100 dark:border-white/[0.06]">
                      <td className="px-5 py-3 font-medium text-zinc-800 dark:text-zinc-100">{t.type}</td>
                      <td className="px-5 py-3 font-mono text-zinc-700 dark:text-zinc-300">{t.amount}</td>
                      <td className="px-5 py-3">
                        <span className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${statusClasses(t.status)}`}>
                          {t.status}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-zinc-500 dark:text-zinc-400">{t.date}</td>
                    </tr>
                  ))}
                  {filtered.length === 0 && (
                    <tr>
                      <td colSpan={4} className="px-5 py-8 text-center text-zinc-400 dark:text-zinc-500">
                        No transactions match these filters.
                      </td>
                    </tr>
                  )}
                </>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </DashboardLayout>
  );
}
