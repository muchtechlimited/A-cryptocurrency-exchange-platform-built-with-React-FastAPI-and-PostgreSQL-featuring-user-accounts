import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Loader2, CheckCircle2, AlertTriangle } from 'lucide-react';
import DashboardLayout from '../../components/dashboard/DashboardLayout';
import CoinSelect from '../../components/dashboard/CoinSelect';
import StepProgress from '../../components/dashboard/StepProgress';
import Card from '../../components/ui/Card';
import Field from '../../components/ui/Field';
import Button from '../../components/ui/Button';
import { coins } from '../../data/cryptoMock';
import { previewSell, placeSellOrder, type OrderPreviewApi, type OrderApi, type TradingCurrency } from '../../lib/tradingApi';
import { getMyWallets } from '../../lib/walletApi';
import { ApiError } from '../../lib/api';

// The backend only has exchange rates / wallets for BTC and USDT — ETH and
// BNB in the shared coin list are shown on the Markets page but aren't
// actually tradeable, so they're excluded here.
const tradeableCoins = coins.filter((c) => c.symbol === 'BTC' || c.symbol === 'USDT');

function formatNgn(value: string | number) {
  const n = typeof value === 'string' ? Number(value) : value;
  return `₦${n.toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function formatCoinBalance(value: number, symbol: string) {
  const decimals = symbol === 'BTC' ? 8 : 2;
  return `${value.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })} ${symbol}`;
}

type Step = 'amount' | 'preview' | 'success';

export default function SellCrypto() {
  const [coinId, setCoinId] = useState(tradeableCoins.find((c) => c.symbol === 'USDT')?.id ?? tradeableCoins[0].id);
  const [cryptoAmount, setCryptoAmount] = useState('');
  const coin = tradeableCoins.find((c) => c.id === coinId)!;

  const [step, setStep] = useState<Step>('amount');
  const [preview, setPreview] = useState<OrderPreviewApi | null>(null);
  const [order, setOrder] = useState<OrderApi | null>(null);
  const [coinBalance, setCoinBalance] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [kycRequired, setKycRequired] = useState(false);

  useEffect(() => {
    getMyWallets()
      .then((wallets) => {
        const w = wallets.find((w2) => w2.currency === coin.symbol);
        setCoinBalance(w ? Number(w.available_balance) : 0);
      })
      .catch(() => setCoinBalance(null));
  }, [coin.symbol]);

  async function handlePreview() {
    setError('');
    setBusy(true);
    try {
      const result = await previewSell(coin.symbol as TradingCurrency, cryptoAmount);
      setPreview(result);
      setStep('preview');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to get a preview. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  async function handleConfirm() {
    setError('');
    setKycRequired(false);
    setBusy(true);
    try {
      const placed = await placeSellOrder(coin.symbol as TradingCurrency, cryptoAmount);
      setOrder(placed);
      setStep('success');
    } catch (err) {
      if (err instanceof ApiError && err.status === 403) {
        setKycRequired(true);
      } else {
        setError(err instanceof ApiError ? err.message : 'Failed to place your order. Please try again.');
      }
    } finally {
      setBusy(false);
    }
  }

  function reset() {
    setStep('amount');
    setCryptoAmount('');
    setPreview(null);
    setOrder(null);
    setError('');
    setKycRequired(false);
  }

  if (step === 'success' && order) {
    return (
      <DashboardLayout title="Sell Crypto" subtitle="Sell your crypto for NGN.">
        <div className="mx-auto max-w-xl">
          <Card className="flex flex-col items-center py-10 text-center">
            <CheckCircle2 size={40} className="mb-3 text-up-500" />
            <h3 className="text-[15px] font-semibold text-zinc-900 dark:text-white">Order submitted</h3>
            <p className="mt-1.5 max-w-xs text-[13px] text-zinc-500 dark:text-zinc-400">
              Your order to sell {order.crypto_amount} {order.currency} for {formatNgn(order.net_ngn_amount)} has been
              submitted and is awaiting admin approval. The {order.currency} has been reserved from your wallet —
              you'll be notified once it's approved.
            </p>
            <div className="mt-6 flex gap-3">
              <Link to="/transactions">
                <Button variant="secondary">View Transactions</Button>
              </Link>
              <Button onClick={reset}>Place Another Order</Button>
            </div>
          </Card>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout title="Sell Crypto" subtitle="Sell your crypto for NGN.">
      <div className="mx-auto max-w-xl">
        <Card>
          <StepProgress steps={['Enter Amount', 'Preview', 'Confirm']} activeIndex={step === 'amount' ? 0 : 1} />

          {step === 'amount' && (
            <>
              <CoinSelect selectedId={coinId} coins={tradeableCoins} onSelect={(c) => { setCoinId(c.id); setError(''); }} />

              <Field
                id="cryptoAmount"
                label="You Sell"
                type="number"
                placeholder="0.00"
                value={cryptoAmount}
                onChange={(e) => setCryptoAmount(e.target.value)}
                rightSlot={<span className="pr-3.5 text-[12.5px] font-semibold text-zinc-500 dark:text-zinc-400">{coin.symbol}</span>}
                hint={coinBalance !== null ? `Available: ${formatCoinBalance(coinBalance, coin.symbol)}` : undefined}
              />

              {error && <p className="mb-4 text-[12.5px] text-down-500">{error}</p>}

              <Button
                fullWidth
                size="lg"
                disabled={!(Number(cryptoAmount) > 0) || busy}
                onClick={handlePreview}
              >
                {busy ? <Loader2 size={16} className="animate-spin" /> : 'Preview Sell'}
              </Button>
            </>
          )}

          {step === 'preview' && preview && (
            <>
              <div className="mb-5 space-y-2 rounded-xl border border-zinc-200 p-4 text-[12.5px] dark:border-white/[0.08]">
                <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
                  <span>You Sell</span>
                  <span className="font-mono text-zinc-700 dark:text-zinc-200">{preview.crypto_amount} {preview.currency}</span>
                </div>
                <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
                  <span>Rate</span>
                  <span className="font-mono text-zinc-700 dark:text-zinc-200">{formatNgn(preview.rate_applied)} per {preview.currency}</span>
                </div>
                <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
                  <span>Subtotal</span>
                  <span className="font-mono text-zinc-700 dark:text-zinc-200">{formatNgn(preview.ngn_amount)}</span>
                </div>
                <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
                  <span>Fee ({preview.fee_percentage}%)</span>
                  <span className="font-mono text-zinc-700 dark:text-zinc-200">{formatNgn(preview.fee_amount_ngn)}</span>
                </div>
                <div className="flex justify-between border-t border-zinc-200 pt-2 font-semibold text-zinc-900 dark:border-white/[0.08] dark:text-white">
                  <span>You Receive</span>
                  <span className="font-mono">{formatNgn(preview.net_ngn_amount)}</span>
                </div>
              </div>

              {kycRequired && (
                <div className="mb-4 flex items-start gap-2.5 rounded-xl border border-down-500/30 bg-down-500/5 px-4 py-3 text-[13px] text-down-600 dark:text-down-400">
                  <AlertTriangle size={16} className="mt-0.5 shrink-0" />
                  <div>
                    <p className="font-semibold">Identity verification required</p>
                    <p className="mt-0.5 text-[12.5px] opacity-90">
                      You need approved KYC before you can trade.{' '}
                      <Link to="/kyc" className="font-semibold underline">Verify your identity</Link>
                    </p>
                  </div>
                </div>
              )}
              {error && !kycRequired && <p className="mb-4 text-[12.5px] text-down-500">{error}</p>}

              <div className="flex gap-3">
                <Button variant="secondary" fullWidth size="lg" disabled={busy} onClick={() => setStep('amount')}>
                  Back
                </Button>
                <Button fullWidth size="lg" disabled={busy} onClick={handleConfirm}>
                  {busy ? <Loader2 size={16} className="animate-spin" /> : 'Confirm & Place Order'}
                </Button>
              </div>
            </>
          )}
        </Card>
      </div>
    </DashboardLayout>
  );
}
