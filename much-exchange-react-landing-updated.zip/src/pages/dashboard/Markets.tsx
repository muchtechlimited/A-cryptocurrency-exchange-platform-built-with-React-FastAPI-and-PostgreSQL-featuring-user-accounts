import { TrendingUp, TrendingDown } from 'lucide-react';
import DashboardLayout from '../../components/dashboard/DashboardLayout';
import Card from '../../components/ui/Card';
import { coins } from '../../data/cryptoMock';

export default function Markets() {
  return (
    <DashboardLayout title="Markets" subtitle="Live rates across all supported assets.">
      <div className="mx-auto max-w-2xl">
        <Card className="!p-0">
          <div className="grid grid-cols-3 px-5 py-3 text-[11px] font-medium uppercase tracking-wide text-zinc-400 dark:text-zinc-500">
            <span>Asset</span>
            <span className="text-right">Buy Rate</span>
            <span className="text-right">24h</span>
          </div>

          {coins.map((coin, i) => {
            const changePct = i % 2 === 0 ? 1.2 + i * 0.4 : -(0.5 + i * 0.3);
            const positive = changePct >= 0;
            return (
              <div
                key={coin.id}
                className="grid grid-cols-3 items-center border-t border-zinc-100 px-5 py-3.5 text-[13px] dark:border-white/[0.06]"
              >
                <div className="flex items-center gap-2.5">
                  <span
                    className="flex h-8 w-8 items-center justify-center rounded-full text-[12px] font-bold text-white"
                    style={{ backgroundColor: coin.color }}
                  >
                    {coin.letter}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate font-medium text-zinc-800 dark:text-zinc-100">{coin.name}</p>
                    <p className="text-[11px] text-zinc-400 dark:text-zinc-500">{coin.symbol}</p>
                  </div>
                </div>
                <span className="text-right font-mono text-[12.5px] text-zinc-700 dark:text-zinc-300">
                  ₦{coin.buyRate.toLocaleString()}
                </span>
                <span
                  className={`flex items-center justify-end gap-1 text-right text-[12.5px] font-semibold ${
                    positive ? 'text-up-500' : 'text-down-500'
                  }`}
                >
                  {positive ? <TrendingUp size={13} /> : <TrendingDown size={13} />}
                  {positive ? '+' : ''}
                  {changePct.toFixed(2)}%
                </span>
              </div>
            );
          })}
        </Card>
      </div>
    </DashboardLayout>
  );
}
