import { useEffect, useRef, useState, type ChangeEvent } from 'react';
import { Link } from 'react-router-dom';
import { Loader2, Camera, CheckCircle2, Clock, AlertTriangle, ShieldCheck } from 'lucide-react';
import DashboardLayout from '../../components/dashboard/DashboardLayout';
import Card from '../../components/ui/Card';
import Field from '../../components/ui/Field';
import Button from '../../components/ui/Button';
import {
  getProfile,
  updateProfile,
  uploadAvatar,
  avatarSrc,
  AVATAR_ACCEPT,
  KYC_STATUS_LABEL,
  type ProfileApi,
} from '../../lib/profileApi';
import { ApiError } from '../../lib/api';
import { useAuth } from '../../context/AuthContext';

function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  } catch {
    return iso;
  }
}

/** Masks all but the last 4 digits — the account is already on file, this is just confirmation. */
function maskAccountNumber(value: string | null) {
  if (!value) return null;
  if (value.length <= 4) return value;
  return `${'•'.repeat(value.length - 4)}${value.slice(-4)}`;
}

function KycBadge({ status }: { status: ProfileApi['kyc_status'] }) {
  const config = {
    approved: { Icon: CheckCircle2, cls: 'text-up-500 border-up-500/30 bg-up-500/10' },
    pending: { Icon: Clock, cls: 'text-brand-600 dark:text-brand-400 border-brand-500/30 bg-brand-500/10' },
    rejected: { Icon: AlertTriangle, cls: 'text-down-500 border-down-500/30 bg-down-500/10' },
    not_submitted: { Icon: AlertTriangle, cls: 'text-zinc-500 border-zinc-300 bg-zinc-100 dark:border-white/10 dark:bg-white/[0.06] dark:text-zinc-400' },
  }[status];

  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11.5px] font-medium ${config.cls}`}>
      <config.Icon size={12} />
      {KYC_STATUS_LABEL[status]}
    </span>
  );
}

export default function Profile() {
  const { updateUser } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [profile, setProfile] = useState<ProfileApi | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');

  // Editable fields, seeded from the loaded profile.
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [country, setCountry] = useState('');

  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState('');
  const [saved, setSaved] = useState(false);

  const [avatarUploading, setAvatarUploading] = useState(false);
  const [avatarError, setAvatarError] = useState('');

  function applyProfile(p: ProfileApi) {
    setProfile(p);
    setFullName(p.full_name ?? '');
    setPhone(p.phone_number ?? '');
    setCountry(p.country ?? '');
  }

  useEffect(() => {
    getProfile()
      .then((p) => {
        applyProfile(p);
        // Sessions created before the login response carried avatar_url have
        // a stale cached user — reconcile it from the authoritative profile.
        updateUser({ full_name: p.full_name, avatar_url: p.avatar_url });
      })
      .catch((err) => setLoadError(err instanceof ApiError ? err.message : 'Failed to load your profile.'))
      .finally(() => setLoading(false));
    // updateUser is stable for the provider's lifetime; this is a mount-only fetch.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const trimmedName = fullName.trim();
  const nameInvalid = trimmedName.length > 0 && trimmedName.length < 2;

  // Only send what actually changed — the endpoint is a partial update, and
  // this also keeps the "Save" button honestly disabled when nothing differs.
  const changes: { full_name?: string; phone_number?: string; country?: string } = {};
  if (profile) {
    if (trimmedName !== (profile.full_name ?? '')) changes.full_name = trimmedName;
    if (phone.trim() !== (profile.phone_number ?? '')) changes.phone_number = phone.trim();
    if (country.trim() !== (profile.country ?? '')) changes.country = country.trim();
  }
  const hasChanges = Object.keys(changes).length > 0;

  async function handleSave() {
    if (!hasChanges || nameInvalid || !trimmedName) return;
    setSaving(true);
    setSaveError('');
    setSaved(false);
    try {
      const updated = await updateProfile(changes);
      applyProfile(updated);
      // Keep the topbar / greeting / drawer in sync straight away.
      updateUser({ full_name: updated.full_name });
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } catch (err) {
      setSaveError(err instanceof ApiError ? err.message : 'Could not save your changes.');
    } finally {
      setSaving(false);
    }
  }

  async function handleAvatarChange(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    // Reset the input so picking the same file twice still fires a change event.
    e.target.value = '';
    if (!file) return;

    setAvatarUploading(true);
    setAvatarError('');
    try {
      const updated = await uploadAvatar(file);
      applyProfile(updated);
      // Keep the topbar / drawer photo in sync straight away.
      updateUser({ avatar_url: updated.avatar_url });
    } catch (err) {
      setAvatarError(err instanceof ApiError ? err.message : 'Could not upload that image.');
    } finally {
      setAvatarUploading(false);
    }
  }

  if (loading) {
    return (
      <DashboardLayout title="Profile" subtitle="Manage your profile information.">
        <div className="mx-auto flex max-w-xl items-center justify-center gap-2 py-16 text-[13px] text-zinc-400 dark:text-zinc-500">
          <Loader2 size={16} className="animate-spin" /> Loading your profile…
        </div>
      </DashboardLayout>
    );
  }

  if (loadError || !profile) {
    return (
      <DashboardLayout title="Profile" subtitle="Manage your profile information.">
        <div className="mx-auto max-w-xl rounded-xl border border-down-500/30 bg-down-500/5 px-4 py-3 text-[13px] text-down-600 dark:text-down-500">
          {loadError || 'Failed to load your profile.'}
        </div>
      </DashboardLayout>
    );
  }

  const src = avatarSrc(profile.avatar_url);

  return (
    <DashboardLayout title="Profile" subtitle="Manage your profile information.">
      <div className="mx-auto max-w-xl space-y-4">
        <Card>
          <div className="mb-6 flex items-center gap-4">
            <div className="relative shrink-0">
              {src ? (
                <img
                  src={src}
                  alt=""
                  className="h-16 w-16 rounded-full object-cover"
                  // If the file was removed server-side, fall back to the initial
                  // rather than showing a broken-image icon.
                  onError={() => setProfile((p) => (p ? { ...p, avatar_url: null } : p))}
                />
              ) : (
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-b from-brand-400 to-brand-500 text-[22px] font-bold text-zinc-900">
                  {(profile.full_name || '?').charAt(0).toUpperCase()}
                </div>
              )}

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={avatarUploading}
                aria-label="Change profile photo"
                className="absolute -bottom-0.5 -right-0.5 flex h-6 w-6 items-center justify-center rounded-full border-2 border-white bg-zinc-900 text-white transition-colors hover:bg-zinc-700 disabled:opacity-60 dark:border-[#101113] dark:bg-white dark:text-zinc-900"
              >
                {avatarUploading ? <Loader2 size={11} className="animate-spin" /> : <Camera size={11} />}
              </button>

              <input
                ref={fileInputRef}
                type="file"
                accept={AVATAR_ACCEPT}
                onChange={handleAvatarChange}
                className="hidden"
              />
            </div>

            <div className="min-w-0">
              <p className="truncate text-[14px] font-semibold text-zinc-900 dark:text-white">{profile.full_name}</p>
              <p className="truncate text-[12.5px] text-zinc-500 dark:text-zinc-400">{profile.email}</p>
              <div className="mt-1.5">
                <KycBadge status={profile.kyc_status} />
              </div>
            </div>
          </div>

          {avatarError && (
            <p className="mb-4 rounded-lg border border-down-500/30 bg-down-500/5 px-3 py-2 text-[12px] text-down-600 dark:text-down-500">
              {avatarError}
            </p>
          )}

          <Field
            id="fullName"
            label="Full Name"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            error={nameInvalid ? 'Name must be at least 2 characters.' : undefined}
          />

          <Field
            id="email"
            label="Email"
            type="email"
            value={profile.email}
            readOnly
            disabled
            hint="Your email is your sign-in ID and can't be changed here. Contact support if you need it updated."
            className="cursor-not-allowed opacity-70"
          />

          <Field
            id="phone"
            label="Phone Number"
            value={phone}
            placeholder="+234 800 000 0000"
            onChange={(e) => setPhone(e.target.value)}
          />

          <Field
            id="country"
            label="Country"
            value={country}
            placeholder="Nigeria"
            onChange={(e) => setCountry(e.target.value)}
          />

          {saveError && (
            <p className="mb-3 rounded-lg border border-down-500/30 bg-down-500/5 px-3 py-2 text-[12px] text-down-600 dark:text-down-500">
              {saveError}
            </p>
          )}

          <Button
            fullWidth
            size="lg"
            onClick={handleSave}
            disabled={!hasChanges || saving || nameInvalid || !trimmedName}
          >
            {saving ? (
              <>
                <Loader2 size={15} className="animate-spin" /> Saving…
              </>
            ) : saved ? (
              <>
                <CheckCircle2 size={15} /> Saved
              </>
            ) : (
              'Save Changes'
            )}
          </Button>

          <p className="mt-3 text-center text-[11.5px] text-zinc-400 dark:text-zinc-500">
            Member since {formatDate(profile.created_at)}
          </p>
        </Card>

        {/* Read-only: the payout account is captured at signup and is the
            destination for every NGN withdrawal, so it's worth showing —
            but there's no endpoint to change it, and it shouldn't be
            editable without review anyway. */}
        <Card>
          <div className="mb-3 flex items-center gap-2">
            <ShieldCheck size={15} className="text-zinc-400" />
            <p className="text-[13px] font-semibold text-zinc-900 dark:text-white">Payout Bank Account</p>
          </div>

          {profile.bank_name || profile.account_number ? (
            <>
              <dl className="space-y-2.5">
                <div className="flex items-center justify-between gap-3">
                  <dt className="text-[12.5px] text-zinc-500 dark:text-zinc-400">Bank</dt>
                  <dd className="truncate text-[13px] font-medium text-zinc-900 dark:text-white">{profile.bank_name || '—'}</dd>
                </div>
                <div className="flex items-center justify-between gap-3">
                  <dt className="text-[12.5px] text-zinc-500 dark:text-zinc-400">Account Number</dt>
                  <dd className="font-mono text-[13px] font-medium text-zinc-900 dark:text-white">
                    {maskAccountNumber(profile.account_number) || '—'}
                  </dd>
                </div>
                <div className="flex items-center justify-between gap-3">
                  <dt className="text-[12.5px] text-zinc-500 dark:text-zinc-400">Account Name</dt>
                  <dd className="truncate text-[13px] font-medium text-zinc-900 dark:text-white">{profile.account_name || '—'}</dd>
                </div>
              </dl>
              <p className="mt-3 text-[11.5px] text-zinc-400 dark:text-zinc-500">
                NGN withdrawals are always paid to this account. Contact support to change it.
              </p>
            </>
          ) : (
            <p className="text-[12.5px] text-zinc-500 dark:text-zinc-400">
              No bank account on file. Contact support to add one — it's required for NGN withdrawals.
            </p>
          )}
        </Card>

        {profile.kyc_status !== 'approved' && (
          <Card className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-[13px] font-semibold text-zinc-900 dark:text-white">Identity verification</p>
              <p className="mt-0.5 text-[12px] text-zinc-500 dark:text-zinc-400">
                {profile.kyc_status === 'pending'
                  ? "Your documents are being reviewed. We'll notify you once it's done."
                  : 'Verify your identity to unlock trading.'}
              </p>
            </div>
            {profile.kyc_status !== 'pending' && (
              <Link to="/kyc" className="shrink-0">
                <Button size="sm">{profile.kyc_status === 'rejected' ? 'Resubmit' : 'Verify'}</Button>
              </Link>
            )}
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
