import DashboardLayout from '../../components/dashboard/DashboardLayout';
import BalanceCard from '../../components/dashboard/BalanceCard';
import PortfolioChart from '../../components/dashboard/PortfolioChart';
import MarketOverview from '../../components/dashboard/MarketOverview';
import TotalWalletCard from '../../components/dashboard/TotalWalletCard';
import QuickActionGrid, { mobileQuickActions, tabletQuickActions } from '../../components/dashboard/QuickActionGrid';
import TradeConfidenceBanner from '../../components/dashboard/TradeConfidenceBanner';
import CompactMarketOverview from '../../components/dashboard/CompactMarketOverview';
import RecentTransactionsCompact from '../../components/dashboard/RecentTransactionsCompact';
import GiftCardPromoBanner from '../../components/dashboard/GiftCardPromoBanner';
import { walletBalances } from '../../data/dashboardMock';
import { useAuth } from '../../context/AuthContext';

export default function Dashboard() {
  const { user } = useAuth();
  const firstName = user?.full_name?.trim().split(' ')[0] || 'there';
  return (
    <DashboardLayout
      title={`Welcome back, ${firstName}! 👋`}
      subtitle="Here's what's happening with your account today."
    >
      {/* ---------- Mobile (<768px) ---------- */}
      <div className="space-y-5 md:hidden">
        <TotalWalletCard />

        <div>
          <p className="mb-2.5 text-[13px] font-semibold text-zinc-900 dark:text-white">Quick Actions</p>
          <QuickActionGrid actions={mobileQuickActions} columns="grid-cols-4" />
        </div>

        <TradeConfidenceBanner />
        <CompactMarketOverview />
        <GiftCardPromoBanner />
      </div>

      {/* ---------- Tablet (768px – 1023px) ---------- */}
      <div className="hidden space-y-5 md:block lg:hidden">
        <TotalWalletCard />

        <div>
          <p className="mb-2.5 text-[13px] font-semibold text-zinc-900 dark:text-white">Quick Actions</p>
          <QuickActionGrid actions={tabletQuickActions} columns="grid-cols-6" />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <CompactMarketOverview />
          <RecentTransactionsCompact />
        </div>

        <GiftCardPromoBanner />
      </div>

      {/* ---------- Desktop (1024px+) ---------- */}
      <div className="hidden lg:block">
        <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {walletBalances.map((wallet) => (
            <BalanceCard key={wallet.label} wallet={wallet} />
          ))}
        </div>

        <div className="grid grid-cols-1 gap-4 xl:grid-cols-[1fr_1.4fr]">
          <MarketOverview />
          <PortfolioChart />
        </div>
      </div>
    </DashboardLayout>
  );
}
