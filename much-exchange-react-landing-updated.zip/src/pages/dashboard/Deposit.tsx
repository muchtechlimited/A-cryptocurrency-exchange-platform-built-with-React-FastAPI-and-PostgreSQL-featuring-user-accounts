import { useEffect, useState } from 'react';
import { Copy, Loader2, CheckCircle2, AlertTriangle, ExternalLink } from 'lucide-react';
import DashboardLayout from '../../components/dashboard/DashboardLayout';
import CoinSelect from '../../components/dashboard/CoinSelect';
import Card from '../../components/ui/Card';
import Field from '../../components/ui/Field';
import Button from '../../components/ui/Button';
import { coins } from '../../data/cryptoMock';
import { ApiError } from '../../lib/api';
import {
  getCompanyWallets,
  submitCryptoDeposit,
  getMyCryptoDeposits,
  initializeNgnDepositSafe,
  initiateNgnBankTransferSafe,
  getMyNgnBankTransfers,
  formatNgn,
  formatDateTime,
  statusBadgeClasses,
  statusLabel,
  type CompanyWalletAddressApi,
  type CryptoDepositApi,
  type NGNBankTransferApi,
} from '../../lib/depositApi';

type Tab = 'crypto' | 'ngn';

// Backend only has company deposit addresses / exchange rates for BTC and
// USDT — same restriction BuyCrypto.tsx applies, for the same reason.
const tradeableCoins = coins.filter((c) => c.symbol === 'BTC' || c.symbol === 'USDT');

export default function Deposit() {
  const [tab, setTab] = useState<Tab>('crypto');

  return (
    <DashboardLayout title="Deposit" subtitle="Choose a method to deposit funds.">
      <div className="mx-auto max-w-xl">
        <Card>
          <div className="mb-5 flex gap-1 rounded-lg bg-zinc-100 p-1 dark:bg-white/[0.05]">
            <button
              onClick={() => setTab('crypto')}
              className={`flex-1 rounded-md py-2 text-[13px] font-semibold transition-colors ${
                tab === 'crypto'
                  ? 'bg-gradient-to-b from-brand-400 to-brand-500 text-zinc-900'
                  : 'text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-white'
              }`}
            >
              Crypto Deposit
            </button>
            <button
              onClick={() => setTab('ngn')}
              className={`flex-1 rounded-md py-2 text-[13px] font-semibold transition-colors ${
                tab === 'ngn'
                  ? 'bg-gradient-to-b from-brand-400 to-brand-500 text-zinc-900'
                  : 'text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-white'
              }`}
            >
              NGN Deposit
            </button>
          </div>

          {tab === 'crypto' ? <CryptoDepositTab /> : <NgnDepositTab />}
        </Card>
      </div>
    </DashboardLayout>
  );
}

// --- Crypto deposit tab ---

function CryptoDepositTab() {
  const [coinId, setCoinId] = useState(tradeableCoins[0].id);
  const coin = tradeableCoins.find((c) => c.id === coinId)!;

  const [addresses, setAddresses] = useState<CompanyWalletAddressApi[]>([]);
  const [addressesLoading, setAddressesLoading] = useState(true);
  const [addressesError, setAddressesError] = useState('');
  const [copied, setCopied] = useState(false);

  const [amount, setAmount] = useState('');
  const [txHash, setTxHash] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const [history, setHistory] = useState<CryptoDepositApi[]>([]);
  const [historyLoading, setHistoryLoading] = useState(true);

  useEffect(() => {
    getCompanyWallets()
      .then(setAddresses)
      .catch((err) => setAddressesError(err instanceof ApiError ? err.message : 'Could not load deposit addresses.'))
      .finally(() => setAddressesLoading(false));
    loadHistory();
  }, []);

  function loadHistory() {
    setHistoryLoading(true);
    getMyCryptoDeposits()
      .then(setHistory)
      .catch(() => setHistory([]))
      .finally(() => setHistoryLoading(false));
  }

  const address = addresses.find((a) => a.currency === coin.symbol);

  function copyAddress() {
    if (!address) return;
    navigator.clipboard?.writeText(address.address).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  async function handleSubmit() {
    setSubmitError('');
    setSubmitting(true);
    try {
      await submitCryptoDeposit({ currency: coin.symbol as 'BTC' | 'USDT', amount, tx_hash: txHash.trim() });
      setSubmitted(true);
      setAmount('');
      setTxHash('');
      loadHistory();
    } catch (err) {
      setSubmitError(err instanceof ApiError ? err.message : 'Could not submit your deposit. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <>
      <CoinSelect selectedId={coinId} coins={tradeableCoins} onSelect={(c) => { setCoinId(c.id); setSubmitted(false); setSubmitError(''); }} />

      <div className="mb-5 flex flex-col items-center rounded-xl border border-zinc-200 p-6 dark:border-white/[0.08]">
        {addressesLoading ? (
          <div className="flex items-center gap-2 py-6 text-[13px] text-zinc-400 dark:text-zinc-500">
            <Loader2 size={16} className="animate-spin" /> Loading deposit address…
          </div>
        ) : addressesError ? (
          <p className="py-6 text-center text-[13px] text-down-500">{addressesError}</p>
        ) : !address ? (
          <p className="py-6 text-center text-[13px] text-zinc-400 dark:text-zinc-500">
            No deposit address has been set up for {coin.symbol} yet — check back soon or contact support.
          </p>
        ) : (
          <>
            <div className="mb-4 flex h-[164px] w-[164px] items-center justify-center rounded-xl bg-white p-2">
              <QrPlaceholder />
            </div>

            <p className="mb-1.5 text-[12px] font-medium text-zinc-500 dark:text-zinc-400">Deposit Address</p>
            <div className="flex w-full items-center gap-2 rounded-lg border border-zinc-200 bg-zinc-50 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
              <span className="flex-1 truncate font-mono text-[12px] text-zinc-700 dark:text-zinc-200">
                {address.address}
              </span>
              <button
                onClick={copyAddress}
                className="shrink-0 text-zinc-400 hover:text-zinc-700 dark:hover:text-white"
                aria-label="Copy address"
              >
                <Copy size={15} />
              </button>
            </div>
            {copied && <p className="mt-1.5 text-[11px] text-up-500">Copied to clipboard</p>}

            <p className="mt-4 rounded-lg bg-brand-500/10 px-3 py-2 text-center text-[11.5px] text-brand-700 dark:text-brand-400">
              Only send {coin.symbol} to this address{address.network_note ? ` (${address.network_note})` : ''}. Sending
              any other coin may result in permanent loss.
            </p>
          </>
        )}
      </div>

      {submitted && (
        <div className="mb-5 flex items-start gap-2.5 rounded-xl border border-up-500/30 bg-up-500/5 px-4 py-3 text-[13px] text-up-600 dark:text-up-400">
          <CheckCircle2 size={16} className="mt-0.5 shrink-0" />
          <div>
            <p className="font-semibold">Submitted for review</p>
            <p className="mt-0.5 text-[12.5px] opacity-90">
              Your {coin.symbol} deposit has been recorded and is awaiting admin verification. It'll be credited to
              your wallet once approved.
            </p>
          </div>
        </div>
      )}

      <p className="mb-3 text-[13px] font-semibold text-zinc-900 dark:text-white">Already sent {coin.symbol}?</p>
      <p className="mb-4 text-[12px] text-zinc-500 dark:text-zinc-400">
        Submit the transaction ID (TxID) below so we can verify and credit your deposit.
      </p>

      <Field
        id="depositAmount"
        label="Amount Sent"
        type="number"
        placeholder="0.00"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
        rightSlot={<span className="pr-3.5 text-[12.5px] font-semibold text-zinc-500 dark:text-zinc-400">{coin.symbol}</span>}
      />

      <Field
        id="txHash"
        label="Transaction ID (TxID)"
        type="text"
        placeholder="Paste the transaction hash"
        value={txHash}
        onChange={(e) => setTxHash(e.target.value)}
      />

      {submitError && <p className="mb-3 text-[12.5px] text-down-500">{submitError}</p>}

      <Button
        fullWidth
        size="lg"
        disabled={!(Number(amount) > 0) || !txHash.trim() || submitting}
        onClick={handleSubmit}
      >
        {submitting ? <Loader2 size={16} className="animate-spin" /> : 'Submit for Review'}
      </Button>

      <DepositHistory
        title="Deposit History"
        loading={historyLoading}
        rows={history.map((d) => ({
          id: d.id,
          label: `${d.amount} ${d.currency}`,
          sub: `TxID: ${d.tx_hash.slice(0, 14)}${d.tx_hash.length > 14 ? '…' : ''}`,
          status: d.status,
          date: formatDateTime(d.created_at),
        }))}
      />
    </>
  );
}

// --- NGN deposit tab ---

type NgnMethod = 'paystack' | 'bank';

function NgnDepositTab() {
  const [method, setMethod] = useState<NgnMethod>('paystack');

  return (
    <>
      <div className="mb-5 flex gap-2">
        {([
          { key: 'paystack', label: 'Pay with Card' },
          { key: 'bank', label: 'Bank Transfer' },
        ] as const).map((opt) => (
          <button
            key={opt.key}
            onClick={() => setMethod(opt.key)}
            className={`flex-1 rounded-lg border px-4 py-2 text-[13px] font-semibold transition-colors ${
              method === opt.key
                ? 'border-brand-500 bg-brand-500/10 text-brand-600 dark:text-brand-400'
                : 'border-zinc-200 text-zinc-600 hover:bg-zinc-50 dark:border-white/10 dark:text-zinc-300 dark:hover:bg-white/[0.04]'
            }`}
          >
            {opt.label}
          </button>
        ))}
      </div>

      {method === 'paystack' ? <PaystackDeposit /> : <BankTransferDeposit />}
    </>
  );
}

function PaystackDeposit() {
  const [amount, setAmount] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [unavailable, setUnavailable] = useState(false);
  const [checkoutUrl, setCheckoutUrl] = useState('');

  async function handlePay() {
    setError('');
    setUnavailable(false);
    setCheckoutUrl('');
    setBusy(true);
    try {
      const result = await initializeNgnDepositSafe(amount);
      if ('data' in result) {
        setCheckoutUrl(result.data.authorization_url);
        if (result.data.authorization_url) {
          window.open(result.data.authorization_url, '_blank', 'noopener,noreferrer');
        }
      } else {
        setUnavailable(true);
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not start a card payment. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  if (unavailable) {
    return (
      <div className="rounded-xl border border-zinc-200 p-6 text-center dark:border-white/[0.08]">
        <AlertTriangle size={28} className="mx-auto mb-2 text-pending-500" />
        <p className="mb-1 text-[13.5px] font-semibold text-zinc-900 dark:text-white">
          Card payments aren't available yet
        </p>
        <p className="mb-4 text-[12.5px] text-zinc-500 dark:text-zinc-400">
          We're still setting up card payments. Please use bank transfer instead for now.
        </p>
        <Button variant="secondary" onClick={() => setUnavailable(false)}>Try Again</Button>
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-zinc-200 p-6 dark:border-white/[0.08]">
      <p className="mb-4 text-[12.5px] text-zinc-500 dark:text-zinc-400">
        Enter an amount and you'll be redirected to a secure Paystack checkout to complete payment by card.
      </p>

      <Field
        id="paystackAmount"
        label="Amount"
        type="number"
        placeholder="0.00"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
        rightSlot={<span className="pr-3.5 text-[12.5px] font-semibold text-zinc-500 dark:text-zinc-400">NGN</span>}
      />

      {checkoutUrl && (
        <div className="mb-4 flex items-start gap-2.5 rounded-xl border border-up-500/30 bg-up-500/5 px-4 py-3 text-[13px] text-up-600 dark:text-up-400">
          <CheckCircle2 size={16} className="mt-0.5 shrink-0" />
          <div className="min-w-0">
            <p className="font-semibold">Checkout opened in a new tab</p>
            <p className="mt-0.5 break-words text-[12.5px] opacity-90">
              Didn't see it?{' '}
              <a href={checkoutUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 font-semibold underline">
                Open Paystack checkout <ExternalLink size={12} />
              </a>
            </p>
          </div>
        </div>
      )}

      {error && <p className="mb-4 text-[12.5px] text-down-500">{error}</p>}

      <Button fullWidth size="lg" disabled={!(Number(amount) > 0) || busy} onClick={handlePay}>
        {busy ? <Loader2 size={16} className="animate-spin" /> : 'Continue to Payment'}
      </Button>
    </div>
  );
}

function BankTransferDeposit() {
  const [amount, setAmount] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [unavailable, setUnavailable] = useState(false);
  const [result, setResult] = useState<{ bank_name: string; account_number: string; account_name: string; reference_number: string; warning: string } | null>(null);
  const [copied, setCopied] = useState(false);

  const [history, setHistory] = useState<NGNBankTransferApi[]>([]);
  const [historyLoading, setHistoryLoading] = useState(true);

  useEffect(() => {
    loadHistory();
  }, []);

  function loadHistory() {
    setHistoryLoading(true);
    getMyNgnBankTransfers()
      .then(setHistory)
      .catch(() => setHistory([]))
      .finally(() => setHistoryLoading(false));
  }

  async function handleInitiate() {
    setError('');
    setUnavailable(false);
    setBusy(true);
    try {
      const res = await initiateNgnBankTransferSafe(amount);
      if ('data' in res) {
        setResult({
          bank_name: res.data.bank_name,
          account_number: res.data.account_number,
          account_name: res.data.account_name,
          reference_number: res.data.deposit.reference_number,
          warning: res.data.warning,
        });
        setAmount('');
        loadHistory();
      } else {
        setUnavailable(true);
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not generate a transfer reference. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  function copyReference() {
    if (!result) return;
    navigator.clipboard?.writeText(result.reference_number).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  if (unavailable) {
    return (
      <div className="rounded-xl border border-zinc-200 p-6 text-center dark:border-white/[0.08]">
        <AlertTriangle size={28} className="mx-auto mb-2 text-pending-500" />
        <p className="mb-1 text-[13.5px] font-semibold text-zinc-900 dark:text-white">
          Bank transfer is temporarily unavailable
        </p>
        <p className="mb-4 text-[12.5px] text-zinc-500 dark:text-zinc-400">
          We're setting up bank transfer deposits. Please try again shortly or contact support.
        </p>
        <Button variant="secondary" onClick={() => setUnavailable(false)}>Try Again</Button>
      </div>
    );
  }

  if (result) {
    return (
      <>
        <div className="rounded-xl border border-zinc-200 p-6 dark:border-white/[0.08]">
          <p className="mb-1 text-center text-[13.5px] font-semibold text-zinc-900 dark:text-white">
            Transfer to the account below
          </p>
          <p className="mb-4 text-center text-[12.5px] text-zinc-500 dark:text-zinc-400">
            Your NGN wallet will be credited once we confirm the transfer.
          </p>
          <div className="space-y-2 rounded-lg bg-zinc-50 p-4 text-left text-[12.5px] dark:bg-white/[0.04]">
            <div className="flex justify-between"><span className="text-zinc-500 dark:text-zinc-400">Bank Name</span><span className="font-medium text-zinc-800 dark:text-zinc-100">{result.bank_name}</span></div>
            <div className="flex justify-between"><span className="text-zinc-500 dark:text-zinc-400">Account Number</span><span className="font-mono font-medium text-zinc-800 dark:text-zinc-100">{result.account_number}</span></div>
            <div className="flex justify-between"><span className="text-zinc-500 dark:text-zinc-400">Account Name</span><span className="font-medium text-zinc-800 dark:text-zinc-100">{result.account_name}</span></div>
          </div>

          <p className="mb-1.5 mt-4 text-[12px] font-medium text-zinc-500 dark:text-zinc-400">
            Transfer Description (use ONLY this — see warning below)
          </p>
          <div className="mb-1.5 flex items-center gap-2 rounded-lg border border-zinc-200 bg-zinc-50 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
            <span className="flex-1 truncate font-mono text-[12px] text-zinc-700 dark:text-zinc-200">
              {result.reference_number}
            </span>
            <button onClick={copyReference} className="shrink-0 text-zinc-400 hover:text-zinc-700 dark:hover:text-white" aria-label="Copy reference">
              <Copy size={15} />
            </button>
          </div>
          {copied && <p className="mb-2 text-[11px] text-up-500">Copied to clipboard</p>}

          <p className="mt-3 rounded-lg bg-down-500/10 px-3 py-2 text-[11.5px] text-down-600 dark:text-down-400">
            {result.warning}
          </p>

          <Button fullWidth size="lg" className="mt-4" variant="secondary" onClick={() => setResult(null)}>
            Start Another Transfer
          </Button>
        </div>

        <DepositHistory
          title="Bank Transfer History"
          loading={historyLoading}
          rows={history.map((d) => ({
            id: d.id,
            label: formatNgn(d.amount),
            sub: `Ref: ${d.reference_number}`,
            status: d.status,
            date: formatDateTime(d.created_at),
          }))}
        />
      </>
    );
  }

  return (
    <>
      <div className="rounded-xl border border-zinc-200 p-6 dark:border-white/[0.08]">
        <p className="mb-4 text-[12.5px] text-zinc-500 dark:text-zinc-400">
          Enter an amount to get a dedicated reference number and our bank account details for this deposit.
        </p>

        <Field
          id="bankTransferAmount"
          label="Amount"
          type="number"
          placeholder="0.00"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          rightSlot={<span className="pr-3.5 text-[12.5px] font-semibold text-zinc-500 dark:text-zinc-400">NGN</span>}
        />

        {error && <p className="mb-4 text-[12.5px] text-down-500">{error}</p>}

        <Button fullWidth size="lg" disabled={!(Number(amount) > 0) || busy} onClick={handleInitiate}>
          {busy ? <Loader2 size={16} className="animate-spin" /> : 'Get Bank Details'}
        </Button>
      </div>

      <DepositHistory
        title="Bank Transfer History"
        loading={historyLoading}
        rows={history.map((d) => ({
          id: d.id,
          label: formatNgn(d.amount),
          sub: `Ref: ${d.reference_number}`,
          status: d.status,
          date: formatDateTime(d.created_at),
        }))}
      />
    </>
  );
}

// --- Shared deposit history list ---

interface HistoryRow {
  id: string;
  label: string;
  sub: string;
  status: string;
  date: string;
}

function DepositHistory({ title, loading, rows }: { title: string; loading: boolean; rows: HistoryRow[] }) {
  return (
    <div className="mt-6">
      <p className="mb-2.5 text-[13px] font-semibold text-zinc-900 dark:text-white">{title}</p>
      {loading ? (
        <div className="flex items-center gap-2 py-6 text-[12.5px] text-zinc-400 dark:text-zinc-500">
          <Loader2 size={14} className="animate-spin" /> Loading history…
        </div>
      ) : rows.length === 0 ? (
        <p className="py-6 text-center text-[12.5px] text-zinc-400 dark:text-zinc-500">No deposits yet.</p>
      ) : (
        <div className="space-y-2">
          {rows.map((r) => (
            <div
              key={r.id}
              className="flex items-center justify-between rounded-xl border border-zinc-200 px-4 py-3 dark:border-white/[0.08]"
            >
              <div className="min-w-0">
                <p className="truncate text-[13px] font-medium text-zinc-800 dark:text-zinc-100">{r.label}</p>
                <p className="truncate text-[11.5px] text-zinc-400 dark:text-zinc-500">{r.sub} · {r.date}</p>
              </div>
              <span className={`ml-3 shrink-0 rounded-full px-2 py-0.5 text-[10.5px] font-semibold ${statusBadgeClasses(r.status)}`}>
                {statusLabel(r.status)}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/** Lightweight generic QR-style placeholder graphic — not a real scannable code. */
function QrPlaceholder() {
  const cells = Array.from({ length: 49 }, (_, i) => i);
  return (
    <svg viewBox="0 0 70 70" className="h-full w-full">
      <rect x="0" y="0" width="70" height="70" fill="white" />
      {cells.map((i) => {
        const row = Math.floor(i / 7);
        const col = i % 7;
        const on = (row + col * 3) % 3 !== 0;
        return on ? <rect key={i} x={col * 10} y={row * 10} width="9" height="9" fill="#08090B" /> : null;
      })}
    </svg>
  );
}
