import { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import DashboardLayout from '../../components/dashboard/DashboardLayout';
import WalletRow from '../../components/dashboard/WalletRow';
import Card from '../../components/ui/Card';
import { getMyWallets, getRates, toUiWallet } from '../../lib/walletApi';
import type { WalletRowData } from '../../data/walletsMock';
import { ApiError } from '../../lib/api';

export default function Wallets() {
  const [wallets, setWallets] = useState<WalletRowData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all([getMyWallets(), getRates().catch(() => [])])
      .then(([apiWallets, rates]) => {
        const rows = apiWallets
          .map((w) => toUiWallet(w, rates))
          .filter((w): w is WalletRowData => w !== null);
        setWallets(rows);
      })
      .catch((err) => setError(err instanceof ApiError ? err.message : 'Failed to load your wallets.'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <DashboardLayout title="Wallets" subtitle="Manage your cryptocurrencies.">
      <div className="mx-auto max-w-2xl">
        <Card className="!p-0">
          {loading ? (
            <div className="flex items-center justify-center gap-2 py-14 text-[13px] text-zinc-400 dark:text-zinc-500">
              <Loader2 size={16} className="animate-spin" /> Loading your wallets…
            </div>
          ) : error ? (
            <p className="px-5 py-8 text-center text-[13px] text-down-500">{error}</p>
          ) : (
            <div className="px-5 pt-5">
              {wallets.map((wallet) => (
                <WalletRow key={wallet.id} wallet={wallet} />
              ))}
            </div>
          )}
        </Card>
      </div>
    </DashboardLayout>
  );
}
