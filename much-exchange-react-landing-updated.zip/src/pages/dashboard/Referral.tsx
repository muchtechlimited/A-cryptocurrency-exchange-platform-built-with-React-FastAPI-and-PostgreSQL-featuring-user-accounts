import { useState } from 'react';
import { Copy, Share2, Send, MessageCircle } from 'lucide-react';
import DashboardLayout from '../../components/dashboard/DashboardLayout';
import Card from '../../components/ui/Card';

const referralLink = 'https://muchexchange.com/ref/Moshood001';

const stats = [
  { label: 'Total Referrals', value: '12' },
  { label: 'Total Earnings', value: '₦120,000.00' },
  { label: 'Pending Earnings', value: '₦30,000.00' },
];

export default function Referral() {
  const [copied, setCopied] = useState(false);

  const copyLink = () => {
    navigator.clipboard?.writeText(referralLink).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <DashboardLayout title="Referral Program" subtitle="Invite friends and earn rewards.">
      <div className="mx-auto max-w-xl space-y-4">
        <Card>
          <p className="mb-2 text-[12.5px] font-medium text-zinc-500 dark:text-zinc-400">Your Referral Link</p>
          <div className="mb-4 flex items-center gap-2 rounded-lg border border-zinc-200 bg-zinc-50 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
            <span className="flex-1 truncate font-mono text-[12.5px] text-zinc-700 dark:text-zinc-200">{referralLink}</span>
            <button onClick={copyLink} className="shrink-0 text-zinc-400 hover:text-zinc-700 dark:hover:text-white" aria-label="Copy link">
              <Copy size={15} />
            </button>
          </div>
          {copied && <p className="-mt-3 mb-3 text-[11px] text-up-500">Link copied</p>}

          <p className="mb-2 text-[12.5px] font-medium text-zinc-500 dark:text-zinc-400">Share via</p>
          <div className="flex gap-2">
            {[MessageCircle, Share2, Send].map((Icon, i) => (
              <button
                key={i}
                className="flex h-9 w-9 items-center justify-center rounded-lg border border-zinc-200 text-zinc-600 hover:bg-zinc-50 dark:border-white/10 dark:text-zinc-300 dark:hover:bg-white/[0.06]"
              >
                <Icon size={15} />
              </button>
            ))}
          </div>
        </Card>

        <Card>
          <p className="mb-3 text-[13px] font-semibold text-zinc-900 dark:text-white">Referral Stats</p>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            {stats.map((s) => (
              <div key={s.label} className="flex items-center justify-between rounded-xl border border-zinc-200 p-3 text-center dark:border-white/[0.08] sm:flex-col sm:justify-center">
                <p className="text-[11px] text-zinc-500 dark:text-zinc-400">{s.label}</p>
                <p className="mt-0 font-display text-[15px] font-bold text-zinc-900 dark:text-white sm:mt-1">{s.value}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </DashboardLayout>
  );
}
