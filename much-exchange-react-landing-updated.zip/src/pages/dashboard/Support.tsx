import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Loader2, MessageCircle, Send, CheckCircle2, Clock, HelpCircle, Mail } from 'lucide-react';
import DashboardLayout from '../../components/dashboard/DashboardLayout';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import {
  submitTicket,
  getMyTickets,
  TICKET_SUBJECTS,
  TICKET_STATUS_LABEL,
  type TicketApi,
  type TicketSubject,
} from '../../lib/supportApi';
import { ApiError } from '../../lib/api';

const MAX_MESSAGE_LENGTH = 2000;

const FAQS: { q: string; a: string }[] = [
  {
    q: 'How long does a deposit take to reflect?',
    a: 'Crypto deposits are credited once an admin confirms your transaction on-chain — usually within a few hours of submitting your TxID. NGN bank transfers are credited once an admin confirms the transfer against the reference number you were given.',
  },
  {
    q: 'Why do I need to complete KYC before trading?',
    a: "Identity verification is required before you can place a Buy or Sell order — you can still preview rates and fees without it. Head to KYC Verification to submit your documents; most reviews are completed within 24 hours.",
  },
  {
    q: 'Where do my NGN withdrawals get paid to?',
    a: 'Always to the bank account on file from signup — you can see it on your Profile page. If it needs to change, open a ticket below and we\u2019ll help.',
  },
  {
    q: 'Why was my order or withdrawal rejected?',
    a: 'If a request is rejected, the reason (if one was given) shows in its status on the relevant history page. If funds were frozen, a rejection either returns them to your available balance or keeps them frozen for review, and your transaction history will reflect which.',
  },
];

function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' });
  } catch {
    return iso;
  }
}

function StatusBadge({ status }: { status: TicketApi['status'] }) {
  const config = {
    open: { Icon: MessageCircle, cls: 'text-brand-600 dark:text-brand-400 border-brand-500/30 bg-brand-500/10' },
    pending: { Icon: Clock, cls: 'text-pending-500 border-pending-500/30 bg-pending-500/10' },
    resolved: { Icon: CheckCircle2, cls: 'text-up-500 border-up-500/30 bg-up-500/10' },
  }[status];
  return (
    <span className={`inline-flex shrink-0 items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-medium ${config.cls}`}>
      <config.Icon size={11} />
      {TICKET_STATUS_LABEL[status]}
    </span>
  );
}

function TicketCard({ ticket }: { ticket: TicketApi }) {
  return (
    <div className="border-b border-zinc-200 px-4 py-4 last:border-0 dark:border-white/[0.08] sm:px-5">
      <div className="mb-1.5 flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-[13px] font-semibold text-zinc-900 dark:text-white">{ticket.subject}</p>
          <p className="mt-0.5 text-[11px] text-zinc-400 dark:text-zinc-500">
            {formatDate(ticket.created_at)}
            {ticket.reference && <> · Ref: {ticket.reference}</>}
          </p>
        </div>
        <StatusBadge status={ticket.status} />
      </div>
      <p className="whitespace-pre-wrap text-[12.5px] leading-relaxed text-zinc-600 dark:text-zinc-300">{ticket.message}</p>

      {ticket.admin_response && (
        <div className="mt-3 rounded-lg border border-zinc-200 bg-zinc-50 px-3 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
          <p className="mb-1 text-[11px] font-semibold text-zinc-500 dark:text-zinc-400">Support Team</p>
          <p className="whitespace-pre-wrap text-[12.5px] leading-relaxed text-zinc-700 dark:text-zinc-200">
            {ticket.admin_response}
          </p>
          {ticket.responded_at && (
            <p className="mt-1.5 text-[10.5px] text-zinc-400 dark:text-zinc-500">{formatDate(ticket.responded_at)}</p>
          )}
        </div>
      )}
    </div>
  );
}

export default function Support() {
  const [tickets, setTickets] = useState<TicketApi[]>([]);
  const [loadingTickets, setLoadingTickets] = useState(true);
  const [loadError, setLoadError] = useState('');

  const [subject, setSubject] = useState<TicketSubject>(TICKET_SUBJECTS[0]);
  const [message, setMessage] = useState('');
  const [reference, setReference] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  function load() {
    setLoadingTickets(true);
    setLoadError('');
    getMyTickets()
      .then(setTickets)
      .catch((err) => setLoadError(err instanceof ApiError ? err.message : 'Failed to load your tickets.'))
      .finally(() => setLoadingTickets(false));
  }

  useEffect(load, []);

  const trimmedMessage = message.trim();
  const canSubmit = trimmedMessage.length > 0 && trimmedMessage.length <= MAX_MESSAGE_LENGTH && !submitting;

  async function handleSubmit() {
    if (!canSubmit) return;
    setSubmitting(true);
    setSubmitError('');
    try {
      await submitTicket({
        subject,
        message: trimmedMessage,
        reference: reference.trim() || undefined,
      });
      setMessage('');
      setReference('');
      setSubject(TICKET_SUBJECTS[0]);
      load(); // refresh history so the new ticket shows up immediately
    } catch (err) {
      setSubmitError(err instanceof ApiError ? err.message : 'Could not submit your ticket. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <DashboardLayout title="Support" subtitle="Get help or browse frequently asked questions.">
      <div className="mx-auto max-w-2xl space-y-4">
        {/* FAQs — answers real questions about how this app's own flows actually work
            (KYC gate, deposit crediting, NGN withdrawal destination, rejections),
            not generic exchange boilerplate. */}
        <Card className="!p-0">
          <div className="flex items-center gap-2 border-b border-zinc-200 px-4 py-3.5 dark:border-white/[0.08] sm:px-5">
            <HelpCircle size={15} className="text-zinc-400" />
            <p className="text-[13px] font-semibold text-zinc-900 dark:text-white">Frequently Asked Questions</p>
          </div>
          <div className="divide-y divide-zinc-100 dark:divide-white/[0.06]">
            {FAQS.map((f, i) => (
              <div key={f.q}>
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="flex w-full items-center justify-between gap-3 px-4 py-3.5 text-left text-[12.5px] font-medium text-zinc-800 hover:bg-zinc-50 dark:text-zinc-100 dark:hover:bg-white/[0.03] sm:px-5"
                >
                  {f.q}
                  <span className={`shrink-0 text-zinc-400 transition-transform ${openFaq === i ? 'rotate-45' : ''}`}>+</span>
                </button>
                {openFaq === i && (
                  <p className="px-4 pb-4 text-[12.5px] leading-relaxed text-zinc-500 dark:text-zinc-400 sm:px-5">
                    {f.a}
                  </p>
                )}
              </div>
            ))}
          </div>
        </Card>

        {/* Ticket submission */}
        <Card>
          <div className="mb-4 flex items-center gap-2">
            <Mail size={15} className="text-zinc-400" />
            <p className="text-[13px] font-semibold text-zinc-900 dark:text-white">Contact Support</p>
          </div>

          <label className="mb-1.5 block text-[13px] font-medium text-zinc-700 dark:text-zinc-300">What's this about?</label>
          <select
            value={subject}
            onChange={(e) => setSubject(e.target.value as TicketSubject)}
            className="mb-4 h-[42px] w-full rounded-lg border border-zinc-200 bg-zinc-50 px-3.5 text-[13.5px] text-zinc-900 outline-none focus:border-brand-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-white"
          >
            {TICKET_SUBJECTS.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>

          {(subject === 'Deposit issue' || subject === 'Withdrawal issue' || subject === 'Buy / Sell issue') && (
            <div className="mb-4">
              <label htmlFor="reference" className="mb-1.5 block text-[13px] font-medium text-zinc-700 dark:text-zinc-300">
                Reference <span className="font-normal text-zinc-400">(optional)</span>
              </label>
              <input
                id="reference"
                value={reference}
                onChange={(e) => setReference(e.target.value)}
                placeholder="Transaction ID, TxID, or reference number if you have one"
                className="h-[42px] w-full rounded-lg border border-zinc-200 bg-zinc-50 px-3.5 text-[13.5px] text-zinc-900 outline-none focus:border-brand-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-white dark:placeholder:text-zinc-500"
              />
            </div>
          )}

          <div className="mb-1.5 flex items-center justify-between">
            <label htmlFor="message" className="text-[13px] font-medium text-zinc-700 dark:text-zinc-300">Message</label>
            <span className={`text-[11px] ${trimmedMessage.length > MAX_MESSAGE_LENGTH ? 'text-down-500' : 'text-zinc-400 dark:text-zinc-500'}`}>
              {trimmedMessage.length}/{MAX_MESSAGE_LENGTH}
            </span>
          </div>
          <textarea
            id="message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={5}
            placeholder="Tell us what's going on — the more detail, the faster we can help."
            className="mb-4 w-full resize-none rounded-lg border border-zinc-200 bg-zinc-50 px-3.5 py-3 text-[13.5px] text-zinc-900 outline-none focus:border-brand-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-white dark:placeholder:text-zinc-500"
          />

          {submitError && (
            <p className="mb-3 rounded-lg border border-down-500/30 bg-down-500/5 px-3 py-2 text-[12px] text-down-600 dark:text-down-500">
              {submitError}
            </p>
          )}

          <Button fullWidth size="lg" onClick={handleSubmit} disabled={!canSubmit}>
            {submitting ? (
              <>
                <Loader2 size={15} className="animate-spin" /> Sending…
              </>
            ) : (
              <>
                <Send size={15} /> Submit Ticket
              </>
            )}
          </Button>
        </Card>

        {/* History */}
        <Card className="!p-0">
          <div className="border-b border-zinc-200 px-4 py-3.5 dark:border-white/[0.08] sm:px-5">
            <p className="text-[13px] font-semibold text-zinc-900 dark:text-white">Your Tickets</p>
          </div>

          {loadingTickets ? (
            <div className="flex items-center justify-center gap-2 px-5 py-10 text-[13px] text-zinc-400 dark:text-zinc-500">
              <Loader2 size={16} className="animate-spin" /> Loading…
            </div>
          ) : loadError ? (
            <p className="px-5 py-8 text-center text-[13px] text-down-600 dark:text-down-500">{loadError}</p>
          ) : tickets.length === 0 ? (
            <p className="px-5 py-10 text-center text-[13px] text-zinc-400 dark:text-zinc-500">
              No tickets yet — submit one above and it'll show up here.
            </p>
          ) : (
            <div>
              {tickets.map((t) => (
                <TicketCard key={t.id} ticket={t} />
              ))}
            </div>
          )}
        </Card>

        <p className="text-center text-[11.5px] text-zinc-400 dark:text-zinc-500">
          Live chat isn't available yet — tickets are the fastest way to reach us for now. You'll also see a{' '}
          <Link to="/notifications" className="text-brand-600 dark:text-brand-400">notification</Link> when we reply.
        </p>
      </div>
    </DashboardLayout>
  );
}
