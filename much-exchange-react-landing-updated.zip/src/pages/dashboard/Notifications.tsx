import { Bell } from 'lucide-react';
import DashboardLayout from '../../components/dashboard/DashboardLayout';
import Card from '../../components/ui/Card';
import { notifications } from '../../data/activityMock';

export default function Notifications() {
  return (
    <DashboardLayout title="Notifications" subtitle="Stay updated with your activities.">
      <div className="mx-auto max-w-xl">
        <Card className="!p-0">
          {notifications.map((n) => (
            <div
              key={n.id}
              className="flex items-start gap-3 border-b border-zinc-200 px-5 py-4 last:border-0 dark:border-white/[0.08]"
            >
              <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-brand-500/10 text-brand-600 dark:text-brand-400">
                <Bell size={15} />
              </span>
              <div className="flex-1">
                <p className={`text-[13px] ${n.read ? 'text-zinc-600 dark:text-zinc-300' : 'font-semibold text-zinc-900 dark:text-white'}`}>
                  {n.title}
                </p>
                <p className="mt-0.5 text-[11.5px] text-zinc-400 dark:text-zinc-500">{n.timestamp}</p>
              </div>
              {!n.read && <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-brand-500" />}
            </div>
          ))}
        </Card>
      </div>
    </DashboardLayout>
  );
}
