import { useEffect, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { Loader2, CheckCircle2, Lock, Info } from 'lucide-react';
import DashboardLayout from '../../components/dashboard/DashboardLayout';
import Card from '../../components/ui/Card';
import Field from '../../components/ui/Field';
import Button from '../../components/ui/Button';
import {
  getProfile,
  getSettings,
  updateSettings,
  changePassword,
  KYC_STATUS_LABEL,
  type ProfileApi,
  type SettingsApi,
} from '../../lib/profileApi';
import { ApiError } from '../../lib/api';

const SECTIONS = ['Security', 'Preferences', 'Change Password', 'Two-Factor Auth', 'Sessions'] as const;
type Section = (typeof SECTIONS)[number];

/** Minimum the backend's ChangePasswordRequest schema enforces (min_length=8). */
const MIN_PASSWORD_LENGTH = 8;

function Toggle({
  checked,
  onChange,
  disabled,
  label,
}: {
  checked: boolean;
  onChange: () => void;
  disabled?: boolean;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onChange}
      disabled={disabled}
      role="switch"
      aria-checked={checked}
      aria-label={label}
      className={`relative h-6 w-11 shrink-0 rounded-full transition-colors disabled:cursor-not-allowed disabled:opacity-50 ${
        checked ? 'bg-brand-500' : 'bg-zinc-300 dark:bg-white/15'
      }`}
    >
      <span
        className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${
          checked ? 'translate-x-[22px]' : 'translate-x-0.5'
        }`}
      />
    </button>
  );
}

function Row({
  title,
  description,
  children,
  bordered = true,
}: {
  title: string;
  description?: string;
  children?: ReactNode;
  bordered?: boolean;
}) {
  return (
    <div
      className={`flex items-center justify-between gap-4 ${
        bordered ? 'border-b border-zinc-200 pb-4 dark:border-white/[0.08]' : ''
      }`}
    >
      <div className="min-w-0">
        <p className="text-[13.5px] font-semibold text-zinc-900 dark:text-white">{title}</p>
        {description && <p className="mt-0.5 text-[12px] text-zinc-500 dark:text-zinc-400">{description}</p>}
      </div>
      {children}
    </div>
  );
}

/** Used for the two features whose backend support doesn't exist yet. */
function NotAvailableYet({ title, body }: { title: string; body: string }) {
  return (
    <div className="flex flex-col items-center py-8 text-center">
      <Info size={32} className="mb-3 text-zinc-400 dark:text-zinc-500" />
      <h3 className="text-[14px] font-semibold text-zinc-900 dark:text-white">{title}</h3>
      <p className="mt-1.5 max-w-sm text-[12.5px] leading-relaxed text-zinc-500 dark:text-zinc-400">{body}</p>
    </div>
  );
}

export default function Settings() {
  const [active, setActive] = useState<Section>('Security');

  const [profile, setProfile] = useState<ProfileApi | null>(null);
  const [settings, setSettings] = useState<SettingsApi | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');

  const [savingKey, setSavingKey] = useState<keyof SettingsApi | null>(null);
  const [settingsError, setSettingsError] = useState('');

  // Change password form
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [changingPassword, setChangingPassword] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');

  useEffect(() => {
    Promise.all([getProfile(), getSettings()])
      .then(([p, s]) => {
        setProfile(p);
        setSettings(s);
      })
      .catch((err) => setLoadError(err instanceof ApiError ? err.message : 'Failed to load your settings.'))
      .finally(() => setLoading(false));
  }, []);

  async function toggleSetting(key: keyof SettingsApi) {
    if (!settings) return;
    const next = !settings[key];
    // Optimistic — these are cheap preference flips and reverting on error
    // is less jarring than a spinner on every toggle.
    setSettings({ ...settings, [key]: next });
    setSavingKey(key);
    setSettingsError('');
    try {
      const updated = await updateSettings({ [key]: next });
      setSettings(updated);
    } catch (err) {
      setSettings((s) => (s ? { ...s, [key]: !next } : s));
      setSettingsError(err instanceof ApiError ? err.message : 'Could not save that preference.');
    } finally {
      setSavingKey(null);
    }
  }

  const passwordTooShort = newPassword.length > 0 && newPassword.length < MIN_PASSWORD_LENGTH;
  const passwordsMismatch = confirmPassword.length > 0 && newPassword !== confirmPassword;
  const canSubmitPassword =
    currentPassword.length > 0 &&
    newPassword.length >= MIN_PASSWORD_LENGTH &&
    newPassword === confirmPassword &&
    !changingPassword;

  async function handleChangePassword() {
    if (!canSubmitPassword) return;
    setChangingPassword(true);
    setPasswordError('');
    setPasswordSuccess('');
    try {
      await changePassword(currentPassword, newPassword);
      setPasswordSuccess('Password changed successfully.');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err) {
      setPasswordError(err instanceof ApiError ? err.message : 'Could not change your password.');
    } finally {
      setChangingPassword(false);
    }
  }

  if (loading) {
    return (
      <DashboardLayout title="Settings" subtitle="Manage your account settings.">
        <div className="flex items-center justify-center gap-2 py-16 text-[13px] text-zinc-400 dark:text-zinc-500">
          <Loader2 size={16} className="animate-spin" /> Loading your settings…
        </div>
      </DashboardLayout>
    );
  }

  if (loadError || !profile || !settings) {
    return (
      <DashboardLayout title="Settings" subtitle="Manage your account settings.">
        <div className="rounded-xl border border-down-500/30 bg-down-500/5 px-4 py-3 text-[13px] text-down-600 dark:text-down-500">
          {loadError || 'Failed to load your settings.'}
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout title="Settings" subtitle="Manage your account settings.">
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[200px_1fr]">
        <Card className="!p-2 h-fit lg:block">
          <nav className="flex gap-1 overflow-x-auto lg:flex-col lg:space-y-1 lg:overflow-visible">
            {SECTIONS.map((s) => (
              <button
                key={s}
                onClick={() => setActive(s)}
                className={`block shrink-0 whitespace-nowrap rounded-lg px-3 py-2 text-left text-[13px] font-medium transition-colors lg:w-full lg:whitespace-normal ${
                  active === s
                    ? 'bg-brand-500/10 text-brand-600 dark:text-brand-400'
                    : 'text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900 dark:text-zinc-400 dark:hover:bg-white/[0.06] dark:hover:text-white'
                }`}
              >
                {s}
              </button>
            ))}
          </nav>
        </Card>

        <Card>
          {active === 'Security' && (
            <div className="space-y-5">
              <Row title="Email" description={profile.email}>
                <span className="shrink-0 text-[11.5px] text-zinc-400 dark:text-zinc-500">
                  {profile.is_verified ? 'Verified' : 'Unverified'}
                </span>
              </Row>

              <Row title="Phone Number" description={profile.phone_number || 'Not set'}>
                <Link
                  to="/profile"
                  className="shrink-0 text-[12.5px] font-semibold text-brand-600 dark:text-brand-400"
                >
                  Change
                </Link>
              </Row>

              <Row title="Identity Verification" description={KYC_STATUS_LABEL[profile.kyc_status]}>
                {profile.kyc_status !== 'approved' && profile.kyc_status !== 'pending' && (
                  <Link
                    to="/kyc"
                    className="shrink-0 text-[12.5px] font-semibold text-brand-600 dark:text-brand-400"
                  >
                    Verify
                  </Link>
                )}
              </Row>

              <Row title="Password" description="Change the password you use to sign in." bordered={false}>
                <button
                  onClick={() => setActive('Change Password')}
                  className="shrink-0 text-[12.5px] font-semibold text-brand-600 dark:text-brand-400"
                >
                  Change
                </button>
              </Row>
            </div>
          )}

          {active === 'Preferences' && (
            <div className="space-y-5">
              {settingsError && (
                <p className="rounded-lg border border-down-500/30 bg-down-500/5 px-3 py-2 text-[12px] text-down-600 dark:text-down-500">
                  {settingsError}
                </p>
              )}

              <Row
                title="Email Notifications"
                description="Get an email when a deposit, withdrawal or trade is approved."
              >
                <div className="flex items-center gap-2">
                  {savingKey === 'email_notifications_enabled' && (
                    <Loader2 size={13} className="animate-spin text-zinc-400" />
                  )}
                  <Toggle
                    checked={settings.email_notifications_enabled}
                    onChange={() => toggleSetting('email_notifications_enabled')}
                    disabled={savingKey !== null}
                    label="Toggle email notifications"
                  />
                </div>
              </Row>

              {/* There is no SMS provider wired into the backend at all, so an
                  enabled-looking toggle here would promise messages that can
                  never arrive. Kept visible (the column exists and is part of
                  the intended product) but clearly marked. */}
              <Row
                title="SMS Notifications"
                description="Not available yet — SMS delivery hasn't been set up."
                bordered={false}
              >
                <Toggle checked={false} onChange={() => {}} disabled label="SMS notifications unavailable" />
              </Row>

              <p className="!mt-4 text-[11.5px] leading-relaxed text-zinc-400 dark:text-zinc-500">
                In-app notifications are always on — you can see them any time on the{' '}
                <Link to="/notifications" className="text-brand-600 dark:text-brand-400">
                  Notifications
                </Link>{' '}
                page.
              </p>
            </div>
          )}

          {active === 'Change Password' && (
            <div className="max-w-sm">
              <Field
                id="currentPassword"
                label="Current Password"
                type="password"
                autoComplete="current-password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
              />
              <Field
                id="newPassword"
                label="New Password"
                type="password"
                autoComplete="new-password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                error={passwordTooShort ? `Must be at least ${MIN_PASSWORD_LENGTH} characters.` : undefined}
                hint={!passwordTooShort ? `At least ${MIN_PASSWORD_LENGTH} characters.` : undefined}
              />
              <Field
                id="confirmPassword"
                label="Confirm New Password"
                type="password"
                autoComplete="new-password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                error={passwordsMismatch ? "Passwords don't match." : undefined}
              />

              {passwordError && (
                <p className="mb-3 rounded-lg border border-down-500/30 bg-down-500/5 px-3 py-2 text-[12px] text-down-600 dark:text-down-500">
                  {passwordError}
                </p>
              )}
              {passwordSuccess && (
                <p className="mb-3 flex items-center gap-1.5 rounded-lg border border-up-500/30 bg-up-500/5 px-3 py-2 text-[12px] text-up-600 dark:text-up-500">
                  <CheckCircle2 size={13} /> {passwordSuccess}
                </p>
              )}

              <Button fullWidth onClick={handleChangePassword} disabled={!canSubmitPassword}>
                {changingPassword ? (
                  <>
                    <Loader2 size={15} className="animate-spin" /> Updating…
                  </>
                ) : (
                  <>
                    <Lock size={15} /> Update Password
                  </>
                )}
              </Button>

              <p className="mt-3 text-[11.5px] leading-relaxed text-zinc-400 dark:text-zinc-500">
                You'll stay signed in on this device after changing your password.
              </p>
            </div>
          )}

          {active === 'Two-Factor Auth' && (
            <NotAvailableYet
              title="Two-factor authentication isn't available yet"
              body="We're still building this. Rather than show a switch that stores a preference without actually protecting your account at sign-in, we've left it off until the real thing ships. Your account is secured by your password — use a strong, unique one and change it from the Change Password tab if you ever suspect it's been exposed."
            />
          )}

          {active === 'Sessions' && (
            <NotAvailableYet
              title="Sign-in activity isn't available yet"
              body="Login history, active devices and recent IP addresses aren't tracked yet, so there's nothing accurate to show here. If you think someone else has access to your account, change your password now from the Change Password tab and contact support."
            />
          )}
        </Card>
      </div>
    </DashboardLayout>
  );
}
