import { useEffect, useMemo, useState } from 'react';
import { Loader2, CheckCircle2 } from 'lucide-react';
import DashboardLayout from '../../components/dashboard/DashboardLayout';
import Card from '../../components/ui/Card';
import Field from '../../components/ui/Field';
import Button from '../../components/ui/Button';
import {
  getGiftCardCatalog,
  getGiftCardRates,
  buyGiftCard,
  submitGiftCardForSale,
  brandColor,
  type GiftCardCatalogEntryApi,
  type GiftCardRateApi,
} from '../../lib/giftCardsApi';
import { apiRequest, ApiError } from '../../lib/api';

type Tab = 'buy' | 'sell';

interface WalletOut {
  currency: string;
  available_balance: string;
}

function formatNgn(value: number) {
  return `₦${value.toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export default function GiftCards() {
  const [tab, setTab] = useState<Tab>('buy');
  const [ngnBalance, setNgnBalance] = useState<number | null>(null);

  useEffect(() => {
    apiRequest<WalletOut[]>('/wallets/me', { auth: 'customer' })
      .then((wallets) => {
        const ngn = wallets.find((w) => w.currency === 'NGN');
        setNgnBalance(ngn ? Number(ngn.available_balance) : 0);
      })
      .catch(() => setNgnBalance(null));
  }, []);

  return (
    <DashboardLayout title="Gift Cards" subtitle="Buy or sell gift cards for instant Naira value.">
      <div className="mx-auto max-w-xl">
        <Card>
          <div className="mb-5 flex gap-1 rounded-lg bg-zinc-100 p-1 dark:bg-white/[0.05]">
            <button
              onClick={() => setTab('buy')}
              className={`flex-1 rounded-md py-2 text-[13px] font-semibold transition-colors ${
                tab === 'buy'
                  ? 'bg-gradient-to-b from-brand-400 to-brand-500 text-zinc-900'
                  : 'text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-white'
              }`}
            >
              Buy Gift Card
            </button>
            <button
              onClick={() => setTab('sell')}
              className={`flex-1 rounded-md py-2 text-[13px] font-semibold transition-colors ${
                tab === 'sell'
                  ? 'bg-gradient-to-b from-brand-400 to-brand-500 text-zinc-900'
                  : 'text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-white'
              }`}
            >
              Sell Gift Card
            </button>
          </div>

          {tab === 'buy' ? <BuyTab ngnBalance={ngnBalance} /> : <SellTab />}
        </Card>
      </div>
    </DashboardLayout>
  );
}

function BuyTab({ ngnBalance }: { ngnBalance: number | null }) {
  const [catalog, setCatalog] = useState<GiftCardCatalogEntryApi[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [selectedBrand, setSelectedBrand] = useState<string | null>(null);
  const [selectedEntry, setSelectedEntry] = useState<GiftCardCatalogEntryApi | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [result, setResult] = useState<{ codes: string[] } | null>(null);

  useEffect(() => {
    getGiftCardCatalog()
      .then((entries) => {
        setCatalog(entries);
        if (entries.length > 0) {
          setSelectedBrand(entries[0].brand);
          setSelectedEntry(entries[0]);
        }
      })
      .catch((err) => setLoadError(err instanceof ApiError ? err.message : 'Could not load available gift cards.'))
      .finally(() => setLoading(false));
  }, []);

  const brands = useMemo(() => [...new Set(catalog.map((e) => e.brand))], [catalog]);
  const denomsForBrand = useMemo(
    () => catalog.filter((e) => e.brand === selectedBrand),
    [catalog, selectedBrand],
  );

  const unitPrice = selectedEntry ? Number(selectedEntry.price_ngn) : 0;
  const total = unitPrice * quantity;
  const insufficientFunds = ngnBalance !== null && total > ngnBalance;
  const exceedsStock = selectedEntry ? quantity > selectedEntry.quantity_available : false;

  async function handleBuy() {
    if (!selectedEntry) return;
    setSubmitting(true);
    setSubmitError('');
    setResult(null);
    const codes: string[] = [];
    try {
      for (let i = 0; i < quantity; i++) {
        const purchase = await buyGiftCard({
          brand: selectedEntry.brand,
          card_type: selectedEntry.card_type,
          card_country: selectedEntry.card_country,
          card_currency: selectedEntry.card_currency,
          card_denomination: Number(selectedEntry.card_denomination),
        });
        if (purchase.delivered_code) codes.push(purchase.delivered_code);
      }
      setResult({ codes });
      const refreshed = await getGiftCardCatalog();
      setCatalog(refreshed);
    } catch (err) {
      setSubmitError(err instanceof ApiError ? err.message : 'Purchase failed. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center gap-2 py-12 text-[13px] text-zinc-400 dark:text-zinc-500">
        <Loader2 size={16} className="animate-spin" /> Loading available gift cards…
      </div>
    );
  }

  if (loadError) {
    return <p className="py-8 text-center text-[13px] text-down-500">{loadError}</p>;
  }

  if (catalog.length === 0) {
    return (
      <p className="py-8 text-center text-[13px] text-zinc-400 dark:text-zinc-500">
        No gift cards are available to buy right now — check back soon.
      </p>
    );
  }

  if (result) {
    return (
      <div className="py-4">
        <div className="mb-4 flex flex-col items-center text-center">
          <CheckCircle2 size={40} className="mb-2 text-up-500" />
          <p className="text-[15px] font-semibold text-zinc-900 dark:text-white">Purchase complete</p>
          <p className="text-[12.5px] text-zinc-500 dark:text-zinc-400">
            {result.codes.length} code{result.codes.length !== 1 ? 's' : ''} delivered below.
          </p>
        </div>
        <div className="space-y-2">
          {result.codes.map((code, i) => (
            <div key={i} className="flex items-center justify-between rounded-xl border border-zinc-200 px-3.5 py-2.5 dark:border-white/10">
              <span className="font-mono text-[13px] font-semibold text-zinc-800 dark:text-zinc-100">{code}</span>
              <button
                onClick={() => navigator.clipboard?.writeText(code)}
                className="text-[11.5px] font-medium text-brand-600 hover:text-brand-500"
              >
                Copy
              </button>
            </div>
          ))}
        </div>
        <Button fullWidth size="lg" className="mt-5" onClick={() => setResult(null)}>
          Buy Another
        </Button>
      </div>
    );
  }

  return (
    <>
      <p className="mb-2 text-[12.5px] font-medium text-zinc-500 dark:text-zinc-400">Select Brand</p>
      <div className="mb-4 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
        {brands.map((brand) => {
          const active = brand === selectedBrand;
          return (
            <button
              key={brand}
              type="button"
              onClick={() => {
                setSelectedBrand(brand);
                const first = catalog.find((e) => e.brand === brand) ?? null;
                setSelectedEntry(first);
              }}
              className={`flex flex-col items-center gap-2 rounded-xl border px-3 py-3.5 transition-colors ${
                active ? 'border-brand-500 bg-brand-500/10' : 'border-zinc-200 hover:bg-zinc-50 dark:border-white/10 dark:hover:bg-white/[0.04]'
              }`}
            >
              <span
                className="flex h-9 w-9 items-center justify-center rounded-full text-[13px] font-bold text-white"
                style={{ backgroundColor: brandColor(brand) }}
              >
                {brand.charAt(0).toUpperCase()}
              </span>
              <span className="text-[12px] font-medium text-zinc-700 dark:text-zinc-200">{brand}</span>
            </button>
          );
        })}
      </div>

      <p className="mb-2 text-[12.5px] font-medium text-zinc-500 dark:text-zinc-400">Card Value</p>
      <div className="mb-4 flex flex-wrap gap-2">
        {denomsForBrand.map((entry) => (
          <button
            key={`${entry.card_type}-${entry.card_country}-${entry.card_denomination}`}
            onClick={() => setSelectedEntry(entry)}
            className={`rounded-lg border px-4 py-2 text-[13px] font-semibold transition-colors ${
              selectedEntry === entry
                ? 'border-brand-500 bg-brand-500/10 text-brand-600 dark:text-brand-400'
                : 'border-zinc-200 text-zinc-600 hover:bg-zinc-50 dark:border-white/10 dark:text-zinc-300 dark:hover:bg-white/[0.04]'
            }`}
          >
            {entry.card_currency}{Number(entry.card_denomination).toLocaleString()}
            <span className="ml-1 text-[10.5px] font-normal text-zinc-400">({entry.quantity_available} left)</span>
          </button>
        ))}
      </div>

      <Field
        id="quantity"
        label="Quantity"
        type="number"
        min={1}
        max={selectedEntry?.quantity_available ?? 1}
        value={quantity}
        onChange={(e) => setQuantity(Math.max(1, Number(e.target.value)))}
      />

      {selectedEntry && (
        <div className="mb-3 space-y-2 rounded-xl border border-zinc-200 p-4 text-[12.5px] dark:border-white/[0.08]">
          <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
            <span>Rate</span>
            <span className="font-mono text-zinc-700 dark:text-zinc-200">₦{Number(selectedEntry.sell_rate_ngn).toLocaleString()} / {selectedEntry.card_currency}1</span>
          </div>
          <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
            <span>Unit Price</span>
            <span className="font-mono text-zinc-700 dark:text-zinc-200">{formatNgn(unitPrice)}</span>
          </div>
          <div className="flex justify-between border-t border-zinc-200 pt-2 font-semibold text-zinc-900 dark:border-white/[0.08] dark:text-white">
            <span>Total</span>
            <span className="font-mono">{formatNgn(total)}</span>
          </div>
          {ngnBalance !== null && (
            <div className="flex justify-between text-[11.5px] text-zinc-400 dark:text-zinc-500">
              <span>Wallet balance</span>
              <span className="font-mono">{formatNgn(ngnBalance)}</span>
            </div>
          )}
        </div>
      )}

      {insufficientFunds && (
        <p className="mb-3 text-[12.5px] font-medium text-down-500">Insufficient wallet balance for this purchase.</p>
      )}
      {exceedsStock && (
        <p className="mb-3 text-[12.5px] font-medium text-down-500">Only {selectedEntry?.quantity_available} left in stock.</p>
      )}
      {submitError && <p className="mb-3 text-[12.5px] font-medium text-down-500">{submitError}</p>}

      <Button
        fullWidth
        size="lg"
        disabled={!selectedEntry || submitting || insufficientFunds || exceedsStock}
        onClick={handleBuy}
      >
        {submitting ? 'Processing…' : 'Buy Now'}
      </Button>
    </>
  );
}

function SellTab() {
  const [rates, setRates] = useState<GiftCardRateApi[]>([]);
  const [loading, setLoading] = useState(true);
  const [brand, setBrand] = useState<string | null>(null);
  const [cardType, setCardType] = useState<'e-code' | 'physical'>('e-code');
  const [country, setCountry] = useState('US');
  const [currency, setCurrency] = useState('USD');
  const [amount, setAmount] = useState('');
  const [code, setCode] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'bank_transfer' | 'wallet_balance'>('bank_transfer');
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    getGiftCardRates()
      .then((r) => {
        const sellable = r.filter((rate) => Number(rate.buy_rate_ngn) > 0);
        setRates(sellable);
        if (sellable.length > 0) setBrand(sellable[0].brand);
      })
      .finally(() => setLoading(false));
  }, []);

  const selectedRate = rates.find((r) => r.brand === brand);
  const usd = Number(amount) || 0;
  const payout = selectedRate ? usd * Number(selectedRate.buy_rate_ngn) : 0;

  async function handleSubmit() {
    if (!brand) return;
    setSubmitting(true);
    setSubmitError('');
    try {
      await submitGiftCardForSale({
        brand,
        card_type: cardType,
        card_country: country,
        card_currency: currency,
        card_denomination: usd,
        redemption_code: code,
        payment_method: paymentMethod,
      });
      setSubmitted(true);
    } catch (err) {
      setSubmitError(err instanceof ApiError ? err.message : 'Submission failed. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center gap-2 py-12 text-[13px] text-zinc-400 dark:text-zinc-500">
        <Loader2 size={16} className="animate-spin" /> Loading rates…
      </div>
    );
  }

  if (rates.length === 0) {
    return (
      <p className="py-8 text-center text-[13px] text-zinc-400 dark:text-zinc-500">
        We're not buying any gift card brands right now — check back soon.
      </p>
    );
  }

  if (submitted) {
    return (
      <div className="flex flex-col items-center py-8 text-center">
        <CheckCircle2 size={40} className="mb-2 text-up-500" />
        <p className="text-[15px] font-semibold text-zinc-900 dark:text-white">Submitted for review</p>
        <p className="mt-1 max-w-xs text-[12.5px] text-zinc-500 dark:text-zinc-400">
          Our team will verify your card and pay out to your {paymentMethod === 'bank_transfer' ? 'bank account' : 'wallet'} once approved.
        </p>
        <Button
          size="lg"
          className="mt-5"
          onClick={() => {
            setSubmitted(false);
            setAmount('');
            setCode('');
          }}
        >
          Submit Another
        </Button>
      </div>
    );
  }

  return (
    <>
      <p className="mb-2 text-[12.5px] font-medium text-zinc-500 dark:text-zinc-400">Select Brand</p>
      <div className="mb-4 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
        {rates.map((r) => {
          const active = r.brand === brand;
          return (
            <button
              key={r.brand}
              type="button"
              onClick={() => setBrand(r.brand)}
              className={`flex flex-col items-center gap-2 rounded-xl border px-3 py-3.5 transition-colors ${
                active ? 'border-brand-500 bg-brand-500/10' : 'border-zinc-200 hover:bg-zinc-50 dark:border-white/10 dark:hover:bg-white/[0.04]'
              }`}
            >
              <span
                className="flex h-9 w-9 items-center justify-center rounded-full text-[13px] font-bold text-white"
                style={{ backgroundColor: brandColor(r.brand) }}
              >
                {r.brand.charAt(0).toUpperCase()}
              </span>
              <span className="text-[12px] font-medium text-zinc-700 dark:text-zinc-200">{r.brand}</span>
            </button>
          );
        })}
      </div>

      <p className="mb-2 text-[12.5px] font-medium text-zinc-500 dark:text-zinc-400">Card Type</p>
      <div className="mb-4 flex gap-2">
        {(['e-code', 'physical'] as const).map((type) => (
          <button
            key={type}
            onClick={() => setCardType(type)}
            className={`flex-1 rounded-lg border px-4 py-2 text-[13px] font-semibold capitalize transition-colors ${
              cardType === type
                ? 'border-brand-500 bg-brand-500/10 text-brand-600 dark:text-brand-400'
                : 'border-zinc-200 text-zinc-600 hover:bg-zinc-50 dark:border-white/10 dark:text-zinc-300 dark:hover:bg-white/[0.04]'
            }`}
          >
            {type}
          </button>
        ))}
      </div>

      <div className="mb-1 grid grid-cols-2 gap-3">
        <Field id="country" label="Card Country" type="text" placeholder="US" value={country} onChange={(e) => setCountry(e.target.value.toUpperCase().slice(0, 2))} />
        <Field id="currency" label="Card Currency" type="text" placeholder="USD" value={currency} onChange={(e) => setCurrency(e.target.value.toUpperCase().slice(0, 3))} />
      </div>

      <Field
        id="sellAmount"
        label={`Card Value (${currency})`}
        type="number"
        placeholder="Enter card value"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
      />

      <Field
        id="redemptionCode"
        label="Redemption Code"
        type="text"
        placeholder="Enter the code on the card"
        value={code}
        onChange={(e) => setCode(e.target.value)}
      />

      <p className="mb-2 mt-1 text-[12.5px] font-medium text-zinc-500 dark:text-zinc-400">Payout Method</p>
      <div className="mb-4 flex gap-2">
        {([
          { key: 'bank_transfer', label: 'Bank Transfer' },
          { key: 'wallet_balance', label: 'Wallet Balance' },
        ] as const).map((opt) => (
          <button
            key={opt.key}
            onClick={() => setPaymentMethod(opt.key)}
            className={`flex-1 rounded-lg border px-4 py-2 text-[13px] font-semibold transition-colors ${
              paymentMethod === opt.key
                ? 'border-brand-500 bg-brand-500/10 text-brand-600 dark:text-brand-400'
                : 'border-zinc-200 text-zinc-600 hover:bg-zinc-50 dark:border-white/10 dark:text-zinc-300 dark:hover:bg-white/[0.04]'
            }`}
          >
            {opt.label}
          </button>
        ))}
      </div>

      {selectedRate && (
        <div className="mb-5 space-y-2 rounded-xl border border-zinc-200 p-4 text-[12.5px] dark:border-white/[0.08]">
          <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
            <span>Rate</span>
            <span className="font-mono text-zinc-700 dark:text-zinc-200">₦{Number(selectedRate.buy_rate_ngn).toLocaleString()} / {currency}1</span>
          </div>
          <div className="flex justify-between border-t border-zinc-200 pt-2 font-semibold text-zinc-900 dark:border-white/[0.08] dark:text-white">
            <span>You'll Receive (if approved)</span>
            <span className="font-mono">{formatNgn(payout)}</span>
          </div>
          <p className="text-[11px] text-zinc-400 dark:text-zinc-500">
            Payout happens after our team verifies the card — not automatic.
          </p>
        </div>
      )}

      {submitError && <p className="mb-3 text-[12.5px] font-medium text-down-500">{submitError}</p>}

      <Button
        fullWidth
        size="lg"
        disabled={!brand || usd <= 0 || !code.trim() || !country.trim() || !currency.trim() || submitting}
        onClick={handleSubmit}
      >
        {submitting ? 'Submitting…' : 'Submit for Review'}
      </Button>
    </>
  );
}
