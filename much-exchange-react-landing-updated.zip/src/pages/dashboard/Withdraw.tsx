import { useEffect, useState } from 'react';
import { Loader2, CheckCircle2 } from 'lucide-react';
import DashboardLayout from '../../components/dashboard/DashboardLayout';
import CoinSelect from '../../components/dashboard/CoinSelect';
import StepProgress from '../../components/dashboard/StepProgress';
import Card from '../../components/ui/Card';
import Field from '../../components/ui/Field';
import Button from '../../components/ui/Button';
import { coins } from '../../data/cryptoMock';
import { apiRequest, ApiError } from '../../lib/api';
import {
  previewCryptoWithdrawal,
  submitCryptoWithdrawal,
  getMyCryptoWithdrawals,
  previewNgnWithdrawal,
  submitNgnWithdrawal,
  getMyNgnWithdrawals,
  withdrawalStatusBadgeClasses,
  withdrawalStatusLabel,
  type CryptoWithdrawalPreviewApi,
  type CryptoWithdrawalApi,
  type NGNWithdrawalPreviewApi,
  type NGNWithdrawalApi,
} from '../../lib/withdrawApi';

type Tab = 'crypto' | 'ngn';

// Backend only supports withdrawal fee config / wallets for BTC and USDT —
// same restriction the buy/sell and deposit flows apply, for the same reason.
const tradeableCoins = coins.filter((c) => c.symbol === 'BTC' || c.symbol === 'USDT');

function formatNgn(value: string | number) {
  const n = typeof value === 'string' ? Number(value) : value;
  return `₦${n.toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function formatDateTime(iso: string) {
  try {
    return new Date(iso).toLocaleString('en-US', {
      month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

export default function Withdraw() {
  const [tab, setTab] = useState<Tab>('crypto');

  return (
    <DashboardLayout title="Withdraw" subtitle="Withdraw your crypto or NGN balance.">
      <div className="mx-auto max-w-xl">
        <Card>
          <div className="mb-5 flex gap-1 rounded-lg bg-zinc-100 p-1 dark:bg-white/[0.05]">
            <button
              onClick={() => setTab('crypto')}
              className={`flex-1 rounded-md py-2 text-[13px] font-semibold transition-colors ${
                tab === 'crypto'
                  ? 'bg-gradient-to-b from-brand-400 to-brand-500 text-zinc-900'
                  : 'text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-white'
              }`}
            >
              Crypto Withdrawal
            </button>
            <button
              onClick={() => setTab('ngn')}
              className={`flex-1 rounded-md py-2 text-[13px] font-semibold transition-colors ${
                tab === 'ngn'
                  ? 'bg-gradient-to-b from-brand-400 to-brand-500 text-zinc-900'
                  : 'text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-white'
              }`}
            >
              NGN Withdrawal
            </button>
          </div>

          {tab === 'crypto' ? <CryptoWithdrawTab /> : <NgnWithdrawTab />}
        </Card>
      </div>
    </DashboardLayout>
  );
}

// --- Crypto withdrawal tab ---

type Step = 'amount' | 'preview' | 'success';

function CryptoWithdrawTab() {
  const [coinId, setCoinId] = useState(tradeableCoins[0].id);
  const coin = tradeableCoins.find((c) => c.id === coinId)!;

  const [address, setAddress] = useState('');
  const [amount, setAmount] = useState('');

  const [step, setStep] = useState<Step>('amount');
  const [preview, setPreview] = useState<CryptoWithdrawalPreviewApi | null>(null);
  const [placed, setPlaced] = useState<CryptoWithdrawalApi | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const [history, setHistory] = useState<CryptoWithdrawalApi[]>([]);
  const [historyLoading, setHistoryLoading] = useState(true);

  useEffect(() => {
    loadHistory();
  }, []);

  function loadHistory() {
    setHistoryLoading(true);
    getMyCryptoWithdrawals()
      .then(setHistory)
      .catch(() => setHistory([]))
      .finally(() => setHistoryLoading(false));
  }

  async function handlePreview() {
    setError('');
    setBusy(true);
    try {
      const result = await previewCryptoWithdrawal({
        currency: coin.symbol as 'BTC' | 'USDT',
        amount,
        destination_address: address.trim(),
      });
      setPreview(result);
      setStep('preview');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to get a preview. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  async function handleConfirm() {
    setError('');
    setBusy(true);
    try {
      const withdrawal = await submitCryptoWithdrawal({
        currency: coin.symbol as 'BTC' | 'USDT',
        amount,
        destination_address: address.trim(),
      });
      setPlaced(withdrawal);
      setStep('success');
      loadHistory();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to submit your withdrawal. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  function reset() {
    setStep('amount');
    setAmount('');
    setAddress('');
    setPreview(null);
    setPlaced(null);
    setError('');
  }

  if (step === 'success' && placed) {
    return (
      <>
        <div className="flex flex-col items-center py-10 text-center">
          <CheckCircle2 size={40} className="mb-3 text-up-500" />
          <h3 className="text-[15px] font-semibold text-zinc-900 dark:text-white">Withdrawal requested</h3>
          <p className="mt-1.5 max-w-xs text-[13px] text-zinc-500 dark:text-zinc-400">
            {placed.amount} {placed.currency} has been reserved from your balance. You'll receive{' '}
            {placed.net_amount} {placed.currency} at {placed.destination_address.slice(0, 10)}… once an admin
            reviews and sends it.
          </p>
          <Button className="mt-6" onClick={reset}>Request Another Withdrawal</Button>
        </div>
        <WithdrawalHistory
          title="Crypto Withdrawal History"
          loading={historyLoading}
          rows={history.map((w) => ({
            id: w.id,
            label: `${w.amount} ${w.currency}`,
            sub: withdrawalSubline(w),
            status: w.status,
            date: formatDateTime(w.created_at),
          }))}
        />
      </>
    );
  }

  return (
    <>
      <StepProgress steps={['Enter Amount', 'Preview', 'Confirm']} activeIndex={step === 'amount' ? 0 : 1} />

      {step === 'amount' && (
        <>
          <CoinSelect selectedId={coinId} coins={tradeableCoins} onSelect={(c) => { setCoinId(c.id); setError(''); }} />

          <Field
            id="withdrawAddress"
            label="Wallet Address"
            placeholder={`Enter ${coin.symbol} address`}
            value={address}
            onChange={(e) => setAddress(e.target.value)}
          />

          <Field
            id="withdrawAmount"
            label="Amount"
            type="number"
            placeholder="0.00"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            rightSlot={<span className="pr-3.5 text-[12.5px] font-semibold text-zinc-500 dark:text-zinc-400">{coin.symbol}</span>}
          />

          {error && <p className="mb-4 text-[12.5px] text-down-500">{error}</p>}

          <Button
            fullWidth
            size="lg"
            disabled={!(Number(amount) > 0) || !address.trim() || busy}
            onClick={handlePreview}
          >
            {busy ? <Loader2 size={16} className="animate-spin" /> : 'Preview Withdrawal'}
          </Button>
        </>
      )}

      {step === 'preview' && preview && (
        <>
          <div className="mb-5 space-y-2 rounded-xl border border-zinc-200 p-4 text-[12.5px] dark:border-white/[0.08]">
            <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
              <span>Wallet Balance</span>
              <span className="font-mono text-zinc-700 dark:text-zinc-200">{preview.wallet_balance} {preview.currency}</span>
            </div>
            <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
              <span>Amount</span>
              <span className="font-mono text-zinc-700 dark:text-zinc-200">{preview.amount} {preview.currency}</span>
            </div>
            <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
              <span>Network Fee</span>
              <span className="font-mono text-zinc-700 dark:text-zinc-200">{preview.network_fee_amount} {preview.currency}</span>
            </div>
            <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
              <span>Service Fee</span>
              <span className="font-mono text-zinc-700 dark:text-zinc-200">{preview.service_fee_amount} {preview.currency}</span>
            </div>
            <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
              <span>Destination</span>
              <span className="max-w-[60%] truncate font-mono text-zinc-700 dark:text-zinc-200">{preview.destination_address}</span>
            </div>
            <div className="flex justify-between border-t border-zinc-200 pt-2 font-semibold text-zinc-900 dark:border-white/[0.08] dark:text-white">
              <span>You Will Receive</span>
              <span className="font-mono">{preview.net_amount} {preview.currency}</span>
            </div>
          </div>

          {error && <p className="mb-4 text-[12.5px] text-down-500">{error}</p>}

          <div className="flex gap-3">
            <Button variant="secondary" fullWidth size="lg" disabled={busy} onClick={() => setStep('amount')}>
              Back
            </Button>
            <Button fullWidth size="lg" disabled={busy} onClick={handleConfirm}>
              {busy ? <Loader2 size={16} className="animate-spin" /> : 'Confirm Withdrawal'}
            </Button>
          </div>
        </>
      )}

      <WithdrawalHistory
        title="Crypto Withdrawal History"
        loading={historyLoading}
        rows={history.map((w) => ({
          id: w.id,
          label: `${w.amount} ${w.currency}`,
          sub: withdrawalSubline(w),
          status: w.status,
          date: formatDateTime(w.created_at),
        }))}
      />
    </>
  );
}

function withdrawalSubline(w: CryptoWithdrawalApi): string {
  if (w.status === 'completed' && w.admin_tx_hash) return `TxID: ${w.admin_tx_hash.slice(0, 14)}…`;
  if (w.status === 'rejected' && w.rejection_reason) return `Rejected: ${w.rejection_reason}`;
  return `To ${w.destination_address.slice(0, 10)}…`;
}

// --- NGN withdrawal tab ---

interface BankAccountInfo {
  bank_name: string | null;
  account_number: string | null;
  account_name: string | null;
}

function NgnWithdrawTab() {
  const [bankAccount, setBankAccount] = useState<BankAccountInfo | null>(null);
  const [bankAccountLoading, setBankAccountLoading] = useState(true);

  const [amount, setAmount] = useState('');
  const [step, setStep] = useState<Step>('amount');
  const [preview, setPreview] = useState<NGNWithdrawalPreviewApi | null>(null);
  const [placed, setPlaced] = useState<NGNWithdrawalApi | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const [history, setHistory] = useState<NGNWithdrawalApi[]>([]);
  const [historyLoading, setHistoryLoading] = useState(true);

  useEffect(() => {
    apiRequest<BankAccountInfo>('/auth/me', { auth: 'customer' })
      .then(setBankAccount)
      .catch(() => setBankAccount(null))
      .finally(() => setBankAccountLoading(false));
    loadHistory();
  }, []);

  function loadHistory() {
    setHistoryLoading(true);
    getMyNgnWithdrawals()
      .then(setHistory)
      .catch(() => setHistory([]))
      .finally(() => setHistoryLoading(false));
  }

  const hasBankAccount = !!(bankAccount?.bank_name && bankAccount?.account_number && bankAccount?.account_name);

  async function handlePreview() {
    setError('');
    setBusy(true);
    try {
      const result = await previewNgnWithdrawal(amount);
      setPreview(result);
      setStep('preview');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to get a preview. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  async function handleConfirm() {
    setError('');
    setBusy(true);
    try {
      const withdrawal = await submitNgnWithdrawal(amount);
      setPlaced(withdrawal);
      setStep('success');
      loadHistory();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to submit your withdrawal. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  function reset() {
    setStep('amount');
    setAmount('');
    setPreview(null);
    setPlaced(null);
    setError('');
  }

  if (bankAccountLoading) {
    return (
      <div className="flex items-center justify-center gap-2 py-12 text-[13px] text-zinc-400 dark:text-zinc-500">
        <Loader2 size={16} className="animate-spin" /> Loading your account…
      </div>
    );
  }

  if (!hasBankAccount) {
    return (
      <div className="rounded-xl border border-zinc-200 p-6 text-center dark:border-white/[0.08]">
        <p className="mb-1 text-[13.5px] font-semibold text-zinc-900 dark:text-white">No bank account on file</p>
        <p className="text-[12.5px] text-zinc-500 dark:text-zinc-400">
          We couldn't find a bank account for your account. Please contact support to add one before requesting an
          NGN withdrawal.
        </p>
      </div>
    );
  }

  if (step === 'success' && placed) {
    return (
      <>
        <div className="flex flex-col items-center py-10 text-center">
          <CheckCircle2 size={40} className="mb-3 text-up-500" />
          <h3 className="text-[15px] font-semibold text-zinc-900 dark:text-white">Withdrawal requested</h3>
          <p className="mt-1.5 max-w-xs text-[13px] text-zinc-500 dark:text-zinc-400">
            {formatNgn(placed.amount)} has been reserved from your NGN balance. You'll receive{' '}
            {formatNgn(placed.net_amount)} at {placed.destination_bank_name} •••{placed.destination_account_number.slice(-4)}{' '}
            once an admin approves it.
          </p>
          <Button className="mt-6" onClick={reset}>Request Another Withdrawal</Button>
        </div>
        <WithdrawalHistory
          title="NGN Withdrawal History"
          loading={historyLoading}
          rows={history.map((w) => ({
            id: w.id,
            label: formatNgn(w.amount),
            sub: ngnWithdrawalSubline(w),
            status: w.status,
            date: formatDateTime(w.created_at),
          }))}
        />
      </>
    );
  }

  return (
    <>
      <StepProgress steps={['Enter Amount', 'Preview', 'Confirm']} activeIndex={step === 'amount' ? 0 : 1} />

      <div className="mb-5 space-y-2 rounded-xl border border-zinc-200 p-4 text-[12.5px] dark:border-white/[0.08]">
        <p className="mb-1 font-semibold text-zinc-800 dark:text-zinc-100">Payout Account</p>
        <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
          <span>Bank</span>
          <span className="font-medium text-zinc-800 dark:text-zinc-100">{bankAccount!.bank_name}</span>
        </div>
        <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
          <span>Account Number</span>
          <span className="font-mono font-medium text-zinc-800 dark:text-zinc-100">{bankAccount!.account_number}</span>
        </div>
        <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
          <span>Account Name</span>
          <span className="font-medium text-zinc-800 dark:text-zinc-100">{bankAccount!.account_name}</span>
        </div>
      </div>

      {step === 'amount' && (
        <>
          <Field
            id="ngnWithdrawAmount"
            label="Amount"
            type="number"
            placeholder="0.00"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            rightSlot={<span className="pr-3.5 text-[12.5px] font-semibold text-zinc-500 dark:text-zinc-400">NGN</span>}
          />

          {error && <p className="mb-4 text-[12.5px] text-down-500">{error}</p>}

          <Button fullWidth size="lg" disabled={!(Number(amount) > 0) || busy} onClick={handlePreview}>
            {busy ? <Loader2 size={16} className="animate-spin" /> : 'Preview Withdrawal'}
          </Button>
        </>
      )}

      {step === 'preview' && preview && (
        <>
          <div className="mb-5 space-y-2 rounded-xl border border-zinc-200 p-4 text-[12.5px] dark:border-white/[0.08]">
            <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
              <span>Wallet Balance</span>
              <span className="font-mono text-zinc-700 dark:text-zinc-200">{formatNgn(preview.wallet_balance)}</span>
            </div>
            <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
              <span>Amount</span>
              <span className="font-mono text-zinc-700 dark:text-zinc-200">{formatNgn(preview.amount)}</span>
            </div>
            <div className="flex justify-between text-zinc-500 dark:text-zinc-400">
              <span>Service Fee</span>
              <span className="font-mono text-zinc-700 dark:text-zinc-200">{formatNgn(preview.service_fee_amount)}</span>
            </div>
            <div className="flex justify-between border-t border-zinc-200 pt-2 font-semibold text-zinc-900 dark:border-white/[0.08] dark:text-white">
              <span>You Will Receive</span>
              <span className="font-mono">{formatNgn(preview.net_amount)}</span>
            </div>
          </div>

          {error && <p className="mb-4 text-[12.5px] text-down-500">{error}</p>}

          <div className="flex gap-3">
            <Button variant="secondary" fullWidth size="lg" disabled={busy} onClick={() => setStep('amount')}>
              Back
            </Button>
            <Button fullWidth size="lg" disabled={busy} onClick={handleConfirm}>
              {busy ? <Loader2 size={16} className="animate-spin" /> : 'Confirm Withdrawal'}
            </Button>
          </div>
        </>
      )}

      <WithdrawalHistory
        title="NGN Withdrawal History"
        loading={historyLoading}
        rows={history.map((w) => ({
          id: w.id,
          label: formatNgn(w.amount),
          sub: ngnWithdrawalSubline(w),
          status: w.status,
          date: formatDateTime(w.created_at),
        }))}
      />
    </>
  );
}

function ngnWithdrawalSubline(w: NGNWithdrawalApi): string {
  if (w.status === 'completed' && w.admin_reference) return `Ref: ${w.admin_reference}`;
  if (w.status === 'rejected' && w.rejection_reason) return `Rejected: ${w.rejection_reason}`;
  return `To ${w.destination_bank_name} •••${w.destination_account_number.slice(-4)}`;
}

// --- Shared withdrawal history list ---

interface HistoryRow {
  id: string;
  label: string;
  sub: string;
  status: string;
  date: string;
}

function WithdrawalHistory({ title, loading, rows }: { title: string; loading: boolean; rows: HistoryRow[] }) {
  return (
    <div className="mt-6">
      <p className="mb-2.5 text-[13px] font-semibold text-zinc-900 dark:text-white">{title}</p>
      {loading ? (
        <div className="flex items-center gap-2 py-6 text-[12.5px] text-zinc-400 dark:text-zinc-500">
          <Loader2 size={14} className="animate-spin" /> Loading history…
        </div>
      ) : rows.length === 0 ? (
        <p className="py-6 text-center text-[12.5px] text-zinc-400 dark:text-zinc-500">No withdrawals yet.</p>
      ) : (
        <div className="space-y-2">
          {rows.map((r) => (
            <div
              key={r.id}
              className="flex items-center justify-between rounded-xl border border-zinc-200 px-4 py-3 dark:border-white/[0.08]"
            >
              <div className="min-w-0">
                <p className="truncate text-[13px] font-medium text-zinc-800 dark:text-zinc-100">{r.label}</p>
                <p className="truncate text-[11.5px] text-zinc-400 dark:text-zinc-500">{r.sub} · {r.date}</p>
              </div>
              <span className={`ml-3 shrink-0 rounded-full px-2 py-0.5 text-[10.5px] font-semibold ${withdrawalStatusBadgeClasses(r.status)}`}>
                {withdrawalStatusLabel(r.status)}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
