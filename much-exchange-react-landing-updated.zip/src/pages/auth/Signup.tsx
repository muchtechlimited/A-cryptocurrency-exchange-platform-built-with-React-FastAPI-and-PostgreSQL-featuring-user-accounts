import { useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import AuthCardLayout from '../../layouts/AuthCardLayout';
import Field from '../../components/ui/Field';
import Button from '../../components/ui/Button';
import { useAuth } from '../../context/AuthContext';

export default function Signup() {
  const { register } = useAuth();
  const navigate = useNavigate();

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [bankName, setBankName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [accountName, setAccountName] = useState('');
  const [agreed, setAgreed] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');

    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    if (!/^\d{10}$/.test(accountNumber.trim())) {
      setError('Account number must be exactly 10 digits (NUBAN format).');
      return;
    }

    setLoading(true);
    register({
      email: email.trim(),
      password,
      full_name: fullName.trim(),
      bank_name: bankName.trim(),
      account_number: accountNumber.trim(),
      account_name: accountName.trim(),
    })
      .then(() => navigate('/dashboard', { replace: true }))
      .catch((err: unknown) => {
        setError(err instanceof Error ? err.message : 'Sign up failed. Please try again.');
      })
      .finally(() => setLoading(false));
  }

  return (
    <AuthCardLayout>
      <div className="mb-6 text-center">
        <h1 className="font-display text-[20px] font-bold text-zinc-900 dark:text-white">Create Account</h1>
        <p className="text-[13px] text-zinc-500 dark:text-zinc-400">Join Much Exchange today</p>
      </div>

      <form onSubmit={handleSubmit}>
        <Field id="fullName" label="Full Name" type="text" placeholder="Enter your full name" value={fullName} onChange={(e) => setFullName(e.target.value)} required />
        <Field id="email" label="Email address" type="email" placeholder="Enter your email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <Field id="password" label="Password" type="password" placeholder="Create a password" value={password} onChange={(e) => setPassword(e.target.value)} minLength={8} required />
        <Field id="confirmPassword" label="Confirm Password" type="password" placeholder="Confirm your password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required />

        <p className="mb-3 mt-1 text-[12px] font-semibold uppercase tracking-wide text-zinc-400 dark:text-zinc-500">
          Payout Bank Account
        </p>
        <Field id="bankName" label="Bank Name" type="text" placeholder="e.g. GTBank" value={bankName} onChange={(e) => setBankName(e.target.value)} required />
        <Field
          id="accountNumber"
          label="Account Number"
          type="text"
          inputMode="numeric"
          placeholder="10-digit NUBAN account number"
          value={accountNumber}
          onChange={(e) => setAccountNumber(e.target.value.replace(/\D/g, '').slice(0, 10))}
          required
        />
        <Field id="accountName" label="Account Name" type="text" placeholder="Name on the account" value={accountName} onChange={(e) => setAccountName(e.target.value)} required />

        <label className="mb-5 flex items-start gap-2 text-[12px] text-zinc-500 dark:text-zinc-400">
          <input
            type="checkbox"
            checked={agreed}
            onChange={(e) => setAgreed(e.target.checked)}
            className="mt-0.5 h-3.5 w-3.5 rounded border-zinc-300 text-brand-500 focus:ring-brand-400 dark:border-white/20 dark:bg-white/5"
          />
          I agree to the{' '}
          <a href="#" className="text-brand-600 hover:text-brand-500">
            Terms of Service
          </a>{' '}
          and{' '}
          <a href="#" className="text-brand-600 hover:text-brand-500">
            Privacy Policy
          </a>
        </label>

        {error && <p className="-mt-3 mb-4 text-[12.5px] font-medium text-down-500">{error}</p>}

        <Button type="submit" fullWidth size="lg" disabled={!agreed || loading}>
          {loading ? 'Creating account…' : 'Sign Up'}
        </Button>
      </form>

      <p className="mt-5 text-center text-[13px] text-zinc-500 dark:text-zinc-400">
        Already have an account?{' '}
        <Link to="/login" className="font-semibold text-brand-600 hover:text-brand-500">
          Log in
        </Link>
      </p>
    </AuthCardLayout>
  );
}
