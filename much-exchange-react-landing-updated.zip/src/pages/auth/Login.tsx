import { useState, type FormEvent } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import AuthSplitLayout from '../../layouts/AuthSplitLayout';
import Field from '../../components/ui/Field';
import Button from '../../components/ui/Button';
import { useAuth } from '../../context/AuthContext';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = (location.state as { from?: string } | null)?.from || '/dashboard';

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    console.log('[DEBUG] handleSubmit called', { email, password });
    setError('');

    if (!email.trim() || !password.trim()) {
      setError('Enter your email and password to continue.');
      return;
    }

    setLoading(true);
    login(email.trim(), password)
      .then(() => navigate(from, { replace: true }))
      .catch((err: unknown) => {
        setError(err instanceof Error ? err.message : 'Login failed. Please try again.');
      })
      .finally(() => setLoading(false));
  }

  return (
    <AuthSplitLayout>
      <h1 className="font-display text-[22px] font-bold text-zinc-900 dark:text-white">Welcome Back 👋</h1>
      <p className="mb-6 text-[13px] text-zinc-500 dark:text-zinc-400">Login to your account</p>

      <form onSubmit={handleSubmit}>
        <Field
          id="email"
          label="Email address"
          type="email"
          placeholder="Enter your email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <div>
          <div className="mb-1.5 flex items-center justify-between">
            <label htmlFor="password" className="text-[13px] font-medium text-zinc-700 dark:text-zinc-300">
              Password
            </label>
            <Link to="/forgot-password" className="text-[12px] font-medium text-brand-600 hover:text-brand-500">
              Forgot password?
            </Link>
          </div>
          <Field
            id="password"
            label=""
            type="password"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            className="!mb-0"
          />
        </div>

        {error && <p className="mt-3 text-[12.5px] font-medium text-down-500">{error}</p>}

        <Button type="submit" fullWidth size="lg" className="mt-6" disabled={loading}>
          {loading ? 'Logging in…' : 'Log In'}
        </Button>
      </form>

      <p className="mt-6 text-center text-[13px] text-zinc-500 dark:text-zinc-400">
        Don't have an account?{' '}
        <Link to="/signup" className="font-semibold text-brand-600 hover:text-brand-500">
          Sign up
        </Link>
      </p>
    </AuthSplitLayout>
  );
}
