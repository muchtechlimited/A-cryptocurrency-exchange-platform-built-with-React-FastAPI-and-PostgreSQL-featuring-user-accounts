import { useState } from 'react';
import { Link } from 'react-router-dom';
import AuthCardLayout from '../../layouts/AuthCardLayout';
import Field from '../../components/ui/Field';
import Button from '../../components/ui/Button';

export default function ForgotPassword() {
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSent(true);
    }, 900);
  }

  return (
    <AuthCardLayout>
      <div className="mb-6 text-center">
        <h1 className="font-display text-[20px] font-bold text-zinc-900 dark:text-white">Forgot Password?</h1>
        <p className="text-[13px] text-zinc-500 dark:text-zinc-400">
          Enter your email address and we'll send you a link to reset your password.
        </p>
      </div>

      {sent ? (
        <div className="rounded-xl border border-up-500/25 bg-up-500/10 px-4 py-3 text-center text-[13px] text-up-600 dark:text-up-500">
          Reset link sent — check your inbox.
        </div>
      ) : (
        <form onSubmit={handleSubmit}>
          <Field id="email" label="Email address" type="email" placeholder="Enter your email" required />
          <Button type="submit" fullWidth size="lg" disabled={loading}>
            {loading ? 'Sending…' : 'Send Reset Link'}
          </Button>
        </form>
      )}

      <p className="mt-5 text-center text-[13px] text-zinc-500 dark:text-zinc-400">
        <Link to="/login" className="font-semibold text-brand-600 hover:text-brand-500">
          Back to login
        </Link>
      </p>
    </AuthCardLayout>
  );
}
