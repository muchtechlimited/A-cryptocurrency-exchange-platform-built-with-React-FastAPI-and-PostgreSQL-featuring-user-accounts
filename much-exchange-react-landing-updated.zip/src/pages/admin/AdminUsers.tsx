import { useEffect, useMemo, useState, useCallback } from 'react';
import { Search, Loader2, ShieldCheck, ShieldOff } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';
import Card from '../../components/ui/Card';
import StatusPill from '../../components/admin/StatusPill';
import { listUsers, setUserActiveStatus, type AdminUserListItemApi } from '../../lib/adminApi';
import { ApiError } from '../../lib/api';

type KycFilter = 'All KYC' | 'Verified' | 'Pending' | 'Unverified' | 'Rejected';
type StatusFilter = 'All Status' | 'Active' | 'Suspended';

const kycOptions: KycFilter[] = ['All KYC', 'Verified', 'Pending', 'Unverified', 'Rejected'];
const statusOptions: StatusFilter[] = ['All Status', 'Active', 'Suspended'];

function kycLabel(kycStatus: string): 'Verified' | 'Pending' | 'Unverified' | 'Rejected' {
  switch (kycStatus) {
    case 'approved': return 'Verified';
    case 'pending': return 'Pending';
    case 'rejected': return 'Rejected';
    default: return 'Unverified';
  }
}

function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  } catch {
    return iso;
  }
}

export default function AdminUsers() {
  const [users, setUsers] = useState<AdminUserListItemApi[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [kycFilter, setKycFilter] = useState<KycFilter>('All KYC');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('All Status');
  const [actingOnId, setActingOnId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      setUsers(await listUsers());
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to load users.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = useMemo(
    () =>
      users.filter((u) => {
        const q = query.trim().toLowerCase();
        const queryMatch = q === '' || u.full_name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q);
        const kycMatch = kycFilter === 'All KYC' || kycLabel(u.kyc_status) === kycFilter;
        const statusLabel = u.is_active ? 'Active' : 'Suspended';
        const statusMatch = statusFilter === 'All Status' || statusLabel === statusFilter;
        return queryMatch && kycMatch && statusMatch;
      }),
    [users, query, kycFilter, statusFilter],
  );

  async function toggleStatus(user: AdminUserListItemApi) {
    setActingOnId(user.id);
    setError('');
    try {
      await setUserActiveStatus(user.id, !user.is_active);
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not update this account.');
    } finally {
      setActingOnId(null);
    }
  }

  return (
    <AdminLayout title="Users" subtitle={loading ? 'Loading…' : `${users.length.toLocaleString()} registered accounts.`}>
      {error && (
        <div className="mb-4 rounded-xl border border-down-500/30 bg-down-500/5 px-4 py-3 text-[13px] text-down-600 dark:text-down-400">
          {error}
        </div>
      )}

      <Card className="!p-0">
        <div className="flex flex-col gap-3 border-b border-zinc-200 px-4 py-4 dark:border-white/[0.08] sm:flex-row sm:items-center sm:justify-between sm:px-5">
          <div className="relative flex-1 sm:max-w-xs">
            <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by name or email"
              className="h-9 w-full rounded-lg border border-zinc-200 bg-white pl-8 pr-3 text-[12.5px] text-zinc-700 outline-none placeholder:text-zinc-400 dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-200 dark:placeholder:text-zinc-500"
            />
          </div>
          <div className="flex gap-2">
            <select
              value={kycFilter}
              onChange={(e) => setKycFilter(e.target.value as KycFilter)}
              className="h-9 flex-1 rounded-lg border border-zinc-200 bg-white px-3 text-[12.5px] text-zinc-700 outline-none dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-200 sm:flex-none"
            >
              {kycOptions.map((k) => <option key={k} value={k}>{k}</option>)}
            </select>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as StatusFilter)}
              className="h-9 flex-1 rounded-lg border border-zinc-200 bg-white px-3 text-[12.5px] text-zinc-700 outline-none dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-200 sm:flex-none"
            >
              {statusOptions.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center gap-2 px-5 py-12 text-[13px] text-zinc-400 dark:text-zinc-500">
            <Loader2 size={16} className="animate-spin" /> Loading users…
          </div>
        ) : (
          <>
            <div className="divide-y divide-zinc-100 dark:divide-white/[0.06] sm:hidden">
              {filtered.map((u) => (
                <div key={u.id} className="flex items-center gap-3 px-4 py-3.5">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-b from-brand-400 to-brand-500 text-[12.5px] font-bold text-zinc-900">
                    {u.full_name.charAt(0).toUpperCase()}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] font-semibold text-zinc-800 dark:text-zinc-100">{u.full_name}</p>
                    <p className="truncate text-[11.5px] text-zinc-400 dark:text-zinc-500">{u.email}</p>
                    <div className="mt-1.5 flex items-center gap-1.5">
                      <StatusPill status={kycLabel(u.kyc_status)} />
                      <StatusPill status={u.is_active ? 'Active' : 'Suspended'} />
                      {u.is_admin && <StatusPill status="Verified" />}
                    </div>
                  </div>
                  <button
                    onClick={() => toggleStatus(u)}
                    disabled={actingOnId === u.id || u.is_admin}
                    aria-label={u.is_active ? 'Suspend account' : 'Activate account'}
                    className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-zinc-400 hover:bg-zinc-100 disabled:opacity-30 dark:hover:bg-white/[0.06]"
                  >
                    {u.is_active ? <ShieldOff size={15} /> : <ShieldCheck size={15} />}
                  </button>
                </div>
              ))}
              {filtered.length === 0 && (
                <p className="px-5 py-8 text-center text-[13px] text-zinc-400 dark:text-zinc-500">
                  No users match these filters.
                </p>
              )}
            </div>

            <div className="hidden overflow-x-auto sm:block">
              <table className="w-full min-w-[760px] text-left text-[12.5px] [&_td]:whitespace-nowrap [&_th]:whitespace-nowrap">
                <thead>
                  <tr className="text-[11px] uppercase tracking-wide text-zinc-400 dark:text-zinc-500">
                    <th className="px-5 py-3 font-medium">User</th>
                    <th className="px-5 py-3 font-medium">Joined</th>
                    <th className="px-5 py-3 font-medium">KYC</th>
                    <th className="px-5 py-3 font-medium">Status</th>
                    <th className="px-5 py-3 font-medium">Role</th>
                    <th className="px-5 py-3 font-medium" />
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((u) => (
                    <tr key={u.id} className="border-t border-zinc-100 dark:border-white/[0.06]">
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-2.5">
                          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-b from-brand-400 to-brand-500 text-[11.5px] font-bold text-zinc-900">
                            {u.full_name.charAt(0).toUpperCase()}
                          </div>
                          <div className="min-w-0">
                            <p className="truncate font-medium text-zinc-800 dark:text-zinc-100">{u.full_name}</p>
                            <p className="truncate text-[11.5px] text-zinc-400 dark:text-zinc-500">{u.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-3 text-zinc-500 dark:text-zinc-400">{formatDate(u.created_at)}</td>
                      <td className="px-5 py-3"><StatusPill status={kycLabel(u.kyc_status)} /></td>
                      <td className="px-5 py-3"><StatusPill status={u.is_active ? 'Active' : 'Suspended'} /></td>
                      <td className="px-5 py-3 text-zinc-500 dark:text-zinc-400">{u.is_admin ? 'Admin' : 'User'}</td>
                      <td className="px-5 py-3 text-right">
                        <button
                          onClick={() => toggleStatus(u)}
                          disabled={actingOnId === u.id || u.is_admin}
                          aria-label={u.is_active ? 'Suspend account' : 'Activate account'}
                          className="inline-flex h-7 items-center gap-1.5 rounded-lg px-2 text-[11.5px] font-medium text-zinc-500 hover:bg-zinc-100 disabled:opacity-30 dark:hover:bg-white/[0.06]"
                        >
                          {u.is_active ? <><ShieldOff size={13} /> Suspend</> : <><ShieldCheck size={13} /> Activate</>}
                        </button>
                      </td>
                    </tr>
                  ))}
                  {filtered.length === 0 && (
                    <tr>
                      <td colSpan={6} className="px-5 py-8 text-center text-zinc-400 dark:text-zinc-500">
                        No users match these filters.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </>
        )}
      </Card>
    </AdminLayout>
  );
}
