import { useEffect, useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { ShieldCheck, CreditCard, ChevronRight, Loader2 } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';
import StatCard from '../../components/admin/StatCard';
import PlatformVolumeChart from '../../components/admin/PlatformVolumeChart';
import RecentActivityFeed from '../../components/admin/RecentActivityFeed';
import Card from '../../components/ui/Card';
import {
  getDashboardAnalytics,
  listAllLedgerTransactions,
  type DashboardAnalyticsApi,
  type LedgerTransactionApi,
} from '../../lib/adminApi';
import { getGiftCardStats } from '../../lib/giftCardsApi';
import { ApiError } from '../../lib/api';

function PendingQueueCard({ pendingKyc, pendingGiftCards }: { pendingKyc: number; pendingGiftCards: number }) {
  return (
    <Card className="!p-0">
      <div className="border-b border-zinc-200 px-5 py-4 dark:border-white/[0.08]">
        <h3 className="text-[14px] font-semibold text-zinc-900 dark:text-white">Needs Your Review</h3>
      </div>
      <div className="divide-y divide-zinc-100 dark:divide-white/[0.06]">
        <Link
          to="/admin/kyc"
          className="flex items-center gap-3 px-5 py-4 transition-colors hover:bg-zinc-50 dark:hover:bg-white/[0.03]"
        >
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-500/10 text-brand-600 dark:text-brand-400">
            <ShieldCheck size={18} />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[13px] font-semibold text-zinc-900 dark:text-white">KYC Verifications</p>
            <p className="text-[11.5px] text-zinc-400 dark:text-zinc-500">{pendingKyc} pending submissions</p>
          </div>
          <ChevronRight size={16} className="shrink-0 text-zinc-400" />
        </Link>
        <Link
          to="/admin/gift-cards"
          className="flex items-center gap-3 px-5 py-4 transition-colors hover:bg-zinc-50 dark:hover:bg-white/[0.03]"
        >
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-500/10 text-brand-600 dark:text-brand-400">
            <CreditCard size={18} />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[13px] font-semibold text-zinc-900 dark:text-white">Gift Card Submissions</p>
            <p className="text-[11.5px] text-zinc-400 dark:text-zinc-500">{pendingGiftCards} pending listings</p>
          </div>
          <ChevronRight size={16} className="shrink-0 text-zinc-400" />
        </Link>
      </div>
    </Card>
  );
}

export default function AdminDashboard() {
  const [analytics, setAnalytics] = useState<DashboardAnalyticsApi | null>(null);
  const [transactions, setTransactions] = useState<LedgerTransactionApi[]>([]);
  const [pendingGiftCards, setPendingGiftCards] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const [dash, ledger, giftCardStats] = await Promise.all([
        getDashboardAnalytics(),
        listAllLedgerTransactions(),
        getGiftCardStats(),
      ]);
      setAnalytics(dash);
      setTransactions(ledger);
      setPendingGiftCards(giftCardStats.pending_count);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to load dashboard data.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  if (loading) {
    return (
      <AdminLayout title="Admin Overview 👋" subtitle="Platform activity across all users at a glance.">
        <div className="flex items-center justify-center gap-2 py-16 text-[13px] text-zinc-400 dark:text-zinc-500">
          <Loader2 size={16} className="animate-spin" /> Loading overview…
        </div>
      </AdminLayout>
    );
  }

  if (error || !analytics) {
    return (
      <AdminLayout title="Admin Overview 👋" subtitle="Platform activity across all users at a glance.">
        <div className="rounded-xl border border-down-500/30 bg-down-500/5 px-4 py-3 text-[13px] text-down-600 dark:text-down-400">
          {error || 'Something went wrong loading the dashboard.'}
        </div>
      </AdminLayout>
    );
  }

  const { stats, daily_activity } = analytics;
  const pendingReviews = stats.pending_kyc + stats.pending_orders + stats.pending_crypto_deposits + stats.pending_crypto_withdrawals + pendingGiftCards;

  const statCards = [
    { label: 'Total Users', value: stats.total_users.toLocaleString(), hint: `${stats.verified_users.toLocaleString()} verified` },
    { label: 'Total Transactions', value: stats.total_transactions.toLocaleString(), hint: 'All time' },
    { label: 'Pending Reviews', value: pendingReviews.toLocaleString(), hint: 'KYC + orders + cards' },
    { label: 'Pending KYC', value: stats.pending_kyc.toLocaleString(), hint: 'Awaiting verification' },
  ];

  return (
    <AdminLayout title="Admin Overview 👋" subtitle="Platform activity across all users at a glance.">
      {/* ---------- Mobile (<768px) ---------- */}
      <div className="space-y-5 md:hidden">
        <div className="grid grid-cols-2 gap-3">
          {statCards.map((s) => <StatCard key={s.label} {...s} />)}
        </div>
        <PendingQueueCard pendingKyc={stats.pending_kyc} pendingGiftCards={pendingGiftCards} />
        <PlatformVolumeChart data={daily_activity} />
        <RecentActivityFeed transactions={transactions} />
      </div>

      {/* ---------- Tablet (768px – 1023px) ---------- */}
      <div className="hidden space-y-5 md:block lg:hidden">
        <div className="grid grid-cols-2 gap-4">
          {statCards.map((s) => <StatCard key={s.label} {...s} />)}
        </div>
        <PendingQueueCard pendingKyc={stats.pending_kyc} pendingGiftCards={pendingGiftCards} />
        <div className="grid grid-cols-2 gap-4">
          <PlatformVolumeChart data={daily_activity} />
          <RecentActivityFeed transactions={transactions} />
        </div>
      </div>

      {/* ---------- Desktop (1024px+) ---------- */}
      <div className="hidden lg:block">
        <div className="mb-6 grid grid-cols-4 gap-4">
          {statCards.map((s) => <StatCard key={s.label} {...s} />)}
        </div>

        <div className="grid grid-cols-[1.4fr_1fr] gap-4">
          <div className="space-y-4">
            <PlatformVolumeChart data={daily_activity} />
            <RecentActivityFeed transactions={transactions} />
          </div>
          <PendingQueueCard pendingKyc={stats.pending_kyc} pendingGiftCards={pendingGiftCards} />
        </div>
      </div>
    </AdminLayout>
  );
}
