import { useEffect, useMemo, useState, useCallback } from 'react';
import { Check, X, Search, SlidersHorizontal, Eye, Hourglass, CheckCircle2, XCircle, TrendingUp, Loader2 } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import StatusPill from '../../components/admin/StatusPill';
import IconStatCard from '../../components/admin/IconStatCard';
import GiftCardDetailModal from '../../components/admin/GiftCardDetailModal';
import type { ReviewStatus } from '../../data/adminMock';
import {
  listGiftCardSubmissions,
  getGiftCardStats,
  reviewGiftCardSubmission,
  toUiSubmission,
  type UiGiftCardSubmission,
  type GiftCardStatsApi,
} from '../../lib/giftCardsApi';
import { ApiError } from '../../lib/api';
import { useAdminChrome } from '../../components/admin/AdminChromeContext';

const tabs: ('All' | ReviewStatus)[] = ['All', 'Pending', 'Approved', 'Rejected'];

export default function AdminGiftCards() {
  const { refreshPendingCounts } = useAdminChrome();
  const [submissions, setSubmissions] = useState<UiGiftCardSubmission[]>([]);
  const [stats, setStats] = useState<GiftCardStatsApi | null>(null);
  const [tab, setTab] = useState<'All' | ReviewStatus>('Pending');
  const [query, setQuery] = useState('');
  const [viewing, setViewing] = useState<UiGiftCardSubmission | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [actingOnId, setActingOnId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const [subs, statsData] = await Promise.all([listGiftCardSubmissions(), getGiftCardStats()]);
      setSubmissions(subs.map(toUiSubmission));
      setStats(statsData);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to load gift card submissions.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = useMemo(
    () =>
      submissions.filter((s) => {
        const tabMatch = tab === 'All' || s.status === tab;
        const q = query.trim().toLowerCase();
        const queryMatch =
          q === '' || s.userName.toLowerCase().includes(q) || s.brand.toLowerCase().includes(q) || s.email.toLowerCase().includes(q);
        return tabMatch && queryMatch;
      }),
    [submissions, tab, query],
  );

  async function act(id: string, status: ReviewStatus) {
    setActingOnId(id);
    setError('');
    try {
      if (status === 'Approved') {
        await reviewGiftCardSubmission(id, { approve: true });
      } else {
        await reviewGiftCardSubmission(id, { approve: false, rejection_reason: 'Rejected by admin' });
      }
      await load();
      refreshPendingCounts();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Action failed. Please try again.');
    } finally {
      setActingOnId(null);
    }
  }

  const pendingCount = stats?.pending_count ?? 0;
  const approvedCount = stats?.approved_count ?? 0;
  const rejectedCount = stats?.rejected_count ?? 0;
  const totalValueThisMonth = Number(stats?.total_value_ngn ?? 0);
  const totalValueDisplay =
    totalValueThisMonth >= 1_000_000
      ? `₦${(totalValueThisMonth / 1_000_000).toFixed(2)}M`
      : `₦${totalValueThisMonth.toLocaleString()}`;

  return (
    <AdminLayout title="Gift Cards" subtitle="Review and manage gift card submissions from sellers.">
      {error && (
        <div className="mb-4 rounded-xl border border-down-500/30 bg-down-500/5 px-4 py-3 text-[13px] text-down-600 dark:text-down-400">
          {error}
        </div>
      )}

      <div className="mb-5 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        <IconStatCard
          icon={Hourglass}
          iconBg="rgba(245, 181, 22, 0.12)"
          iconColor="#D89614"
          value={String(pendingCount)}
          label="Pending"
          hint="Awaiting review"
        />
        <IconStatCard
          icon={CheckCircle2}
          iconBg="rgba(34, 197, 94, 0.12)"
          iconColor="#16A34A"
          value={String(approvedCount)}
          label="Approved"
          hint="All time"
        />
        <IconStatCard
          icon={XCircle}
          iconBg="rgba(239, 68, 68, 0.12)"
          iconColor="#DC2626"
          value={String(rejectedCount)}
          label="Rejected"
          hint="All time"
        />
        <IconStatCard
          icon={TrendingUp}
          iconBg="rgba(59, 130, 246, 0.12)"
          iconColor="#2563EB"
          value={totalValueDisplay}
          label="Total Value"
          hint="Approved payouts"
        />
      </div>

      <Card className="!p-0">
        <div className="flex flex-col gap-3 border-b border-zinc-200 px-4 py-3.5 dark:border-white/[0.08] sm:px-5">
          <div className="flex items-center gap-1 overflow-x-auto">
            {tabs.map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`shrink-0 rounded-lg px-3 py-1.5 text-[12.5px] font-semibold transition-colors ${
                  tab === t
                    ? 'bg-brand-500/10 text-brand-600 dark:bg-brand-400/10 dark:text-brand-400'
                    : 'text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-white'
                }`}
              >
                {t}
                {t === 'Pending' && pendingCount > 0 && (
                  <span className="ml-1.5 rounded-full bg-down-500/15 px-1.5 py-0.5 text-[10px] text-down-500">
                    {pendingCount}
                  </span>
                )}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search submissions..."
                className="h-9 w-full rounded-lg border border-zinc-200 bg-white pl-8 pr-3 text-[12.5px] text-zinc-700 outline-none placeholder:text-zinc-400 dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-200 dark:placeholder:text-zinc-500"
              />
            </div>
            <Button variant="secondary" size="sm" className="shrink-0">
              <SlidersHorizontal size={14} /> Filters
            </Button>
          </div>
        </div>

        {loading && (
          <div className="flex items-center justify-center gap-2 px-5 py-12 text-[13px] text-zinc-400 dark:text-zinc-500">
            <Loader2 size={16} className="animate-spin" /> Loading submissions…
          </div>
        )}

        {!loading && (
          <>
            {/* Mobile: stacked card list */}
            <div className="divide-y divide-zinc-100 dark:divide-white/[0.06] sm:hidden">
              {filtered.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setViewing(s)}
                  className="flex w-full flex-col gap-3 px-4 py-4 text-left transition-colors active:bg-zinc-50 dark:active:bg-white/[0.03]"
                >
                  <div className="flex items-center gap-3">
                    <span
                      className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-[14px] font-bold text-white"
                      style={{ backgroundColor: s.brandColor }}
                    >
                      {s.brandLetter}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[13px] font-semibold text-zinc-800 dark:text-zinc-100">
                        {s.brand} · {s.value}
                      </p>
                      <p className="truncate text-[11.5px] text-zinc-400 dark:text-zinc-500">{s.userName}</p>
                    </div>
                    <StatusPill status={s.status} />
                  </div>
                  <div className="flex items-center justify-between text-[11.5px] text-zinc-400 dark:text-zinc-500">
                    <span>Seller gets <span className="font-semibold text-zinc-700 dark:text-zinc-200">{s.payoutNaira}</span></span>
                    <span>{s.paymentMethod}</span>
                  </div>
                  {s.status === 'Pending' && (
                    <div className="flex gap-2" onClick={(e) => e.stopPropagation()}>
                      <Button
                        size="sm" variant="secondary" className="flex-1"
                        disabled={actingOnId === s.id}
                        onClick={() => act(s.id, 'Approved')}
                      >
                        <Check size={14} /> Approve
                      </Button>
                      <Button
                        size="sm" variant="danger" className="flex-1"
                        disabled={actingOnId === s.id}
                        onClick={() => act(s.id, 'Rejected')}
                      >
                        <X size={14} /> Reject
                      </Button>
                    </div>
                  )}
                </button>
              ))}
              {filtered.length === 0 && (
                <p className="px-5 py-8 text-center text-[13px] text-zinc-400 dark:text-zinc-500">
                  No submissions in this view.
                </p>
              )}
            </div>

            {/* Tablet/desktop: rich row list */}
            <div className="hidden divide-y divide-zinc-100 dark:divide-white/[0.06] sm:block">
              {filtered.map((s) => (
                <div key={s.id} className="flex items-center gap-4 px-5 py-4">
                  <span
                    className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-[15px] font-bold text-white"
                    style={{ backgroundColor: s.brandColor }}
                  >
                    {s.brandLetter}
                  </span>

                  <div className="w-[105px] shrink-0 lg:w-[130px]">
                    <p className="text-[13px] font-semibold text-zinc-800 dark:text-zinc-100">{s.brand}</p>
                    <p className="text-[12px] text-zinc-400 dark:text-zinc-500">{s.value}</p>
                    <div className="mt-1"><StatusPill status={s.status} /></div>
                  </div>

                  <div className="w-[145px] shrink-0 lg:w-[210px]">
                    <p className="text-[11px] font-medium uppercase tracking-wide text-zinc-400 dark:text-zinc-500">
                      Submitted by
                    </p>
                    <p className="truncate text-[12.5px] font-semibold text-zinc-700 dark:text-zinc-200">{s.userName}</p>
                    <p className="truncate text-[11.5px] text-zinc-400 dark:text-zinc-500">{s.email}</p>
                  </div>

                  <div className="w-[105px] shrink-0 lg:w-[130px]">
                    <p className="text-[11px] font-medium uppercase tracking-wide text-zinc-400 dark:text-zinc-500">
                      Seller Gets
                    </p>
                    <p className="text-[13px] font-bold text-zinc-900 dark:text-white">{s.payoutNaira}</p>
                    <p className="text-[11px] text-zinc-400 dark:text-zinc-500">{s.offeredRate}</p>
                  </div>

                  <div className="hidden w-[130px] shrink-0 lg:block">
                    <p className="text-[11px] font-medium uppercase tracking-wide text-zinc-400 dark:text-zinc-500">
                      Payment Method
                    </p>
                    <p className="text-[12.5px] font-medium text-zinc-600 dark:text-zinc-300">{s.paymentMethod}</p>
                    <p className="text-[11px] text-zinc-400 dark:text-zinc-500">{s.submitted}</p>
                  </div>

                  <div className="ml-auto flex shrink-0 items-center gap-2">
                    {s.status === 'Pending' && (
                      <div className="hidden items-center gap-2 lg:flex">
                        <Button size="sm" variant="secondary" disabled={actingOnId === s.id} onClick={() => act(s.id, 'Approved')}>
                          <Check size={14} /> Approve
                        </Button>
                        <Button size="sm" variant="danger" disabled={actingOnId === s.id} onClick={() => act(s.id, 'Rejected')}>
                          <X size={14} /> Reject
                        </Button>
                      </div>
                    )}
                    <button
                      onClick={() => setViewing(s)}
                      aria-label="View submission"
                      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-zinc-400 hover:bg-zinc-100 hover:text-zinc-700 dark:hover:bg-white/[0.06] dark:hover:text-zinc-200 lg:h-8 lg:w-8"
                    >
                      <Eye size={16} />
                    </button>
                  </div>
                </div>
              ))}
              {filtered.length === 0 && (
                <p className="px-5 py-8 text-center text-[13px] text-zinc-400 dark:text-zinc-500">
                  No submissions in this view.
                </p>
              )}
            </div>

            {filtered.length > 0 && (
              <div className="flex items-center justify-between border-t border-zinc-200 px-5 py-3.5 text-[12px] text-zinc-400 dark:border-white/[0.08] dark:text-zinc-500">
                <span>Showing 1 to {filtered.length} of {filtered.length} results</span>
              </div>
            )}
          </>
        )}
      </Card>

      <GiftCardDetailModal
        submission={viewing}
        onClose={() => setViewing(null)}
        onApprove={(id) => act(id, 'Approved')}
        onReject={(id) => act(id, 'Rejected')}
      />
    </AdminLayout>
  );
}
