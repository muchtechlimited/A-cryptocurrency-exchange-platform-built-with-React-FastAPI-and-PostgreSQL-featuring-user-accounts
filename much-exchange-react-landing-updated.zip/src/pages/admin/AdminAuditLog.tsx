import { useEffect, useMemo, useState } from 'react';
import { Loader2, ChevronDown, SearchX } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';
import Card from '../../components/ui/Card';
import {
  listAuditLog,
  listAuditLogActions,
  formatActionLabel,
  actionCategory,
  type AuditLogEntryApi,
} from '../../lib/auditLogApi';
import { ApiError } from '../../lib/api';

const CATEGORY_COLOR: Record<string, string> = {
  kyc: 'bg-brand-500/10 text-brand-600 dark:text-brand-400',
  rate: 'bg-up-500/10 text-up-500',
  gift_card_rate: 'bg-up-500/10 text-up-500',
  wallet: 'bg-pending-500/10 text-pending-500',
  withdrawal: 'bg-down-500/10 text-down-500',
  deposit: 'bg-up-500/10 text-up-500',
  order: 'bg-brand-500/10 text-brand-600 dark:text-brand-400',
  gift_card: 'bg-up-500/10 text-up-500',
  gift_card_stock: 'bg-zinc-400/10 text-zinc-500 dark:text-zinc-400',
  user: 'bg-down-500/10 text-down-500',
  ticket: 'bg-brand-500/10 text-brand-600 dark:text-brand-400',
  company_bank_account: 'bg-down-500/10 text-down-500',
  company_wallet: 'bg-down-500/10 text-down-500',
};

function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleString('en-US', {
      month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

function ActionBadge({ action }: { action: string }) {
  const cat = actionCategory(action);
  const cls = CATEGORY_COLOR[cat] ?? 'bg-zinc-400/10 text-zinc-500 dark:text-zinc-400';
  return (
    <span className={`inline-flex shrink-0 items-center rounded-full px-2 py-0.5 text-[10.5px] font-semibold ${cls}`}>
      {formatActionLabel(action)}
    </span>
  );
}

function DetailsRow({ entry }: { entry: AuditLogEntryApi }) {
  const [open, setOpen] = useState(false);
  let parsed: unknown = null;
  if (entry.details) {
    try {
      parsed = JSON.parse(entry.details);
    } catch {
      parsed = entry.details;
    }
  }

  return (
    <div>
      <button
        onClick={() => setOpen((v) => !v)}
        className="mt-1 flex items-center gap-1 text-[11px] font-medium text-zinc-400 hover:text-zinc-600 dark:text-zinc-500 dark:hover:text-zinc-300"
      >
        <ChevronDown size={11} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
        Details
      </button>
      {open && (
        <pre className="mt-1.5 overflow-x-auto rounded-lg bg-zinc-50 px-3 py-2 text-[11px] leading-relaxed text-zinc-600 dark:bg-white/[0.04] dark:text-zinc-300">
          {JSON.stringify(parsed, null, 2)}
        </pre>
      )}
    </div>
  );
}

export default function AdminAuditLog() {
  const [entries, setEntries] = useState<AuditLogEntryApi[]>([]);
  const [actions, setActions] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [actionFilter, setActionFilter] = useState('All Actions');
  const [targetTypeFilter, setTargetTypeFilter] = useState('All Types');
  const [search, setSearch] = useState('');

  useEffect(() => {
    setLoading(true);
    setError('');
    Promise.all([listAuditLog({ limit: 300 }), listAuditLogActions()])
      .then(([log, distinctActions]) => {
        setEntries(log);
        setActions(distinctActions);
      })
      .catch((err) => setError(err instanceof ApiError ? err.message : 'Failed to load the audit log.'))
      .finally(() => setLoading(false));
  }, []);

  const targetTypes = useMemo(
    () => ['All Types', ...Array.from(new Set(entries.map((e) => e.target_type))).sort()],
    [entries],
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return entries.filter((e) => {
      if (actionFilter !== 'All Actions' && e.action !== actionFilter) return false;
      if (targetTypeFilter !== 'All Types' && e.target_type !== targetTypeFilter) return false;
      if (q) {
        const haystack = `${e.summary} ${e.actor_email ?? ''} ${e.actor_full_name ?? ''} ${e.target_user_email ?? ''} ${e.target_user_full_name ?? ''}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });
  }, [entries, actionFilter, targetTypeFilter, search]);

  return (
    <AdminLayout
      title="Audit Log"
      subtitle={loading ? 'Loading…' : `${filtered.length} of ${entries.length} actions shown.`}
    >
      {error && (
        <div className="mb-4 rounded-xl border border-down-500/30 bg-down-500/5 px-4 py-3 text-[13px] text-down-600 dark:text-down-500">
          {error}
        </div>
      )}

      <Card className="!p-0">
        <div className="flex flex-col gap-2.5 border-b border-zinc-200 px-4 py-4 dark:border-white/[0.08] sm:flex-row sm:items-center sm:px-5">
          <input
            type="text"
            placeholder="Search by summary, admin, or user…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-9 flex-1 rounded-lg border border-zinc-200 bg-white px-3 text-[12.5px] text-zinc-700 outline-none focus:border-brand-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-200 dark:placeholder:text-zinc-500"
          />
          <div className="flex gap-2">
            <select
              value={actionFilter}
              onChange={(e) => setActionFilter(e.target.value)}
              className="h-9 flex-1 rounded-lg border border-zinc-200 bg-white px-3 text-[12.5px] text-zinc-700 outline-none dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-200 sm:flex-none"
            >
              <option>All Actions</option>
              {actions.map((a) => (
                <option key={a} value={a}>{formatActionLabel(a)}</option>
              ))}
            </select>
            <select
              value={targetTypeFilter}
              onChange={(e) => setTargetTypeFilter(e.target.value)}
              className="h-9 flex-1 rounded-lg border border-zinc-200 bg-white px-3 text-[12.5px] text-zinc-700 outline-none dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-200 sm:flex-none"
            >
              {targetTypes.map((t) => (
                <option key={t} value={t}>{t === 'All Types' ? t : t.replace(/_/g, ' ')}</option>
              ))}
            </select>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center gap-2 px-5 py-12 text-[13px] text-zinc-400 dark:text-zinc-500">
            <Loader2 size={16} className="animate-spin" /> Loading audit log…
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center px-5 py-14 text-center">
            <SearchX size={28} className="mb-2.5 text-zinc-300 dark:text-zinc-600" />
            <p className="text-[13px] text-zinc-400 dark:text-zinc-500">
              {entries.length === 0 ? 'No admin actions recorded yet.' : 'No entries match your filters.'}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-zinc-100 dark:divide-white/[0.06]">
            {filtered.map((e) => (
              <div key={e.id} className="px-4 py-3.5 sm:px-5">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="mb-1 flex flex-wrap items-center gap-2">
                      <ActionBadge action={e.action} />
                      <span className="text-[11px] text-zinc-400 dark:text-zinc-500">{formatDate(e.created_at)}</span>
                    </div>
                    <p className="text-[13px] leading-snug text-zinc-800 dark:text-zinc-100">{e.summary}</p>
                    <p className="mt-1 text-[11.5px] text-zinc-400 dark:text-zinc-500">
                      By {e.actor_full_name || e.actor_email || 'Unknown admin'}
                      {e.target_user_id && e.target_user_id !== e.actor_id && (
                        <> &middot; on {e.target_user_full_name || e.target_user_email || 'a user'}</>
                      )}
                    </p>
                    {e.details && <DetailsRow entry={e} />}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <p className="mt-3 text-center text-[11.5px] text-zinc-400 dark:text-zinc-500">
        Showing the most recent {entries.length} actions. This log is read-only — entries are written automatically
        and can't be edited or deleted here.
      </p>
    </AdminLayout>
  );
}
