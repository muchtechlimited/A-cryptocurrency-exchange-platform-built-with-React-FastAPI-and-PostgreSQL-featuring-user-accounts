import { useState, type FormEvent } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { ShieldCheck } from 'lucide-react';
import ThemeToggle from '../../components/ThemeToggle';
import Field from '../../components/ui/Field';
import Button from '../../components/ui/Button';
import { useAdminAuth } from '../../context/AdminAuthContext';

export default function AdminLogin() {
  const { login } = useAdminAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = (location.state as { from?: string } | null)?.from || '/admin';

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');

    if (!email.trim() || !password.trim()) {
      setError('Enter your admin email and password to continue.');
      return;
    }

    setLoading(true);
    login(email.trim(), password)
      .then(() => {
        navigate(from, { replace: true });
      })
      .catch((err: unknown) => {
        setError(err instanceof Error ? err.message : 'Sign in failed. Please try again.');
      })
      .finally(() => setLoading(false));
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-zinc-50 p-4 dark:bg-[#08090B] sm:p-8">
      <div className="fixed right-4 top-4 z-10 sm:right-6 sm:top-6">
        <ThemeToggle />
      </div>

      <div className="grid w-full max-w-[860px] overflow-hidden rounded-3xl border border-zinc-200 shadow-2xl shadow-zinc-900/5 dark:border-white/10 dark:shadow-black/40 sm:grid-cols-2">
        <div className="relative hidden flex-col items-center justify-center bg-[#0B0C0E] p-10 sm:flex">
          <div
            className="absolute inset-0 opacity-40"
            style={{
              backgroundImage: 'radial-gradient(circle at 50% 35%, rgba(245,181,22,.18), transparent 60%)',
            }}
          />
          <svg width="100" height="100" viewBox="0 0 40 40" fill="none" className="relative">
            <circle cx="20" cy="20" r="19" fill="url(#admin-split-gradient)" stroke="#B37E08" strokeWidth="0.4" />
            <path d="M11 27V13.5L20 22L29 13.5V27" stroke="#0B0C0E" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" fill="none" />
            <defs>
              <linearGradient id="admin-split-gradient" x1="1" y1="1" x2="39" y2="39" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#FBD46B" />
                <stop offset="1" stopColor="#DE9E0A" />
              </linearGradient>
            </defs>
          </svg>
          <span className="relative mt-5 font-display text-lg font-bold tracking-tight text-white">MUCH</span>
          <span className="relative text-[10px] font-medium tracking-[0.3em] text-zinc-400">EXCHANGE</span>
          <span className="relative mt-5 inline-flex items-center gap-1.5 rounded-md bg-white/10 px-2.5 py-1 text-[10.5px] font-semibold uppercase tracking-wide text-zinc-300">
            <ShieldCheck size={12} /> Admin Panel
          </span>
          <p className="relative mt-6 max-w-[220px] text-center text-[12.5px] leading-relaxed text-zinc-500">
            Restricted access. This area is for authorized Much Exchange staff only.
          </p>
        </div>

        <div className="bg-white px-7 py-10 dark:bg-[#101113] sm:px-10">
          <div className="mb-1 inline-flex items-center gap-1.5 rounded-md bg-zinc-100 px-2 py-0.5 text-[10.5px] font-semibold uppercase tracking-wide text-zinc-500 dark:bg-white/[0.06] dark:text-zinc-400 sm:hidden">
            <ShieldCheck size={11} /> Admin Panel
          </div>
          <h1 className="mt-2 font-display text-[22px] font-bold text-zinc-900 dark:text-white sm:mt-0">
            Admin Sign In
          </h1>
          <p className="mb-6 text-[13px] text-zinc-500 dark:text-zinc-400">
            Sign in with your administrator credentials.
          </p>

          <form onSubmit={handleSubmit}>
            <Field
              id="admin-email"
              label="Admin email"
              type="email"
              placeholder="admin@muchexchange.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="username"
              required
            />
            <Field
              id="admin-password"
              label="Password"
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
              required
            />

            {error && (
              <p className="-mt-2 mb-4 text-[12.5px] font-medium text-down-500">{error}</p>
            )}

            <Button type="submit" fullWidth size="lg" className="mt-2" disabled={loading}>
              {loading ? 'Signing in…' : 'Sign In'}
            </Button>
          </form>

          <p className="mt-6 text-center text-[12.5px] text-zinc-400 dark:text-zinc-500">
            This is a restricted staff area.{' '}
            <Link to="/dashboard" className="font-semibold text-brand-600 hover:text-brand-500">
              Back to Much Exchange
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
