import { useEffect, useMemo, useState, useCallback } from 'react';
import { Check, X, Loader2, Send } from 'lucide-react';
import { Link } from 'react-router-dom';
import AdminLayout from '../../components/admin/AdminLayout';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import StatusPill from '../../components/admin/StatusPill';
import {
  listPendingOrders,
  listPendingDeposits,
  listPendingWithdrawals,
  listPendingBankTransfers,
  listPendingNgnWithdrawals,
  listApprovedWithdrawals,
  listAllLedgerTransactions,
  reviewOrder,
  reviewDeposit,
  reviewWithdrawal,
  reviewBankTransfer,
  reviewNgnWithdrawal,
  completeWithdrawal,
  listUsers,
  type CryptoWithdrawalApi,
} from '../../lib/adminApi';
import { ApiError } from '../../lib/api';

type Source = 'order' | 'deposit' | 'withdrawal' | 'ngn_withdrawal' | 'bank_transfer' | 'ledger';
type UiType = 'Buy' | 'Sell' | 'Deposit' | 'Withdraw' | 'Gift Card' | 'Other';
type UiStatus = 'Pending' | 'Completed' | 'Failed';

interface Row {
  id: string;
  source: Source;
  type: UiType;
  asset: string;
  amount: string;
  userId: string;
  status: UiStatus;
  date: string;
}

const typeOptions: ('All Types' | UiType)[] = ['All Types', 'Buy', 'Sell', 'Deposit', 'Withdraw', 'Gift Card', 'Other'];
const statusOptions: ('All Status' | UiStatus)[] = ['All Status', 'Pending', 'Completed', 'Failed'];

function canActionHere(source: Source) {
  return source !== 'ledger';
}

function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  } catch {
    return iso;
  }
}

function ledgerTypeToUi(type: string): UiType {
  if (type === 'buy_btc' || type === 'buy_usdt') return 'Buy';
  if (type === 'sell_btc' || type === 'sell_usdt') return 'Sell';
  if (type === 'deposit') return 'Deposit';
  if (type === 'withdrawal') return 'Withdraw';
  if (type === 'gift_card_sell' || type === 'buy_gift_card') return 'Gift Card';
  return 'Other';
}

function ledgerStatusToUi(status: string): UiStatus {
  if (status === 'completed') return 'Completed';
  if (status === 'failed' || status === 'rejected') return 'Failed';
  return 'Pending';
}

export default function AdminTransactions() {
  const [rows, setRows] = useState<Row[]>([]);
  const [userNames, setUserNames] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [typeFilter, setTypeFilter] = useState<'All Types' | UiType>('All Types');
  const [statusFilter, setStatusFilter] = useState<'All Status' | UiStatus>('Pending');
  const [actingOnId, setActingOnId] = useState<string | null>(null);

  // Approved-but-not-yet-completed crypto withdrawals live in their own
  // section below, not the main filterable table — they need a distinct
  // action (record a TxID) rather than approve/reject.
  const [awaitingCompletion, setAwaitingCompletion] = useState<CryptoWithdrawalApi[]>([]);
  const [txHashDrafts, setTxHashDrafts] = useState<Record<string, string>>({});
  const [completingId, setCompletingId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const [orders, deposits, withdrawals, ngnWithdrawals, transfers, ledger, users, approved] = await Promise.all([
        listPendingOrders(),
        listPendingDeposits(),
        listPendingWithdrawals(),
        listPendingNgnWithdrawals(),
        listPendingBankTransfers(),
        listAllLedgerTransactions(),
        listUsers(),
        listApprovedWithdrawals(),
      ]);

      const nameMap: Record<string, string> = {};
      users.forEach((u) => { nameMap[u.id] = u.full_name; });
      setUserNames(nameMap);
      setAwaitingCompletion(approved);

      const combined: Row[] = [
        ...orders.map((o): Row => ({
          id: o.id, source: 'order', type: o.side === 'buy' ? 'Buy' : 'Sell', asset: o.currency,
          amount: `${o.crypto_amount} ${o.currency}`, userId: o.user_id, status: 'Pending', date: formatDate(o.created_at),
        })),
        ...deposits.map((d): Row => ({
          id: d.id, source: 'deposit', type: 'Deposit', asset: d.currency,
          amount: `${d.amount} ${d.currency}`, userId: d.user_id, status: 'Pending', date: formatDate(d.created_at),
        })),
        ...withdrawals.map((w): Row => ({
          id: w.id, source: 'withdrawal', type: 'Withdraw', asset: w.currency,
          amount: `${w.amount} ${w.currency}`, userId: w.user_id, status: 'Pending', date: formatDate(w.created_at),
        })),
        ...ngnWithdrawals.map((w): Row => ({
          id: w.id, source: 'ngn_withdrawal', type: 'Withdraw', asset: 'NGN',
          amount: `₦${Number(w.amount).toLocaleString()}`, userId: w.user_id, status: 'Pending', date: formatDate(w.created_at),
        })),
        ...transfers.map((t): Row => ({
          id: t.id, source: 'bank_transfer', type: 'Deposit', asset: 'NGN',
          amount: `₦${Number(t.amount).toLocaleString()}`, userId: t.user_id, status: 'Pending', date: formatDate(t.created_at),
        })),
        ...ledger.map((l): Row => ({
          id: l.id, source: 'ledger', type: ledgerTypeToUi(l.type), asset: l.currency,
          amount: `${l.amount} ${l.currency}`, userId: l.user_id, status: ledgerStatusToUi(l.status), date: formatDate(l.created_at),
        })),
      ];

      setRows(combined);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to load transactions.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function completeOne(withdrawalId: string) {
    const txHash = (txHashDrafts[withdrawalId] || '').trim();
    if (!txHash) {
      setError('Enter the TxID for the crypto you actually sent before marking this complete.');
      return;
    }
    setCompletingId(withdrawalId);
    setError('');
    try {
      await completeWithdrawal(withdrawalId, { admin_tx_hash: txHash });
      setTxHashDrafts((prev) => {
        const next = { ...prev };
        delete next[withdrawalId];
        return next;
      });
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to complete withdrawal.');
    } finally {
      setCompletingId(null);
    }
  }

  const filtered = useMemo(
    () =>
      rows.filter((r) => {
        const typeMatch = typeFilter === 'All Types' || r.type === typeFilter;
        const statusMatch = statusFilter === 'All Status' || r.status === statusFilter;
        return typeMatch && statusMatch;
      }),
    [rows, typeFilter, statusFilter],
  );

  const pendingCount = rows.filter((r) => r.status === 'Pending' && canActionHere(r.source)).length;

  async function act(row: Row, approve: boolean) {
    setActingOnId(row.id);
    setError('');
    try {
      if (row.source === 'order') {
        await reviewOrder(row.id, approve ? { approve: true } : { approve: false, rejection_reason: 'Rejected by admin', rejection_action: 'unfreeze' });
      } else if (row.source === 'deposit') {
        await reviewDeposit(row.id, approve ? { approve: true } : { approve: false, rejection_reason: 'Rejected by admin' });
      } else if (row.source === 'withdrawal') {
        await reviewWithdrawal(row.id, approve ? { approve: true } : { approve: false, rejection_reason: 'Rejected by admin', rejection_action: 'unfreeze' });
      } else if (row.source === 'ngn_withdrawal') {
        // Unlike crypto withdrawals, approving an NGN withdrawal finalizes
        // the debit immediately — there's no separate "complete" step.
        await reviewNgnWithdrawal(row.id, approve ? { approve: true } : { approve: false, rejection_reason: 'Rejected by admin', rejection_action: 'unfreeze' });
      } else if (row.source === 'bank_transfer') {
        await reviewBankTransfer(row.id, approve ? { approve: true } : { approve: false, rejection_reason: 'Rejected by admin' });
      }
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Action failed. Please try again.');
    } finally {
      setActingOnId(null);
    }
  }

  return (
    <AdminLayout
      title="Transactions"
      subtitle={loading ? 'Loading…' : `All buy, sell, deposit and withdraw activity · ${pendingCount} awaiting approval.`}
    >
      {error && (
        <div className="mb-4 rounded-xl border border-down-500/30 bg-down-500/5 px-4 py-3 text-[13px] text-down-600 dark:text-down-400">
          {error}
        </div>
      )}

      {awaitingCompletion.length > 0 && (
        <Card className="mb-5 !p-0">
          <div className="border-b border-zinc-200 px-4 py-3.5 dark:border-white/[0.08] sm:px-5">
            <h3 className="text-[13px] font-semibold text-zinc-800 dark:text-zinc-100">
              Awaiting completion ({awaitingCompletion.length})
            </h3>
            <p className="mt-0.5 text-[12px] text-zinc-400 dark:text-zinc-500">
              Approved crypto withdrawals — the balance stays frozen until you actually send the funds and record the TxID here.
            </p>
          </div>
          <div className="divide-y divide-zinc-100 dark:divide-white/[0.06]">
            {awaitingCompletion.map((w) => (
              <div key={w.id} className="flex flex-col gap-2.5 px-4 py-3.5 sm:flex-row sm:items-center sm:justify-between sm:px-5">
                <div className="min-w-0">
                  <p className="truncate text-[13px] font-semibold text-zinc-800 dark:text-zinc-100">
                    {userNames[w.user_id] || w.user_id.slice(0, 8)} · {w.net_amount} {w.currency}
                  </p>
                  <p className="truncate text-[11.5px] text-zinc-400 dark:text-zinc-500">
                    To: {w.destination_address}
                  </p>
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Paste TxID once sent"
                    value={txHashDrafts[w.id] || ''}
                    onChange={(e) => setTxHashDrafts((prev) => ({ ...prev, [w.id]: e.target.value }))}
                    className="h-9 w-full min-w-[180px] rounded-lg border border-zinc-200 bg-white px-3 text-[12.5px] text-zinc-700 outline-none dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-200 sm:w-56"
                  />
                  <Button
                    size="sm"
                    variant="secondary"
                    disabled={completingId === w.id}
                    onClick={() => completeOne(w.id)}
                  >
                    <Send size={14} /> Mark sent
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      <Card className="!p-0">
        <div className="flex flex-col gap-3 border-b border-zinc-200 px-4 py-4 dark:border-white/[0.08] sm:flex-row sm:items-center sm:justify-between sm:px-5">
          <div className="flex gap-2">
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value as typeof typeFilter)}
              className="h-9 flex-1 rounded-lg border border-zinc-200 bg-white px-3 text-[12.5px] text-zinc-700 outline-none dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-200 sm:flex-none"
            >
              {typeOptions.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as typeof statusFilter)}
              className="h-9 flex-1 rounded-lg border border-zinc-200 bg-white px-3 text-[12.5px] text-zinc-700 outline-none dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-200 sm:flex-none"
            >
              {statusOptions.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center gap-2 px-5 py-12 text-[13px] text-zinc-400 dark:text-zinc-500">
            <Loader2 size={16} className="animate-spin" /> Loading transactions…
          </div>
        ) : (
          <>
            {/* Mobile: stacked card list */}
            <div className="divide-y divide-zinc-100 dark:divide-white/[0.06] sm:hidden">
              {filtered.map((t) => (
                <div key={`${t.source}-${t.id}`} className="flex flex-col gap-2.5 px-4 py-3.5">
                  <div className="flex items-center justify-between">
                    <div className="min-w-0">
                      <p className="truncate text-[13px] font-semibold text-zinc-800 dark:text-zinc-100">
                        {t.type} · {t.asset}
                      </p>
                      <p className="truncate text-[11.5px] text-zinc-400 dark:text-zinc-500">
                        {userNames[t.userId] || t.userId.slice(0, 8)}
                      </p>
                      <p className="mt-0.5 text-[11px] text-zinc-400 dark:text-zinc-500">{t.date}</p>
                    </div>
                    <div className="flex shrink-0 flex-col items-end gap-1">
                      <span className="font-mono text-[12.5px] text-zinc-700 dark:text-zinc-300">{t.amount}</span>
                      <StatusPill status={t.status} />
                    </div>
                  </div>
                  {t.status === 'Pending' && (
                    canActionHere(t.source) ? (
                      <div className="flex gap-2">
                        <Button size="sm" variant="secondary" className="flex-1" disabled={actingOnId === t.id} onClick={() => act(t, true)}>
                          <Check size={14} /> Approve
                        </Button>
                        <Button size="sm" variant="danger" className="flex-1" disabled={actingOnId === t.id} onClick={() => act(t, false)}>
                          <X size={14} /> Reject
                        </Button>
                      </div>
                    ) : (
                      <Link to="/admin/gift-cards" className="text-[12px] font-semibold text-brand-600 dark:text-brand-400">
                        Review in Gift Cards →
                      </Link>
                    )
                  )}
                </div>
              ))}
              {filtered.length === 0 && (
                <p className="px-5 py-8 text-center text-[13px] text-zinc-400 dark:text-zinc-500">
                  No transactions match these filters.
                </p>
              )}
            </div>

            {/* Desktop/tablet: table */}
            <div className="hidden overflow-x-auto sm:block">
              <table className="w-full min-w-[880px] text-left text-[12.5px] [&_td]:whitespace-nowrap [&_th]:whitespace-nowrap">
                <thead>
                  <tr className="text-[11px] uppercase tracking-wide text-zinc-400 dark:text-zinc-500">
                    <th className="px-5 py-3 font-medium">User</th>
                    <th className="px-5 py-3 font-medium">Type</th>
                    <th className="px-5 py-3 font-medium">Asset</th>
                    <th className="px-5 py-3 font-medium">Amount</th>
                    <th className="px-5 py-3 font-medium">Status</th>
                    <th className="px-5 py-3 font-medium">Date</th>
                    <th className="px-5 py-3 font-medium text-right">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((t) => (
                    <tr key={`${t.source}-${t.id}`} className="border-t border-zinc-100 dark:border-white/[0.06]">
                      <td className="px-5 py-3 font-medium text-zinc-800 dark:text-zinc-100">
                        {userNames[t.userId] || t.userId.slice(0, 8)}
                      </td>
                      <td className="px-5 py-3 text-zinc-600 dark:text-zinc-300">{t.type}</td>
                      <td className="px-5 py-3 text-zinc-600 dark:text-zinc-300">{t.asset}</td>
                      <td className="px-5 py-3 font-mono text-zinc-700 dark:text-zinc-300">{t.amount}</td>
                      <td className="px-5 py-3"><StatusPill status={t.status} /></td>
                      <td className="px-5 py-3 text-zinc-500 dark:text-zinc-400">{t.date}</td>
                      <td className="px-5 py-3">
                        {t.status === 'Pending' ? (
                          canActionHere(t.source) ? (
                            <div className="flex justify-end gap-2">
                              <Button size="sm" variant="secondary" disabled={actingOnId === t.id} onClick={() => act(t, true)}>
                                <Check size={14} /> Approve
                              </Button>
                              <Button size="sm" variant="danger" disabled={actingOnId === t.id} onClick={() => act(t, false)}>
                                <X size={14} /> Reject
                              </Button>
                            </div>
                          ) : (
                            <div className="text-right">
                              <Link to="/admin/gift-cards" className="text-[12px] font-semibold text-brand-600 dark:text-brand-400">
                                Review in Gift Cards →
                              </Link>
                            </div>
                          )
                        ) : (
                          <span className="block text-right text-zinc-300 dark:text-zinc-600">—</span>
                        )}
                      </td>
                    </tr>
                  ))}
                  {filtered.length === 0 && (
                    <tr>
                      <td colSpan={7} className="px-5 py-8 text-center text-zinc-400 dark:text-zinc-500">
                        No transactions match these filters.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </>
        )}
      </Card>
    </AdminLayout>
  );
}
