import { useEffect, useMemo, useState, useCallback } from 'react';
import { Check, X, FileText, Loader2, Eye } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import StatusPill from '../../components/admin/StatusPill';
import KycDocumentModal from '../../components/admin/KycDocumentModal';
import { listPendingKyc, reviewKyc, type KYCSubmissionApi } from '../../lib/adminApi';
import { ApiError } from '../../lib/api';
import { useAdminChrome } from '../../components/admin/AdminChromeContext';

type Tab = 'All' | 'Pending' | 'Approved' | 'Rejected';
const tabs: Tab[] = ['All', 'Pending', 'Approved', 'Rejected'];

const STATUS_LABEL: Record<string, 'Pending' | 'Approved' | 'Rejected'> = {
  pending: 'Pending',
  approved: 'Approved',
  rejected: 'Rejected',
};

const DOC_LABEL: Record<string, string> = {
  national_id: 'National ID',
  passport: 'Passport',
  drivers_license: "Driver's License",
  voters_card: "Voter's Card",
};

function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  } catch {
    return iso;
  }
}

export default function AdminKyc() {
  const { refreshPendingCounts } = useAdminChrome();
  const [requests, setRequests] = useState<KYCSubmissionApi[]>([]);
  const [tab, setTab] = useState<Tab>('Pending');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [actingOnId, setActingOnId] = useState<string | null>(null);
  const [viewingId, setViewingId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      setRequests(await listPendingKyc());
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to load KYC submissions.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = useMemo(
    () => requests.filter((r) => tab === 'All' || STATUS_LABEL[r.status] === tab),
    [requests, tab],
  );

  async function act(id: string, approve: boolean) {
    setActingOnId(id);
    setError('');
    try {
      await reviewKyc(id, approve ? { approve: true } : { approve: false, rejection_reason: 'Document did not pass review' });
      await load();
      refreshPendingCounts();
      setViewingId(null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Action failed. Please try again.');
    } finally {
      setActingOnId(null);
    }
  }

  const pendingCount = requests.filter((r) => r.status === 'pending').length;
  const viewingSubmission = requests.find((r) => r.id === viewingId) ?? null;

  return (
    <AdminLayout title="KYC Requests" subtitle={loading ? 'Loading…' : `${pendingCount} submissions awaiting review.`}>
      {error && (
        <div className="mb-4 rounded-xl border border-down-500/30 bg-down-500/5 px-4 py-3 text-[13px] text-down-600 dark:text-down-400">
          {error}
        </div>
      )}

      <Card className="!p-0">
        <div className="flex items-center gap-1 overflow-x-auto border-b border-zinc-200 px-3 py-3 dark:border-white/[0.08] sm:px-4">
          {tabs.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`shrink-0 rounded-lg px-3 py-1.5 text-[12.5px] font-semibold transition-colors ${
                tab === t
                  ? 'bg-brand-500/10 text-brand-600 dark:bg-brand-400/10 dark:text-brand-400'
                  : 'text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-white'
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="flex items-center justify-center gap-2 px-5 py-12 text-[13px] text-zinc-400 dark:text-zinc-500">
            <Loader2 size={16} className="animate-spin" /> Loading submissions…
          </div>
        ) : (
          <div className="divide-y divide-zinc-100 dark:divide-white/[0.06]">
            {filtered.map((r) => (
              <div key={r.id} className="flex flex-col gap-3 px-4 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-5">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-zinc-100 text-zinc-500 dark:bg-white/[0.06] dark:text-zinc-400">
                    <FileText size={17} />
                  </div>
                  <div className="min-w-0">
                    <p className="truncate text-[13px] font-semibold text-zinc-800 dark:text-zinc-100">
                      {r.user_full_name || 'Unknown user'}
                    </p>
                    <p className="truncate text-[11.5px] text-zinc-400 dark:text-zinc-500">{r.user_email}</p>
                    <p className="mt-0.5 text-[11.5px] text-zinc-400 dark:text-zinc-500">
                      {DOC_LABEL[r.document_type] || r.document_type} · Submitted {formatDate(r.created_at)}
                    </p>
                  </div>
                </div>

                <div className="flex shrink-0 items-center gap-2 pl-13 sm:pl-0">
                  <StatusPill status={STATUS_LABEL[r.status] ?? 'Pending'} />
                  <Button size="sm" variant="secondary" onClick={() => setViewingId(r.id)}>
                    <Eye size={14} /> View
                  </Button>
                  {r.status === 'pending' && (
                    <>
                      <Button size="sm" variant="secondary" disabled={actingOnId === r.id} onClick={() => act(r.id, true)}>
                        <Check size={14} /> Approve
                      </Button>
                      <Button size="sm" variant="danger" disabled={actingOnId === r.id} onClick={() => act(r.id, false)}>
                        <X size={14} /> Reject
                      </Button>
                    </>
                  )}
                </div>
              </div>
            ))}
            {filtered.length === 0 && (
              <p className="px-5 py-8 text-center text-[13px] text-zinc-400 dark:text-zinc-500">
                No requests in this view.
              </p>
            )}
          </div>
        )}
      </Card>

      <KycDocumentModal
        submission={viewingSubmission}
        onClose={() => setViewingId(null)}
        onApprove={(id) => act(id, true)}
        onReject={(id) => act(id, false)}
        actingOnId={actingOnId}
      />
    </AdminLayout>
  );
}
