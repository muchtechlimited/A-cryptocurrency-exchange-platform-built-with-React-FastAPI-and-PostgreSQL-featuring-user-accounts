import { useEffect, useState, useCallback } from 'react';
import { Save, Loader2, Check } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { listExchangeRates, setExchangeRate, type ExchangeRateApi } from '../../lib/adminApi';
import { ApiError } from '../../lib/api';

const COIN_META: Record<string, { name: string; color: string; letter: string }> = {
  BTC: { name: 'Bitcoin', color: '#F7931A', letter: 'B' },
  USDT: { name: 'Tether', color: '#26A17B', letter: 'T' },
};

interface EditableRate {
  currency: string;
  buy_rate_ngn: string;
  sell_rate_ngn: string;
  buy_fee_percentage: string;
  sell_fee_percentage: string;
  withdrawal_network_fee: string;
  withdrawal_service_fee: string;
}

function toEditable(r: ExchangeRateApi): EditableRate {
  return {
    currency: r.currency,
    buy_rate_ngn: r.buy_rate_ngn,
    sell_rate_ngn: r.sell_rate_ngn,
    buy_fee_percentage: r.buy_fee_percentage,
    sell_fee_percentage: r.sell_fee_percentage,
    withdrawal_network_fee: r.withdrawal_network_fee,
    withdrawal_service_fee: r.withdrawal_service_fee,
  };
}

function RateRow({
  rate,
  onChange,
  onSave,
  saving,
  saved,
}: {
  rate: EditableRate;
  onChange: (patch: Partial<EditableRate>) => void;
  onSave: () => void;
  saving: boolean;
  saved: boolean;
}) {
  const meta = COIN_META[rate.currency] ?? { name: rate.currency, color: '#6B7280', letter: rate.currency.charAt(0) };

  return (
    <div className="flex flex-col gap-3 px-4 py-4 lg:flex-row lg:items-center lg:gap-4 sm:px-5">
      <div className="flex items-center gap-2.5 lg:w-[140px] lg:shrink-0">
        <span
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-[11px] font-bold text-white"
          style={{ backgroundColor: meta.color }}
        >
          {meta.letter}
        </span>
        <div className="min-w-0">
          <p className="truncate text-[13px] font-semibold text-zinc-800 dark:text-zinc-100">{rate.currency}</p>
          <p className="truncate text-[11.5px] text-zinc-400 dark:text-zinc-500">{meta.name}</p>
        </div>
      </div>

      <div className="grid flex-1 grid-cols-2 gap-3 lg:grid-cols-4">
        <label className="block">
          <span className="mb-1 block text-[11px] font-medium uppercase tracking-wide text-zinc-400 dark:text-zinc-500">
            Buy Rate (₦)
          </span>
          <input
            type="number"
            value={rate.buy_rate_ngn}
            onChange={(e) => onChange({ buy_rate_ngn: e.target.value })}
            className="h-9 w-full rounded-lg border border-zinc-200 bg-zinc-50 px-3 font-mono text-[12.5px] text-zinc-800 outline-none focus:border-brand-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-100"
          />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-medium uppercase tracking-wide text-zinc-400 dark:text-zinc-500">
            Sell Rate (₦)
          </span>
          <input
            type="number"
            value={rate.sell_rate_ngn}
            onChange={(e) => onChange({ sell_rate_ngn: e.target.value })}
            className="h-9 w-full rounded-lg border border-zinc-200 bg-zinc-50 px-3 font-mono text-[12.5px] text-zinc-800 outline-none focus:border-brand-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-100"
          />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-medium uppercase tracking-wide text-zinc-400 dark:text-zinc-500">
            Buy Fee (%)
          </span>
          <input
            type="number"
            step="0.1"
            value={rate.buy_fee_percentage}
            onChange={(e) => onChange({ buy_fee_percentage: e.target.value })}
            className="h-9 w-full rounded-lg border border-zinc-200 bg-zinc-50 px-3 font-mono text-[12.5px] text-zinc-800 outline-none focus:border-brand-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-100"
          />
        </label>
        <label className="block">
          <span className="mb-1 block text-[11px] font-medium uppercase tracking-wide text-zinc-400 dark:text-zinc-500">
            Sell Fee (%)
          </span>
          <input
            type="number"
            step="0.1"
            value={rate.sell_fee_percentage}
            onChange={(e) => onChange({ sell_fee_percentage: e.target.value })}
            className="h-9 w-full rounded-lg border border-zinc-200 bg-zinc-50 px-3 font-mono text-[12.5px] text-zinc-800 outline-none focus:border-brand-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-100"
          />
        </label>
      </div>

      <div className="shrink-0 lg:w-[110px]">
        <Button size="sm" fullWidth onClick={onSave} disabled={saving}>
          {saving ? <Loader2 size={13} className="animate-spin" /> : saved ? <Check size={13} /> : <Save size={13} />}
          {saving ? 'Saving' : saved ? 'Saved' : 'Save'}
        </Button>
      </div>
    </div>
  );
}

export default function AdminRates() {
  const [rates, setRates] = useState<EditableRate[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [savingCurrency, setSavingCurrency] = useState<string | null>(null);
  const [savedCurrency, setSavedCurrency] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await listExchangeRates();
      setRates(data.map(toEditable));
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to load rates.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  function updateRate(currency: string, patch: Partial<EditableRate>) {
    setSavedCurrency(null);
    setRates((prev) => prev.map((r) => (r.currency === currency ? { ...r, ...patch } : r)));
  }

  async function saveRate(rate: EditableRate) {
    setSavingCurrency(rate.currency);
    setError('');
    try {
      await setExchangeRate(rate.currency, {
        buy_rate_ngn: Number(rate.buy_rate_ngn),
        sell_rate_ngn: Number(rate.sell_rate_ngn),
        buy_fee_percentage: Number(rate.buy_fee_percentage),
        sell_fee_percentage: Number(rate.sell_fee_percentage),
        withdrawal_network_fee: Number(rate.withdrawal_network_fee),
        withdrawal_service_fee: Number(rate.withdrawal_service_fee),
      });
      setSavedCurrency(rate.currency);
      setTimeout(() => setSavedCurrency((c) => (c === rate.currency ? null : c)), 2000);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not save this rate.');
    } finally {
      setSavingCurrency(null);
    }
  }

  return (
    <AdminLayout title="Rate Management" subtitle="Set buy/sell rates and fees users see across the platform.">
      {error && (
        <div className="mb-4 rounded-xl border border-down-500/30 bg-down-500/5 px-4 py-3 text-[13px] text-down-600 dark:text-down-400">
          {error}
        </div>
      )}

      <Card className="!p-0">
        <div className="border-b border-zinc-200 px-4 py-4 dark:border-white/[0.08] sm:px-5">
          <p className="text-[12.5px] text-zinc-500 dark:text-zinc-400">
            Rates are set manually and take effect immediately for new orders. Each row saves independently.
          </p>
        </div>

        {loading ? (
          <div className="flex items-center justify-center gap-2 px-5 py-12 text-[13px] text-zinc-400 dark:text-zinc-500">
            <Loader2 size={16} className="animate-spin" /> Loading rates…
          </div>
        ) : rates.length === 0 ? (
          <p className="px-5 py-8 text-center text-[13px] text-zinc-400 dark:text-zinc-500">
            No exchange rates configured yet.
          </p>
        ) : (
          <div className="divide-y divide-zinc-100 dark:divide-white/[0.06]">
            {rates.map((r) => (
              <RateRow
                key={r.currency}
                rate={r}
                onChange={(patch) => updateRate(r.currency, patch)}
                onSave={() => saveRate(r)}
                saving={savingCurrency === r.currency}
                saved={savedCurrency === r.currency}
              />
            ))}
          </div>
        )}
      </Card>
    </AdminLayout>
  );
}
