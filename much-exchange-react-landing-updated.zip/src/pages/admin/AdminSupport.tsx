import { useCallback, useEffect, useMemo, useState } from 'react';
import { ChevronDown, Loader2, Send, MessageSquare } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import StatusPill from '../../components/admin/StatusPill';
import { listAllTickets, respondToTicket, type TicketApi } from '../../lib/supportApi';
import { ApiError } from '../../lib/api';
import { useAdminChrome } from '../../components/admin/AdminChromeContext';

type Tab = 'All' | 'Open' | 'Pending' | 'Resolved';
const TABS: Tab[] = ['All', 'Open', 'Pending', 'Resolved'];

const STATUS_LABEL: Record<TicketApi['status'], 'Open' | 'Pending' | 'Resolved'> = {
  open: 'Open',
  pending: 'Pending',
  resolved: 'Resolved',
};

function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' });
  } catch {
    return iso;
  }
}

function TicketRow({
  ticket,
  expanded,
  onToggle,
  onResponded,
}: {
  ticket: TicketApi;
  expanded: boolean;
  onToggle: () => void;
  onResponded: (updated: TicketApi) => void;
}) {
  const [reply, setReply] = useState(ticket.admin_response ?? '');
  const [nextStatus, setNextStatus] = useState<'pending' | 'resolved'>('resolved');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');

  async function handleRespond() {
    const trimmed = reply.trim();
    if (!trimmed) return;
    setSending(true);
    setError('');
    try {
      const updated = await respondToTicket(ticket.id, { response: trimmed, status: nextStatus });
      onResponded(updated);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to send response.');
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="border-b border-zinc-100 last:border-0 dark:border-white/[0.06]">
      <button
        onClick={onToggle}
        className="flex w-full items-center justify-between gap-3 px-4 py-4 text-left hover:bg-zinc-50 dark:hover:bg-white/[0.02] sm:px-5"
      >
        <div className="flex min-w-0 items-center gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-zinc-100 text-zinc-500 dark:bg-white/[0.06] dark:text-zinc-400">
            <MessageSquare size={16} />
          </div>
          <div className="min-w-0">
            <p className="truncate text-[13px] font-semibold text-zinc-800 dark:text-zinc-100">{ticket.subject}</p>
            <p className="truncate text-[11.5px] text-zinc-400 dark:text-zinc-500">
              {ticket.user_full_name || 'Unknown user'} · {ticket.user_email || '—'}
            </p>
            <p className="mt-0.5 truncate text-[11.5px] text-zinc-400 dark:text-zinc-500">
              {formatDate(ticket.created_at)}
              {ticket.reference && <> · Ref: {ticket.reference}</>}
            </p>
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-2.5">
          <StatusPill status={STATUS_LABEL[ticket.status]} />
          <ChevronDown size={16} className={`text-zinc-400 transition-transform ${expanded ? 'rotate-180' : ''}`} />
        </div>
      </button>

      {expanded && (
        <div className="px-4 pb-5 pl-[4.25rem] pr-4 sm:px-5 sm:pl-[4.25rem]">
          <p className="mb-3 whitespace-pre-wrap rounded-lg border border-zinc-200 bg-zinc-50 px-3 py-2.5 text-[12.5px] leading-relaxed text-zinc-700 dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-200">
            {ticket.message}
          </p>

          {ticket.admin_response && (
            <div className="mb-3 rounded-lg border border-brand-500/20 bg-brand-500/5 px-3 py-2.5">
              <p className="mb-1 text-[11px] font-semibold text-brand-700 dark:text-brand-400">
                Previous reply{ticket.responded_at ? ` · ${formatDate(ticket.responded_at)}` : ''}
              </p>
              <p className="whitespace-pre-wrap text-[12.5px] leading-relaxed text-zinc-700 dark:text-zinc-200">
                {ticket.admin_response}
              </p>
            </div>
          )}

          <label htmlFor={`reply-${ticket.id}`} className="mb-1.5 block text-[12px] font-medium text-zinc-600 dark:text-zinc-300">
            {ticket.admin_response ? 'Update reply' : 'Reply'}
          </label>
          <textarea
            id={`reply-${ticket.id}`}
            value={reply}
            onChange={(e) => setReply(e.target.value)}
            rows={3}
            placeholder="Write a response…"
            className="mb-2.5 w-full resize-none rounded-lg border border-zinc-200 bg-white px-3 py-2.5 text-[12.5px] text-zinc-900 outline-none focus:border-brand-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-white dark:placeholder:text-zinc-500"
          />

          {error && (
            <p className="mb-2.5 rounded-lg border border-down-500/30 bg-down-500/5 px-3 py-2 text-[11.5px] text-down-600 dark:text-down-500">
              {error}
            </p>
          )}

          <div className="flex flex-wrap items-center gap-2.5">
            <select
              value={nextStatus}
              onChange={(e) => setNextStatus(e.target.value as 'pending' | 'resolved')}
              className="h-9 rounded-lg border border-zinc-200 bg-white px-2.5 text-[12px] text-zinc-700 outline-none focus:border-brand-500 dark:border-white/10 dark:bg-white/[0.04] dark:text-zinc-200"
            >
              <option value="resolved">Mark Resolved</option>
              <option value="pending">Keep as Pending</option>
            </select>
            <Button size="sm" onClick={handleRespond} disabled={sending || !reply.trim()}>
              {sending ? <Loader2 size={13} className="animate-spin" /> : <Send size={13} />}
              {ticket.admin_response ? 'Update Reply' : 'Send Reply'}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

export default function AdminSupport() {
  const { refreshPendingCounts } = useAdminChrome();
  const [tickets, setTickets] = useState<TicketApi[]>([]);
  const [tab, setTab] = useState<Tab>('Open');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      setTickets(await listAllTickets());
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to load support tickets.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = useMemo(
    () => tickets.filter((t) => tab === 'All' || STATUS_LABEL[t.status] === tab),
    [tickets, tab],
  );

  const openCount = tickets.filter((t) => t.status === 'open').length;

  function handleResponded(updated: TicketApi) {
    setTickets((prev) => prev.map((t) => (t.id === updated.id ? { ...updated, user_email: t.user_email, user_full_name: t.user_full_name } : t)));
    refreshPendingCounts();
  }

  return (
    <AdminLayout title="Support Tickets" subtitle={loading ? 'Loading…' : `${openCount} open, awaiting a first reply.`}>
      {error && (
        <div className="mb-4 rounded-xl border border-down-500/30 bg-down-500/5 px-4 py-3 text-[13px] text-down-600 dark:text-down-500">
          {error}
        </div>
      )}

      <Card className="!p-0">
        <div className="flex items-center gap-1 overflow-x-auto border-b border-zinc-200 px-3 py-3 dark:border-white/[0.08] sm:px-4">
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`shrink-0 rounded-lg px-3 py-1.5 text-[12.5px] font-semibold transition-colors ${
                tab === t
                  ? 'bg-brand-500/10 text-brand-600 dark:bg-brand-400/10 dark:text-brand-400'
                  : 'text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-white'
              }`}
            >
              {t}
              {t === 'Open' && openCount > 0 && ` (${openCount})`}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="flex items-center justify-center gap-2 px-5 py-12 text-[13px] text-zinc-400 dark:text-zinc-500">
            <Loader2 size={16} className="animate-spin" /> Loading tickets…
          </div>
        ) : (
          <div>
            {filtered.map((t) => (
              <TicketRow
                key={t.id}
                ticket={t}
                expanded={expandedId === t.id}
                onToggle={() => setExpandedId(expandedId === t.id ? null : t.id)}
                onResponded={handleResponded}
              />
            ))}
            {filtered.length === 0 && (
              <p className="px-5 py-8 text-center text-[13px] text-zinc-400 dark:text-zinc-500">
                No tickets in this view.
              </p>
            )}
          </div>
        )}
      </Card>
    </AdminLayout>
  );
}
