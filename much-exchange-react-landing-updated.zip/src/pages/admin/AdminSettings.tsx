import { useState } from 'react';
import AdminLayout from '../../components/admin/AdminLayout';
import Card from '../../components/ui/Card';
import Field from '../../components/ui/Field';
import Button from '../../components/ui/Button';

interface ToggleRowProps {
  label: string;
  hint: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}

function ToggleRow({ label, hint, checked, onChange }: ToggleRowProps) {
  return (
    <div className="flex items-center justify-between gap-4 py-3.5">
      <div className="min-w-0">
        <p className="text-[13px] font-medium text-zinc-800 dark:text-zinc-100">{label}</p>
        <p className="mt-0.5 text-[11.5px] text-zinc-400 dark:text-zinc-500">{hint}</p>
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={`relative h-6 w-10 shrink-0 rounded-full transition-colors ${
          checked ? 'bg-brand-500' : 'bg-zinc-300 dark:bg-white/15'
        }`}
      >
        <span
          className={`absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow-sm transition-transform ${
            checked ? 'translate-x-[18px]' : 'translate-x-0'
          }`}
        />
      </button>
    </div>
  );
}

export default function AdminSettings() {
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [requireKyc, setRequireKyc] = useState(true);
  const [autoApproveGiftCards, setAutoApproveGiftCards] = useState(false);
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [smsAlerts, setSmsAlerts] = useState(false);

  return (
    <AdminLayout title="Settings" subtitle="Platform controls and your admin profile.">
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
        <Card>
          <h3 className="mb-1 text-[14px] font-semibold text-zinc-900 dark:text-white">Platform Controls</h3>
          <p className="mb-2 text-[12px] text-zinc-400 dark:text-zinc-500">
            These affect what every user on Much Exchange sees.
          </p>
          <div className="divide-y divide-zinc-100 dark:divide-white/[0.06]">
            <ToggleRow
              label="Maintenance Mode"
              hint="Temporarily block new trades platform-wide."
              checked={maintenanceMode}
              onChange={setMaintenanceMode}
            />
            <ToggleRow
              label="Require KYC to Trade"
              hint="Unverified users can't buy, sell, or withdraw."
              checked={requireKyc}
              onChange={setRequireKyc}
            />
            <ToggleRow
              label="Auto-approve Gift Cards"
              hint="Skip manual review for listings under $50."
              checked={autoApproveGiftCards}
              onChange={setAutoApproveGiftCards}
            />
          </div>
        </Card>

        <Card>
          <h3 className="mb-1 text-[14px] font-semibold text-zinc-900 dark:text-white">Admin Notifications</h3>
          <p className="mb-2 text-[12px] text-zinc-400 dark:text-zinc-500">
            How you're notified about pending reviews and platform events.
          </p>
          <div className="divide-y divide-zinc-100 dark:divide-white/[0.06]">
            <ToggleRow
              label="Email Alerts"
              hint="New KYC and gift card submissions."
              checked={emailAlerts}
              onChange={setEmailAlerts}
            />
            <ToggleRow
              label="SMS Alerts"
              hint="Large withdrawals over ₦1,000,000."
              checked={smsAlerts}
              onChange={setSmsAlerts}
            />
          </div>
        </Card>

        <Card className="lg:col-span-2">
          <h3 className="mb-4 text-[14px] font-semibold text-zinc-900 dark:text-white">Admin Profile</h3>
          <div className="grid grid-cols-1 gap-x-4 sm:grid-cols-2">
            <Field label="Full Name" defaultValue="Admin User" />
            <Field label="Email" type="email" defaultValue="admin@muchexchange.com" />
          </div>
          <Button size="md" className="mt-1">
            Save Changes
          </Button>
        </Card>
      </div>
    </AdminLayout>
  );
}
