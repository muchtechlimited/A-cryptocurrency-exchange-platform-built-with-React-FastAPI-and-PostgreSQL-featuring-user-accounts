import { Link } from 'react-router-dom';
import { ShieldCheck, TrendingUp, Zap, Headset } from 'lucide-react';
import PublicNavbar from '../components/PublicNavbar';
import PhoneMockup from '../components/PhoneMockup';
import Button from '../components/ui/Button';

const badges = [
  { icon: ShieldCheck, title: 'Secure Platform', sub: 'Bank-level security' },
  { icon: TrendingUp, title: 'Best Rates', sub: 'Competitive prices' },
  { icon: Zap, title: 'Instant Transactions', sub: 'Quick & easy' },
  { icon: Headset, title: '24/7 Support', sub: "We're here for you" },
];

const partners = ['BINANCE', 'coinbase', 'Trustpilot', 'CoinGecko'];

export default function Landing() {
  return (
    <div className="min-h-screen bg-white dark:bg-[#08090B]">
      <PublicNavbar />

      <section className="relative overflow-hidden">
        <div
          className="pointer-events-none absolute inset-x-0 top-0 h-[560px] opacity-70 dark:opacity-100"
          style={{ backgroundImage: 'radial-gradient(circle at 75% 15%, rgba(245,181,22,.14), transparent 55%)' }}
        />
        <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-5 py-16 sm:px-8 sm:py-20 lg:grid-cols-2 lg:py-28">
          <div>
            <span className="mb-5 inline-flex items-center gap-1.5 rounded-full border border-brand-500/30 bg-brand-500/10 px-3 py-1 text-[11.5px] font-semibold text-brand-600 dark:text-brand-400">
              ● Trade Crypto with Confidence
            </span>
            <h1 className="font-display text-[38px] font-bold leading-[1.1] tracking-tight text-zinc-900 dark:text-white sm:text-[50px]">
              Fast. Secure. <span className="text-brand-500">Reliable.</span>
            </h1>
            <p className="mt-5 max-w-md text-[15px] leading-relaxed text-zinc-500 dark:text-zinc-400">
              Buy, sell and trade cryptocurrencies with ease on Much Exchange.
            </p>

            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/signup">
                <Button size="lg">Get Started</Button>
              </Link>
              <a href="#features">
                <Button variant="secondary" size="lg">Learn More</Button>
              </a>
            </div>

            <div className="mt-12 grid grid-cols-2 gap-x-6 gap-y-6 sm:grid-cols-4">
              {badges.map((b) => (
                <div key={b.title} className="flex items-start gap-2.5">
                  <b.icon size={18} className="mt-0.5 shrink-0 text-brand-500" />
                  <div>
                    <p className="text-[12.5px] font-semibold text-zinc-800 dark:text-zinc-100">{b.title}</p>
                    <p className="text-[11px] text-zinc-400 dark:text-zinc-500">{b.sub}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative flex justify-center py-6 lg:justify-end">
            <PhoneMockup />
          </div>
        </div>

        <div className="border-t border-zinc-200 dark:border-white/10">
          <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-center gap-x-12 gap-y-4 px-5 py-8 sm:px-8">
            {partners.map((p) => (
              <span
                key={p}
                className="text-[15px] font-bold tracking-wide text-zinc-300 grayscale dark:text-zinc-700"
              >
                {p}
              </span>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
