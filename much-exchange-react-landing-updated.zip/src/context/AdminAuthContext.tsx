import { createContext, useContext, useState, type ReactNode } from 'react';
import { apiRequest, clearAdminToken, setAdminToken, getAdminToken } from '../lib/api';

const STORAGE_KEY = 'much_exchange_admin_auth';

interface LoginResponseUser {
  id: string;
  email: string;
  full_name: string;
  is_admin: boolean;
}

interface LoginResponse {
  access_token: string;
  token_type: string;
  user: LoginResponseUser;
}

interface AdminAuthValue {
  isAuthenticated: boolean;
  adminName: string;
  adminEmail: string;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
}

const AdminAuthContext = createContext<AdminAuthValue | undefined>(undefined);

function readStoredAuth(): { name: string; email: string } | null {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    // A stored session is only meaningful if we still have the token too.
    if (!getAdminToken()) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function AdminAuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<{ name: string; email: string } | null>(() => readStoredAuth());

  async function login(email: string, password: string) {
    const data = await apiRequest<LoginResponse>('/auth/login', {
      method: 'POST',
      body: { email: email.trim(), password },
      auth: false,
    });

    if (!data.user.is_admin) {
      throw new Error('This account does not have admin access.');
    }

    setAdminToken(data.access_token);
    const record = { name: data.user.full_name || 'Admin', email: data.user.email };
    try {
      sessionStorage.setItem(STORAGE_KEY, JSON.stringify(record));
    } catch {
      /* sessionStorage unavailable — session still works for this tab via state */
    }
    setSession(record);
  }

  function logout() {
    try {
      sessionStorage.removeItem(STORAGE_KEY);
    } catch {
      /* no-op */
    }
    clearAdminToken();
    setSession(null);
  }

  return (
    <AdminAuthContext.Provider
      value={{
        isAuthenticated: session !== null,
        adminName: session?.name ?? 'Admin',
        adminEmail: session?.email ?? '',
        login,
        logout,
      }}
    >
      {children}
    </AdminAuthContext.Provider>
  );
}

export function useAdminAuth() {
  const ctx = useContext(AdminAuthContext);
  if (!ctx) throw new Error('useAdminAuth must be used within an AdminAuthProvider');
  return ctx;
}
