import { createContext, useContext, useState, type ReactNode } from 'react';
import { apiRequest, clearCustomerToken, setCustomerToken, getCustomerToken } from '../lib/api';

const STORAGE_KEY = 'much_exchange_customer_auth';

interface AuthUser {
  id: string;
  email: string;
  full_name: string;
  /** Root-relative path on the API origin; run it through `avatarSrc()` before using as an <img src>. */
  avatar_url?: string | null;
}

interface LoginResponse {
  access_token: string;
  token_type: string;
  user: AuthUser & { is_admin: boolean };
}

interface RegisterPayload {
  email: string;
  password: string;
  full_name: string;
  bank_name: string;
  account_number: string;
  account_name: string;
}

interface AuthValue {
  isAuthenticated: boolean;
  user: AuthUser | null;
  login: (email: string, password: string) => Promise<void>;
  register: (payload: RegisterPayload) => Promise<void>;
  /**
   * Merges fresh fields into the cached user (and its localStorage copy)
   * without requiring a re-login. Needed because the topbar name, the
   * dashboard greeting and the MoreDrawer all read `full_name` from here —
   * without this, editing your name on the Profile page would leave the
   * rest of the app showing the old one until the next login.
   */
  updateUser: (patch: Partial<AuthUser>) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthValue | undefined>(undefined);

function readStoredUser(): AuthUser | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    if (!getCustomerToken()) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function persist(user: AuthUser, token: string) {
  setCustomerToken(token);
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
  } catch {
    /* localStorage unavailable — session still works for this tab via state */
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(() => readStoredUser());

  async function login(email: string, password: string) {
    const data = await apiRequest<LoginResponse>('/auth/login', {
      method: 'POST',
      body: { email: email.trim(), password },
      auth: false,
    });
    const { is_admin: _is_admin, ...rest } = data.user;
    persist(rest, data.access_token);
    setUser(rest);
  }

  async function register(payload: RegisterPayload) {
    const data = await apiRequest<LoginResponse>('/auth/register', {
      method: 'POST',
      body: payload,
      auth: false,
    });
    const { is_admin: _is_admin, ...rest } = data.user;
    persist(rest, data.access_token);
    setUser(rest);
  }

  function updateUser(patch: Partial<AuthUser>) {
    setUser((current) => {
      if (!current) return current;
      const next = { ...current, ...patch };
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {
        /* localStorage unavailable — in-memory state is still updated */
      }
      return next;
    });
  }

  function logout() {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      /* no-op */
    }
    clearCustomerToken();
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ isAuthenticated: user !== null, user, login, register, updateUser, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
}
