export interface WalletBalance {
  symbol: string;
  label: string;
  amount: string;
  fiat: string;
  changePct: number;
}

export const walletBalances: WalletBalance[] = [
  { symbol: 'NGN', label: 'Total Balance', amount: '₦2,450,000.00', fiat: '', changePct: 2.4 },
  { symbol: 'BTC', label: 'BTC Balance', amount: '0.04521 BTC', fiat: '₦1,485,010.00', changePct: 2.84 },
  { symbol: 'USDT', label: 'USDT Balance', amount: '1,250.50 USDT', fiat: '₦1,301,000.00', changePct: 0.15 },
  { symbol: 'NGN2', label: 'NGN Balance', amount: '₦610,000.00', fiat: '', changePct: 1.02 },
];

export interface MarketRow {
  pair: string;
  symbol: string;
  color: string;
  letter: string;
  price: string;
  changePct: number;
}

export const marketRows: MarketRow[] = [
  { pair: 'BTC/NGN', symbol: 'BTC', color: '#F59E0B', letter: 'B', price: '₦69,234,000.00', changePct: 2.45 },
  { pair: 'ETH/NGN', symbol: 'ETH', color: '#627EEA', letter: 'E', price: '₦2,980,000.00', changePct: 1.3 },
  { pair: 'USDT/NGN', symbol: 'USDT', color: '#14B8A6', letter: 'T', price: '₦1,250.00', changePct: 0.15 },
  { pair: 'BNB/NGN', symbol: 'BNB', color: '#F0B90B', letter: 'B', price: '₦444,000.00', changePct: -1.02 },
];

export type ChartRange = '1D' | '7D' | '1M' | '3M' | '6M' | '1Y' | 'ALL';

export const chartRanges: ChartRange[] = ['1D', '7D', '1M', '3M', '6M', '1Y', 'ALL'];

export const portfolioSeries: Record<ChartRange, { label: string; value: number }[]> = {
  '1D': [
    { label: '9AM', value: 2402 }, { label: '11AM', value: 2418 }, { label: '1PM', value: 2395 },
    { label: '3PM', value: 2431 }, { label: '5PM', value: 2444 }, { label: '7PM', value: 2450 },
  ],
  '7D': [
    { label: 'Mon', value: 2310 }, { label: 'Tue', value: 2345 }, { label: 'Wed', value: 2298 },
    { label: 'Thu', value: 2360 }, { label: 'Fri', value: 2402 }, { label: 'Sat', value: 2429 }, { label: 'Sun', value: 2450 },
  ],
  '1M': [
    { label: 'Apr 20', value: 2180 }, { label: 'Apr 27', value: 2245 }, { label: 'May 4', value: 2220 },
    { label: 'May 11', value: 2340 }, { label: 'May 18', value: 2310 }, { label: 'May 25', value: 2410 }, { label: 'Today', value: 2450 },
  ],
  '3M': [
    { label: 'Mar', value: 1890 }, { label: 'Mar', value: 1975 }, { label: 'Apr', value: 2040 },
    { label: 'Apr', value: 2120 }, { label: 'May', value: 2260 }, { label: 'May', value: 2380 }, { label: 'Jun', value: 2450 },
  ],
  '6M': [
    { label: 'Jan', value: 1420 }, { label: 'Feb', value: 1610 }, { label: 'Mar', value: 1780 },
    { label: 'Apr', value: 2020 }, { label: 'May', value: 2210 }, { label: 'Jun', value: 2450 },
  ],
  '1Y': [
    { label: 'Jul', value: 980 }, { label: 'Sep', value: 1120 }, { label: 'Nov', value: 1340 },
    { label: 'Jan', value: 1580 }, { label: 'Mar', value: 1890 }, { label: 'Jun', value: 2450 },
  ],
  'ALL': [
    { label: '2023', value: 320 }, { label: '2024', value: 780 }, { label: '2025', value: 1540 }, { label: '2026', value: 2450 },
  ],
};
