export interface WalletRowData {
  id: string;
  name: string;
  symbol: string;
  color: string;
  letter: string;
  balance: string;
  fiatEquivalent?: string;
}

export const walletRows: WalletRowData[] = [
  { id: 'ngn', name: 'NGN Wallet', symbol: 'NGN', color: '#22C55E', letter: 'N', balance: '₦610,000.00' },
  { id: 'btc', name: 'Bitcoin Wallet', symbol: 'BTC', color: '#F59E0B', letter: 'B', balance: '0.04521 BTC', fiatEquivalent: '≈ ₦1,485,010.00' },
  { id: 'usdt', name: 'USDT Wallet', symbol: 'USDT', color: '#14B8A6', letter: 'T', balance: '1,250.50 USDT', fiatEquivalent: '≈ ₦1,301,000.00' },
  { id: 'eth', name: 'Ethereum Wallet', symbol: 'ETH', color: '#627EEA', letter: 'E', balance: '0.25 ETH', fiatEquivalent: '≈ ₦745,000.00' },
];
