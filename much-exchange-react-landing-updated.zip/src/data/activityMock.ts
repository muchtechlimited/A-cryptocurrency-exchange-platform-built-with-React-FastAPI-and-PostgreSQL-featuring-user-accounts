export type TxStatus = 'Completed' | 'Pending' | 'Failed';

export interface Transaction {
  id: string;
  type: string;
  amount: string;
  status: TxStatus;
  date: string;
}

export const transactions: Transaction[] = [
  { id: 't1', type: 'Buy BTC', amount: '₦50,500.00', status: 'Completed', date: 'May 14, 2024 10:30 AM' },
  { id: 't2', type: 'Sell USDT', amount: '₦154,500.00', status: 'Completed', date: 'May 13, 2024 02:15 PM' },
  { id: 't3', type: 'Deposit BTC', amount: '0.005 BTC', status: 'Completed', date: 'May 12, 2024 09:20 AM' },
  { id: 't4', type: 'Withdraw USDT', amount: '100 USDT', status: 'Pending', date: 'May 11, 2024 04:45 PM' },
  { id: 't5', type: 'Buy USDT', amount: '₦100,000.00', status: 'Completed', date: 'May 10, 2024 11:10 AM' },
];

export interface NotificationItem {
  id: string;
  title: string;
  timestamp: string;
  read: boolean;
}

export const notifications: NotificationItem[] = [
  { id: 'n1', title: 'Your KYC has been approved', timestamp: 'May 14, 2024 10:30 AM', read: false },
  { id: 'n2', title: 'Deposit of 0.005 BTC confirmed', timestamp: 'May 12, 2024 09:20 AM', read: false },
  { id: 'n3', title: 'Your withdrawal request is pending', timestamp: 'May 11, 2024 04:45 PM', read: true },
  { id: 'n4', title: 'New login to your account detected', timestamp: 'May 10, 2024 11:00 PM', read: true },
];
