export interface Coin {
  id: string;
  symbol: string;
  name: string;
  color: string;
  letter: string;
  buyRate: number; // NGN per 1 unit
  sellRate: number; // NGN per 1 unit
  network: string;
  networkFee: number; // in coin units
  availableBalance: number; // in coin units, for withdraw
}

export const coins: Coin[] = [
  { id: 'btc', symbol: 'BTC', name: 'Bitcoin', color: '#F59E0B', letter: 'B', buyRate: 69500100, sellRate: 68500000, network: 'BTC Network', networkFee: 0.0002, availableBalance: 0.04521 },
  { id: 'eth', symbol: 'ETH', name: 'Ethereum', color: '#627EEA', letter: 'E', buyRate: 2980000, sellRate: 2940000, network: 'ERC20', networkFee: 0.002, availableBalance: 0.25 },
  { id: 'usdt', symbol: 'USDT', name: 'Tether', color: '#14B8A6', letter: 'T', buyRate: 1545, sellRate: 1530, network: 'TRC20', networkFee: 1, availableBalance: 1250.5 },
  { id: 'bnb', symbol: 'BNB', name: 'BNB', color: '#F0B90B', letter: 'B', buyRate: 448000, sellRate: 441000, network: 'BEP20', networkFee: 0.001, availableBalance: 0 },
];

export const networkOptions = ['TRC20', 'ERC20', 'BEP20'];
