export interface GiftCardBrand {
  id: string;
  name: string;
  color: string;
  letter: string;
  denominations: number[]; // in USD
  buyRate: number; // NGN per $1
  sellRate: number; // NGN per $1
}

export const giftCardBrands: GiftCardBrand[] = [
  { id: 'amazon', name: 'Amazon', color: '#FF9900', letter: 'A', denominations: [25, 50, 100, 200], buyRate: 1520, sellRate: 1180 },
  { id: 'itunes', name: 'iTunes', color: '#A855F7', letter: 'i', denominations: [25, 50, 100, 200], buyRate: 1480, sellRate: 1150 },
  { id: 'steam', name: 'Steam', color: '#1B2838', letter: 'S', denominations: [20, 50, 100], buyRate: 1500, sellRate: 1160 },
  { id: 'google-play', name: 'Google Play', color: '#00C853', letter: 'G', denominations: [25, 50, 100, 200], buyRate: 1490, sellRate: 1155 },
];

export type CardType = 'E-code' | 'Physical';
