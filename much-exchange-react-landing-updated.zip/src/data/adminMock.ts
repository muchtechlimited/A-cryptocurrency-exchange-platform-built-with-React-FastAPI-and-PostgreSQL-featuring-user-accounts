/* ---------------------------------------------------------------------- */
/* Admin-facing mock data — platform-wide stats, users, and review queues. */
/* ---------------------------------------------------------------------- */

export interface PlatformStat {
  label: string;
  value: string;
  changePct: number;
  hint?: string;
}

export const platformStats: PlatformStat[] = [
  { label: 'Total Users', value: '12,486', changePct: 4.8, hint: '+186 this week' },
  { label: "Today's Volume", value: '₦84.2M', changePct: 6.3, hint: 'All assets' },
  { label: 'Platform Revenue (MTD)', value: '₦6.94M', changePct: 2.1, hint: 'Fees + spread' },
  { label: 'Pending Reviews', value: '23', changePct: -8.4, hint: 'KYC + cards' },
];

export type AdminKycStatus = 'Verified' | 'Pending' | 'Unverified';
export type AccountStatus = 'Active' | 'Suspended';

export interface AdminUser {
  id: string;
  name: string;
  email: string;
  joined: string;
  kycStatus: AdminKycStatus;
  status: AccountStatus;
  walletValue: string;
  txCount: number;
}

export const adminUsers: AdminUser[] = [
  { id: 'u1', name: 'Moshood Adebayo', email: 'moshood.a@gmail.com', joined: 'Jan 12, 2025', kycStatus: 'Verified', status: 'Active', walletValue: '₦2,450,000.00', txCount: 58 },
  { id: 'u2', name: 'Ngozi Okafor', email: 'ngozi.okafor@gmail.com', joined: 'Feb 3, 2025', kycStatus: 'Verified', status: 'Active', walletValue: '₦890,200.00', txCount: 34 },
  { id: 'u3', name: 'Tunde Bakare', email: 'tunde.bakare@yahoo.com', joined: 'Mar 21, 2025', kycStatus: 'Pending', status: 'Active', walletValue: '₦120,000.00', txCount: 6 },
  { id: 'u4', name: 'Amaka Chukwu', email: 'amaka.c@outlook.com', joined: 'Apr 9, 2025', kycStatus: 'Verified', status: 'Suspended', walletValue: '₦0.00', txCount: 12 },
  { id: 'u5', name: 'Ibrahim Musa', email: 'ibrahim.musa@gmail.com', joined: 'May 2, 2025', kycStatus: 'Unverified', status: 'Active', walletValue: '₦45,000.00', txCount: 2 },
  { id: 'u6', name: 'Chiamaka Eze', email: 'chiamaka.eze@gmail.com', joined: 'Jun 18, 2025', kycStatus: 'Verified', status: 'Active', walletValue: '₦3,120,500.00', txCount: 91 },
  { id: 'u7', name: 'Emeka Nwosu', email: 'emeka.nwosu@gmail.com', joined: 'Jul 30, 2025', kycStatus: 'Pending', status: 'Active', walletValue: '₦560,000.00', txCount: 15 },
  { id: 'u8', name: 'Folake Adeyemi', email: 'folake.a@yahoo.com', joined: 'Aug 14, 2025', kycStatus: 'Verified', status: 'Active', walletValue: '₦210,750.00', txCount: 21 },
];

export type ReviewStatus = 'Pending' | 'Approved' | 'Rejected';

export interface KycRequest {
  id: string;
  userName: string;
  email: string;
  submitted: string;
  docType: string;
  status: ReviewStatus;
}

export const kycRequests: KycRequest[] = [
  { id: 'k1', userName: 'Tunde Bakare', email: 'tunde.bakare@yahoo.com', submitted: 'Aug 27, 2026 09:12 AM', docType: "Driver's License", status: 'Pending' },
  { id: 'k2', userName: 'Emeka Nwosu', email: 'emeka.nwosu@gmail.com', submitted: 'Aug 27, 2026 08:40 AM', docType: 'International Passport', status: 'Pending' },
  { id: 'k3', userName: 'Ibrahim Musa', email: 'ibrahim.musa@gmail.com', submitted: 'Aug 26, 2026 04:55 PM', docType: 'National ID (NIN)', status: 'Pending' },
  { id: 'k4', userName: 'Grace Adeleke', email: 'grace.adeleke@gmail.com', submitted: 'Aug 25, 2026 11:20 AM', docType: 'National ID (NIN)', status: 'Approved' },
  { id: 'k5', userName: 'Sunday Okonkwo', email: 'sunday.o@yahoo.com', submitted: 'Aug 24, 2026 02:05 PM', docType: "Driver's License", status: 'Rejected' },
];

export type GiftCardPaymentMethod = 'Bank Transfer' | 'Wallet Balance';

export interface GiftCardSubmission {
  id: string;
  userName: string;
  email: string;
  phone: string;
  brand: string;
  brandColor: string;
  brandLetter: string;
  value: string;
  offeredRate: string;
  payoutNaira: string;
  paymentMethod: GiftCardPaymentMethod;
  cardCode: string;
  submitted: string;
  status: ReviewStatus;
}

export const giftCardSubmissions: GiftCardSubmission[] = [
  {
    id: 'g1', userName: 'Chiamaka Eze', email: 'chiamaka.eze@gmail.com', phone: '0803 123 4567',
    brand: 'Amazon', brandColor: '#FF9900', brandLetter: 'A', value: '$200.00', offeredRate: '₦1,190/$',
    payoutNaira: '₦238,000', paymentMethod: 'Bank Transfer', cardCode: 'AZ7K-3M9P-QX2R-8LT4',
    submitted: 'Aug 27, 2026 10:02 AM', status: 'Pending',
  },
  {
    id: 'g2', userName: 'Folake Adeyemi', email: 'folake.adeyemi@gmail.com', phone: '0802 987 6543',
    brand: 'Steam', brandColor: '#1B2838', brandLetter: 'S', value: '$50.00', offeredRate: '₦980/$',
    payoutNaira: '₦49,000', paymentMethod: 'Wallet Balance', cardCode: 'ST4H-9J2K-5VBN-1QWE',
    submitted: 'Aug 27, 2026 09:15 AM', status: 'Pending',
  },
  {
    id: 'g3', userName: 'Ngozi Okafor', email: 'ngozi.okafor@gmail.com', phone: '0706 555 6677',
    brand: 'iTunes', brandColor: '#FA57C1', brandLetter: 'i', value: '$100.00', offeredRate: '₦1,050/$',
    payoutNaira: '₦105,000', paymentMethod: 'Bank Transfer', cardCode: 'IT9X-2M4L-7KJH-3RTY',
    submitted: 'Aug 26, 2026 06:48 PM', status: 'Pending',
  },
  {
    id: 'g4', userName: 'Moshood Adebayo', email: 'moshood.a@gmail.com', phone: '0813 222 9981',
    brand: 'Amazon', brandColor: '#FF9900', brandLetter: 'A', value: '$500.00', offeredRate: '₦1,190/$',
    payoutNaira: '₦595,000', paymentMethod: 'Bank Transfer', cardCode: 'AZ2Q-8N5M-1WER-6TYU',
    submitted: 'Aug 25, 2026 01:30 PM', status: 'Approved',
  },
  {
    id: 'g5', userName: 'Ibrahim Musa', email: 'ibrahim.musa@gmail.com', phone: '0701 444 5522',
    brand: 'Google Play', brandColor: '#00C566', brandLetter: 'G', value: '$30.00', offeredRate: '₦960/$',
    payoutNaira: '₦28,800', paymentMethod: 'Wallet Balance', cardCode: 'GP5Z-1X8C-4VBN-9MKL',
    submitted: 'Aug 24, 2026 03:22 PM', status: 'Rejected',
  },
];

export type AdminTxType = 'Buy' | 'Sell' | 'Deposit' | 'Withdraw' | 'Gift Card';
export type AdminTxStatus = 'Completed' | 'Pending' | 'Failed';

export interface AdminTransaction {
  id: string;
  userName: string;
  type: AdminTxType;
  asset: string;
  amount: string;
  status: AdminTxStatus;
  date: string;
}

export const adminTransactions: AdminTransaction[] = [
  { id: 'at1', userName: 'Moshood Adebayo', type: 'Buy', asset: 'BTC', amount: '₦50,500.00', status: 'Completed', date: 'Aug 27, 2026 10:30 AM' },
  { id: 'at2', userName: 'Chiamaka Eze', type: 'Sell', asset: 'USDT', amount: '₦154,500.00', status: 'Completed', date: 'Aug 27, 2026 09:15 AM' },
  { id: 'at3', userName: 'Ngozi Okafor', type: 'Deposit', asset: 'BTC', amount: '0.005 BTC', status: 'Completed', date: 'Aug 27, 2026 08:20 AM' },
  { id: 'at4', userName: 'Tunde Bakare', type: 'Withdraw', asset: 'USDT', amount: '100 USDT', status: 'Pending', date: 'Aug 26, 2026 04:45 PM' },
  { id: 'at5', userName: 'Folake Adeyemi', type: 'Gift Card', asset: 'Steam', amount: '$50.00', status: 'Pending', date: 'Aug 26, 2026 02:10 PM' },
  { id: 'at6', userName: 'Ibrahim Musa', type: 'Buy', asset: 'ETH', amount: '₦298,000.00', status: 'Failed', date: 'Aug 26, 2026 11:05 AM' },
  { id: 'at7', userName: 'Emeka Nwosu', type: 'Withdraw', asset: 'NGN', amount: '₦75,000.00', status: 'Completed', date: 'Aug 25, 2026 05:40 PM' },
  { id: 'at8', userName: 'Chiamaka Eze', type: 'Sell', asset: 'BNB', amount: '₦88,200.00', status: 'Completed', date: 'Aug 25, 2026 01:12 PM' },
  { id: 'at9', userName: 'Grace Adeleke', type: 'Buy', asset: 'USDT', amount: '₦231,750.00', status: 'Pending', date: 'Aug 27, 2026 11:48 AM' },
  { id: 'at10', userName: 'Sunday Okonkwo', type: 'Sell', asset: 'ETH', amount: '₦445,000.00', status: 'Pending', date: 'Aug 27, 2026 10:55 AM' },
  { id: 'at11', userName: 'Folake Adeyemi', type: 'Deposit', asset: 'USDT', amount: '250 USDT', status: 'Pending', date: 'Aug 27, 2026 09:40 AM' },
  { id: 'at12', userName: 'Ibrahim Musa', type: 'Withdraw', asset: 'NGN', amount: '₦120,000.00', status: 'Pending', date: 'Aug 27, 2026 08:05 AM' },
];

export interface AdminActivityItem {
  id: string;
  text: string;
  timestamp: string;
}

export const adminActivity: AdminActivityItem[] = [
  { id: 'a1', text: 'Tunde Bakare submitted a KYC document for review', timestamp: '12 min ago' },
  { id: 'a2', text: 'Folake Adeyemi listed a Steam gift card ($50.00)', timestamp: '38 min ago' },
  { id: 'a3', text: 'Withdrawal of ₦75,000.00 approved for Emeka Nwosu', timestamp: '1 hr ago' },
  { id: 'a4', text: 'New user Grace Adeleke signed up', timestamp: '2 hr ago' },
  { id: 'a5', text: 'BTC/NGN buy rate updated to ₦69,500,100', timestamp: '3 hr ago' },
];

export const platformVolumeSeries = [
  { label: 'Mon', value: 62 }, { label: 'Tue', value: 71 }, { label: 'Wed', value: 58 },
  { label: 'Thu', value: 84 }, { label: 'Fri', value: 79 }, { label: 'Sat', value: 91 }, { label: 'Sun', value: 84 },
];

export interface AdminRate {
  id: string;
  symbol: string;
  name: string;
  color: string;
  letter: string;
  buyRate: number;
  sellRate: number;
  autoSync: boolean;
}

export const adminRates: AdminRate[] = [
  { id: 'btc', symbol: 'BTC', name: 'Bitcoin', color: '#F59E0B', letter: 'B', buyRate: 69500100, sellRate: 68500000, autoSync: true },
  { id: 'eth', symbol: 'ETH', name: 'Ethereum', color: '#627EEA', letter: 'E', buyRate: 2980000, sellRate: 2940000, autoSync: true },
  { id: 'usdt', symbol: 'USDT', name: 'Tether', color: '#14B8A6', letter: 'T', buyRate: 1545, sellRate: 1530, autoSync: false },
  { id: 'bnb', symbol: 'BNB', name: 'BNB', color: '#F0B90B', letter: 'B', buyRate: 448000, sellRate: 441000, autoSync: true },
];
