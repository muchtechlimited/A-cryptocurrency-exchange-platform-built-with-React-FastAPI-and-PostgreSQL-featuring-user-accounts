import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Landing from './pages/Landing';
import Login from './pages/auth/Login';
import Signup from './pages/auth/Signup';
import ForgotPassword from './pages/auth/ForgotPassword';
import Dashboard from './pages/dashboard/Dashboard';
import Markets from './pages/dashboard/Markets';
import GiftCards from './pages/dashboard/GiftCards';
import Wallets from './pages/dashboard/Wallets';
import BuyCrypto from './pages/dashboard/BuyCrypto';
import SellCrypto from './pages/dashboard/SellCrypto';
import Deposit from './pages/dashboard/Deposit';
import Withdraw from './pages/dashboard/Withdraw';
import Kyc from './pages/dashboard/Kyc';
import Transactions from './pages/dashboard/Transactions';
import Notifications from './pages/dashboard/Notifications';
import Profile from './pages/dashboard/Profile';
import Settings from './pages/dashboard/Settings';
import Referral from './pages/dashboard/Referral';
import Support from './pages/dashboard/Support';
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminUsers from './pages/admin/AdminUsers';
import AdminTransactions from './pages/admin/AdminTransactions';
import AdminKyc from './pages/admin/AdminKyc';
import AdminGiftCards from './pages/admin/AdminGiftCards';
import AdminSupport from './pages/admin/AdminSupport';
import AdminAuditLog from './pages/admin/AdminAuditLog';
import AdminRates from './pages/admin/AdminRates';
import AdminSettings from './pages/admin/AdminSettings';
import AdminLogin from './pages/admin/AdminLogin';
import { AdminAuthProvider } from './context/AdminAuthContext';
import RequireAdminAuth from './components/admin/RequireAdminAuth';
import { AdminChromeProvider } from './components/admin/AdminChromeContext';
import { AuthProvider } from './context/AuthContext';
import RequireAuth from './components/RequireAuth';

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/dashboard" element={<RequireAuth><Dashboard /></RequireAuth>} />
          <Route path="/markets" element={<RequireAuth><Markets /></RequireAuth>} />
          <Route path="/gift-cards" element={<RequireAuth><GiftCards /></RequireAuth>} />
          <Route path="/wallets" element={<RequireAuth><Wallets /></RequireAuth>} />
          <Route path="/buy" element={<RequireAuth><BuyCrypto /></RequireAuth>} />
          <Route path="/sell" element={<RequireAuth><SellCrypto /></RequireAuth>} />
          <Route path="/deposit" element={<RequireAuth><Deposit /></RequireAuth>} />
          <Route path="/withdraw" element={<RequireAuth><Withdraw /></RequireAuth>} />
          <Route path="/kyc" element={<RequireAuth><Kyc /></RequireAuth>} />
          <Route path="/transactions" element={<RequireAuth><Transactions /></RequireAuth>} />
          <Route path="/notifications" element={<RequireAuth><Notifications /></RequireAuth>} />
          <Route path="/profile" element={<RequireAuth><Profile /></RequireAuth>} />
          <Route path="/settings" element={<RequireAuth><Settings /></RequireAuth>} />
          <Route path="/referral" element={<RequireAuth><Referral /></RequireAuth>} />
          <Route path="/support" element={<RequireAuth><Support /></RequireAuth>} />
        <Route
          path="/admin/login"
          element={
            <AdminAuthProvider>
              <AdminLogin />
            </AdminAuthProvider>
          }
        />
        <Route
          path="/admin"
          element={
            <AdminAuthProvider>
              <RequireAdminAuth>
                <AdminChromeProvider>
                  <AdminDashboard />
                </AdminChromeProvider>
              </RequireAdminAuth>
            </AdminAuthProvider>
          }
        />
        <Route
          path="/admin/users"
          element={
            <AdminAuthProvider>
              <RequireAdminAuth>
                <AdminChromeProvider>
                  <AdminUsers />
                </AdminChromeProvider>
              </RequireAdminAuth>
            </AdminAuthProvider>
          }
        />
        <Route
          path="/admin/transactions"
          element={
            <AdminAuthProvider>
              <RequireAdminAuth>
                <AdminChromeProvider>
                  <AdminTransactions />
                </AdminChromeProvider>
              </RequireAdminAuth>
            </AdminAuthProvider>
          }
        />
        <Route
          path="/admin/kyc"
          element={
            <AdminAuthProvider>
              <RequireAdminAuth>
                <AdminChromeProvider>
                  <AdminKyc />
                </AdminChromeProvider>
              </RequireAdminAuth>
            </AdminAuthProvider>
          }
        />
        <Route
          path="/admin/gift-cards"
          element={
            <AdminAuthProvider>
              <RequireAdminAuth>
                <AdminChromeProvider>
                  <AdminGiftCards />
                </AdminChromeProvider>
              </RequireAdminAuth>
            </AdminAuthProvider>
          }
        />
        <Route
          path="/admin/support"
          element={
            <AdminAuthProvider>
              <RequireAdminAuth>
                <AdminChromeProvider>
                  <AdminSupport />
                </AdminChromeProvider>
              </RequireAdminAuth>
            </AdminAuthProvider>
          }
        />
        <Route
          path="/admin/audit-log"
          element={
            <AdminAuthProvider>
              <RequireAdminAuth>
                <AdminChromeProvider>
                  <AdminAuditLog />
                </AdminChromeProvider>
              </RequireAdminAuth>
            </AdminAuthProvider>
          }
        />
        <Route
          path="/admin/rates"
          element={
            <AdminAuthProvider>
              <RequireAdminAuth>
                <AdminChromeProvider>
                  <AdminRates />
                </AdminChromeProvider>
              </RequireAdminAuth>
            </AdminAuthProvider>
          }
        />
        <Route
          path="/admin/settings"
          element={
            <AdminAuthProvider>
              <RequireAdminAuth>
                <AdminChromeProvider>
                  <AdminSettings />
                </AdminChromeProvider>
              </RequireAdminAuth>
            </AdminAuthProvider>
          }
        />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}
