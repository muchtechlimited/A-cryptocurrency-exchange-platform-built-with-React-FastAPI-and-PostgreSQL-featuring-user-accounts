/**
 * Support ticket API (`/support/tickets/...`).
 *
 * Session 10 found this backend fully written (model, schemas, router) but
 * never actually wired up: the router wasn't registered in app/main.py and
 * no migration had ever been generated for it, so none of these endpoints
 * existed at runtime until this session. See PROJECT_STATUS.md.
 */

import { apiRequest } from './api';

export type TicketSubject =
  | 'Deposit issue'
  | 'Withdrawal issue'
  | 'Buy / Sell issue'
  | 'Account & verification'
  | 'Something else';

export const TICKET_SUBJECTS: TicketSubject[] = [
  'Deposit issue',
  'Withdrawal issue',
  'Buy / Sell issue',
  'Account & verification',
  'Something else',
];

export type TicketStatus = 'open' | 'pending' | 'resolved';

export interface TicketApi {
  id: string;
  user_id: string;
  subject: string;
  message: string;
  reference: string | null;
  status: TicketStatus;
  admin_response: string | null;
  responded_by: string | null;
  responded_at: string | null;
  created_at: string;
  /** Only populated on the admin listing — see _to_out in the backend router. */
  user_email?: string | null;
  user_full_name?: string | null;
}

export const TICKET_STATUS_LABEL: Record<TicketStatus, string> = {
  open: 'Open',
  pending: 'Pending',
  resolved: 'Resolved',
};

// --- Customer ---

export function submitTicket(payload: { subject: TicketSubject; message: string; reference?: string }) {
  return apiRequest<TicketApi>('/support/tickets', {
    method: 'POST',
    body: payload,
    auth: 'customer',
  });
}

export function getMyTickets() {
  return apiRequest<TicketApi[]>('/support/tickets/me', { auth: 'customer' });
}

// --- Admin ---

export function listAllTickets() {
  return apiRequest<TicketApi[]>('/support/tickets/admin');
}

export function respondToTicket(
  ticketId: string,
  payload: { response: string; status?: 'pending' | 'resolved' },
) {
  return apiRequest<TicketApi>(`/support/tickets/admin/${ticketId}/respond`, {
    method: 'POST',
    body: payload,
  });
}
