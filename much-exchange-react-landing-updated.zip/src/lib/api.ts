/**
 * Shared API client for the Much Exchange FastAPI backend.
 *
 * Handles the base URL, attaching the bearer token, and turning FastAPI's
 * error shape ({"detail": "..."} or a Pydantic validation error array)
 * into a single readable message so callers can just `catch (e) { e.message }`.
 */

const BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

const ADMIN_TOKEN_KEY = 'much_exchange_admin_token';
const CUSTOMER_TOKEN_KEY = 'much_exchange_customer_token';

export function getAdminToken(): string | null {
  try {
    return sessionStorage.getItem(ADMIN_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setAdminToken(token: string) {
  try {
    sessionStorage.setItem(ADMIN_TOKEN_KEY, token);
  } catch {
    /* sessionStorage unavailable — requests will just go out unauthenticated */
  }
}

export function clearAdminToken() {
  try {
    sessionStorage.removeItem(ADMIN_TOKEN_KEY);
  } catch {
    /* no-op */
  }
}

// Customer sessions use localStorage (not sessionStorage) so a login
// survives closing the tab — matching normal "stay signed in" expectations
// for a consumer app, vs. the admin panel's tighter per-tab session.
export function getCustomerToken(): string | null {
  try {
    return localStorage.getItem(CUSTOMER_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setCustomerToken(token: string) {
  try {
    localStorage.setItem(CUSTOMER_TOKEN_KEY, token);
  } catch {
    /* localStorage unavailable — requests will just go out unauthenticated */
  }
}

export function clearCustomerToken() {
  try {
    localStorage.removeItem(CUSTOMER_TOKEN_KEY);
  } catch {
    /* no-op */
  }
}

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

function extractErrorMessage(body: unknown, fallback: string): string {
  if (body && typeof body === 'object' && 'detail' in body) {
    const detail = (body as { detail: unknown }).detail;
    if (typeof detail === 'string') return detail;
    if (Array.isArray(detail)) {
      // Pydantic validation error array: [{ loc, msg, type }, ...]
      return detail
        .map((d) => (d && typeof d === 'object' && 'msg' in d ? String((d as { msg: unknown }).msg) : JSON.stringify(d)))
        .join('; ');
    }
  }
  return fallback;
}

interface RequestOptions {
  method?: string;
  body?: unknown;
  /** Query params appended directly to the URL (FastAPI query-param endpoints, not JSON bodies). */
  query?: Record<string, string | number | boolean | undefined>;
  /** false = no Authorization header at all. 'admin' | 'customer' picks which stored session to attach. Defaults to 'admin' for backward compatibility with existing admin call sites. */
  auth?: false | 'admin' | 'customer';
}

function buildUrl(path: string, query?: RequestOptions['query']): string {
  const url = new URL(path.replace(/^\//, ''), BASE_URL.endsWith('/') ? BASE_URL : `${BASE_URL}/`);
  if (query) {
    for (const [key, value] of Object.entries(query)) {
      if (value !== undefined) url.searchParams.set(key, String(value));
    }
  }
  return url.toString();
}

export async function apiRequest<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const { method = 'GET', body, query, auth = 'admin' } = options;

  const headers: Record<string, string> = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (auth) {
    const token = auth === 'customer' ? getCustomerToken() : getAdminToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;
  }

  let response: Response;
  try {
    response = await fetch(buildUrl(path, query), {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError('Could not reach the server. Is the backend running?', 0);
  }

  const isJson = response.headers.get('content-type')?.includes('application/json');
  const parsed = isJson ? await response.json().catch(() => null) : null;

  if (!response.ok) {
    throw new ApiError(extractErrorMessage(parsed, `Request failed (${response.status})`), response.status);
  }

  return parsed as T;
}

export { BASE_URL };
