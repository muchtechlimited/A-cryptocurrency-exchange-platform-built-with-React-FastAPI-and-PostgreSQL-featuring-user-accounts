/**
 * Profile + account settings API (`/users/me/...`).
 *
 * These endpoints all already existed on the backend (see
 * `app/routers/users.py`) — this module is the frontend wiring for them.
 *
 * Note on what is NOT here, deliberately:
 *  - There is no "change email" endpoint. Email is the account's identity
 *    (it's the login field and carries the verification token), and
 *    `ProfileUpdate` doesn't accept it. The UI shows it read-only rather
 *    than offering an edit that would silently do nothing.
 *  - There is no session/device-listing endpoint, so there's nothing to
 *    build a "Sessions" view against yet.
 */

import { apiRequest, ApiError, BASE_URL, getCustomerToken } from './api';

export interface ProfileApi {
  id: string;
  email: string;
  full_name: string;
  phone_number: string | null;
  country: string | null;
  avatar_url: string | null;
  kyc_status: 'not_submitted' | 'pending' | 'approved' | 'rejected';
  is_verified: boolean;
  created_at: string;
  bank_name: string | null;
  account_number: string | null;
  account_name: string | null;
  bvn: string | null;
}

export interface SettingsApi {
  email_notifications_enabled: boolean;
  sms_notifications_enabled: boolean;
  two_factor_enabled: boolean;
}

/** Partial update — only send the fields that actually changed. */
export interface ProfileUpdatePayload {
  full_name?: string;
  phone_number?: string;
  country?: string;
}

export function getProfile() {
  return apiRequest<ProfileApi>('/users/me/profile', { auth: 'customer' });
}

export function updateProfile(payload: ProfileUpdatePayload) {
  return apiRequest<ProfileApi>('/users/me/profile', {
    method: 'PUT',
    body: payload,
    auth: 'customer',
  });
}

export function getSettings() {
  return apiRequest<SettingsApi>('/users/me/settings', { auth: 'customer' });
}

export function updateSettings(payload: Partial<SettingsApi>) {
  return apiRequest<SettingsApi>('/users/me/settings', {
    method: 'PUT',
    body: payload,
    auth: 'customer',
  });
}

export function changePassword(current_password: string, new_password: string) {
  return apiRequest<{ message: string }>('/users/me/change-password', {
    method: 'POST',
    body: { current_password, new_password },
    auth: 'customer',
  });
}

/**
 * Uploads a new avatar. This is a multipart upload, so it bypasses
 * `apiRequest` (which only sends JSON) and builds the request by hand —
 * same approach `kycApi.submitKyc` uses, for the same reason. Crucially
 * the Content-Type header is left unset so the browser adds the multipart
 * boundary itself.
 */
export function uploadAvatar(file: File): Promise<ProfileApi> {
  const url = new URL('users/me/avatar', BASE_URL.endsWith('/') ? BASE_URL : `${BASE_URL}/`);

  const formData = new FormData();
  formData.append('file', file);

  const token = getCustomerToken();

  return fetch(url.toString(), {
    method: 'POST',
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    body: formData,
  }).then(async (res) => {
    const body = await res.json().catch(() => null);
    if (!res.ok) {
      const message =
        body && typeof body === 'object' && 'detail' in body
          ? typeof (body as { detail: unknown }).detail === 'string'
            ? (body as { detail: string }).detail
            : JSON.stringify((body as { detail: unknown }).detail)
          : `Request failed (${res.status})`;
      throw new ApiError(message, res.status);
    }
    return body as ProfileApi;
  });
}

/**
 * Avatars are saved to the *public* upload dir and stored as a root-relative
 * path (e.g. "/uploads/avatars/<uuid>.jpg"), which points at the API origin,
 * not the frontend's. So it needs the API base URL prefixed onto it before
 * it can go in an <img src>. Unlike KYC documents, no auth is needed —
 * avatars are served statically (see the StaticFiles mount in app/main.py).
 */
export function avatarSrc(avatarUrl: string | null): string | null {
  if (!avatarUrl) return null;
  if (/^https?:\/\//i.test(avatarUrl)) return avatarUrl;
  const base = BASE_URL.endsWith('/') ? BASE_URL.slice(0, -1) : BASE_URL;
  return `${base}${avatarUrl.startsWith('/') ? '' : '/'}${avatarUrl}`;
}

/** Matches the backend's ALLOWED_CONTENT_TYPES for uploads, minus PDF (an avatar should be an image). */
export const AVATAR_ACCEPT = 'image/jpeg,image/png,image/webp';

export const KYC_STATUS_LABEL: Record<ProfileApi['kyc_status'], string> = {
  not_submitted: 'Not verified',
  pending: 'Under review',
  approved: 'Verified',
  rejected: 'Rejected',
};
