import { apiRequest } from './api';
import type { WalletRowData } from '../data/walletsMock';
import type { Transaction as UiTransaction, TxStatus } from '../data/activityMock';

export interface WalletApi {
  id: string;
  currency: string;
  available_balance: string;
  frozen_balance: string;
  total_balance: string;
  updated_at: string;
}

export interface TransactionApi {
  id: string;
  user_id: string;
  wallet_id: string;
  type: string;
  status: 'pending' | 'completed' | 'rejected';
  currency: string;
  amount: string;
  fee_amount: string;
  balance_after: string | null;
  reference: string | null;
  description: string | null;
  created_at: string;
}

export interface ExchangeRateApi {
  currency: string;
  buy_rate_ngn: string;
  sell_rate_ngn: string;
  buy_fee_percentage: string;
  sell_fee_percentage: string;
  withdrawal_network_fee: string;
  withdrawal_service_fee: string;
  updated_at: string;
}

export function getMyWallets() {
  return apiRequest<WalletApi[]>('/wallets/me', { auth: 'customer' });
}

export function getMyTransactions() {
  return apiRequest<TransactionApi[]>('/wallets/me/transactions', { auth: 'customer' });
}

/** Public (any logged-in user) — used to show an approximate NGN value next to crypto balances. */
export function getRates() {
  return apiRequest<ExchangeRateApi[]>('/rates', { auth: 'customer' });
}

const WALLET_DISPLAY: Record<string, { name: string; color: string; letter: string }> = {
  NGN: { name: 'NGN Wallet', color: '#22C55E', letter: 'N' },
  BTC: { name: 'Bitcoin Wallet', color: '#F59E0B', letter: 'B' },
  USDT: { name: 'USDT Wallet', color: '#14B8A6', letter: 'T' },
};

function formatNgn(value: number) {
  return `₦${value.toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function formatCrypto(value: number, currency: string) {
  // BTC conventionally shown with more decimal places than USDT
  const decimals = currency === 'BTC' ? 8 : 2;
  return `${value.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })} ${currency}`;
}

/**
 * Adapts a backend wallet + the current rate sheet into the shape
 * WalletRow was built around. Only known currencies (NGN/BTC/USDT) are
 * shown — the mock's 4th "ETH Wallet" row doesn't correspond to anything
 * the backend supports, so it's dropped rather than shown with fake data.
 */
export function toUiWallet(wallet: WalletApi, rates: ExchangeRateApi[]): WalletRowData | null {
  const display = WALLET_DISPLAY[wallet.currency];
  if (!display) return null;

  const balanceNum = Number(wallet.available_balance);

  if (wallet.currency === 'NGN') {
    return {
      id: wallet.id,
      name: display.name,
      symbol: wallet.currency,
      color: display.color,
      letter: display.letter,
      balance: formatNgn(balanceNum),
    };
  }

  const rate = rates.find((r) => r.currency === wallet.currency);
  const fiatEquivalent = rate ? formatNgn(balanceNum * Number(rate.sell_rate_ngn)) : undefined;

  return {
    id: wallet.id,
    name: display.name,
    symbol: wallet.currency,
    color: display.color,
    letter: display.letter,
    balance: formatCrypto(balanceNum, wallet.currency),
    fiatEquivalent: fiatEquivalent ? `≈ ${fiatEquivalent}` : undefined,
  };
}

const TYPE_LABEL: Record<string, string> = {
  deposit: 'Deposit',
  withdrawal: 'Withdraw',
  buy_btc: 'Buy BTC',
  sell_btc: 'Sell BTC',
  buy_usdt: 'Buy USDT',
  sell_usdt: 'Sell USDT',
  admin_credit: 'Admin Credit',
  admin_debit: 'Admin Debit',
  gift_card_sell: 'Gift Card Sale',
  buy_gift_card: 'Buy Gift Card',
};

const STATUS_MAP: Record<TransactionApi['status'], TxStatus> = {
  completed: 'Completed',
  pending: 'Pending',
  rejected: 'Failed',
};

function formatTxDate(iso: string) {
  try {
    return new Date(iso).toLocaleString('en-US', {
      month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

function formatTxAmount(tx: TransactionApi): string {
  const value = Number(tx.amount);
  if (tx.currency === 'NGN') return formatNgn(value);
  return formatCrypto(value, tx.currency);
}

/**
 * Adapts a backend transaction into the shape the existing Transactions
 * page (rows, type/status filters) was built around, so that UI doesn't
 * need to change — only where its data comes from.
 *
 * Deposit/withdrawal types are generic in the backend (currency is a
 * separate field), so the currency is appended here to get labels like
 * "Deposit NGN" — this also keeps the page's existing substring-based
 * type filter ("Deposit", "Withdraw", "Buy", "Sell") working correctly.
 */
export function toUiTransaction(tx: TransactionApi): UiTransaction {
  const baseLabel = TYPE_LABEL[tx.type] ?? tx.type;
  const label = tx.type === 'deposit' || tx.type === 'withdrawal' ? `${baseLabel} ${tx.currency}` : baseLabel;

  return {
    id: tx.id,
    type: label,
    amount: formatTxAmount(tx),
    status: STATUS_MAP[tx.status] ?? 'Pending',
    date: formatTxDate(tx.created_at),
  };
}
