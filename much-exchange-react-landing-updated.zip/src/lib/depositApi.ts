import { apiRequest, ApiError } from './api';

// --- Company deposit addresses (crypto) ---

export interface CompanyWalletAddressApi {
  currency: string;
  address: string;
  network_note: string | null;
  updated_at: string;
}

export function getCompanyWallets() {
  return apiRequest<CompanyWalletAddressApi[]>('/company-wallets', { auth: 'customer' });
}

// --- Crypto deposits (manual TxID review) ---

export interface CryptoDepositApi {
  id: string;
  user_id: string;
  currency: string;
  amount: string;
  tx_hash: string;
  status: 'pending' | 'approved' | 'rejected';
  rejection_reason: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
}

export function submitCryptoDeposit(payload: { currency: 'BTC' | 'USDT'; amount: string; tx_hash: string }) {
  return apiRequest<CryptoDepositApi>('/deposits/crypto', {
    method: 'POST',
    body: payload,
    auth: 'customer',
  });
}

export function getMyCryptoDeposits() {
  return apiRequest<CryptoDepositApi[]>('/deposits/crypto/me', { auth: 'customer' });
}

// --- NGN deposits via Paystack ---

export interface NGNDepositInitResponseApi {
  reference: string;
  authorization_url: string;
}

export function initializeNgnDeposit(amount: string) {
  return apiRequest<NGNDepositInitResponseApi>('/deposits/ngn/initialize', {
    method: 'POST',
    body: { amount },
    auth: 'customer',
  });
}

/**
 * Paystack isn't configured in every environment (blank secret/public keys
 * until an admin sets them up), so this never throws for that specific
 * case — it resolves to `{ unavailable: true }` instead, letting the UI
 * show a friendly "card payments aren't available yet" message rather
 * than a raw error. Any other failure still throws normally.
 */
export async function initializeNgnDepositSafe(
  amount: string,
): Promise<{ unavailable: false; data: NGNDepositInitResponseApi } | { unavailable: true }> {
  try {
    const data = await initializeNgnDeposit(amount);
    return { unavailable: false, data };
  } catch (err) {
    if (err instanceof ApiError && (err.status === 503 || err.status === 500 || err.status === 400)) {
      return { unavailable: true };
    }
    throw err;
  }
}

// --- NGN deposits via direct bank transfer ---

export interface NGNBankTransferApi {
  id: string;
  user_id: string;
  amount: string;
  reference_number: string;
  status: 'pending' | 'approved' | 'rejected';
  rejection_reason: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
}

export interface NGNBankTransferInitiateResponseApi {
  deposit: NGNBankTransferApi;
  bank_name: string;
  account_number: string;
  account_name: string;
  warning: string;
}

export function initiateNgnBankTransfer(amount: string) {
  return apiRequest<NGNBankTransferInitiateResponseApi>('/deposits/ngn/bank-transfer/initiate', {
    method: 'POST',
    body: { amount },
    auth: 'customer',
  });
}

/**
 * No `CompanyBankAccount` row means bank-transfer deposits aren't set up
 * yet — the backend returns a clear 503 for that. Same "never let the raw
 * error reach the user" treatment as the Paystack path above.
 */
export async function initiateNgnBankTransferSafe(
  amount: string,
): Promise<{ unavailable: false; data: NGNBankTransferInitiateResponseApi } | { unavailable: true }> {
  try {
    const data = await initiateNgnBankTransfer(amount);
    return { unavailable: false, data };
  } catch (err) {
    if (err instanceof ApiError && err.status === 503) {
      return { unavailable: true };
    }
    throw err;
  }
}

export function getMyNgnBankTransfers() {
  return apiRequest<NGNBankTransferApi[]>('/deposits/ngn/bank-transfer/me', { auth: 'customer' });
}

// --- Shared formatting/status helpers for deposit history lists ---

export function formatNgn(value: string | number) {
  const n = typeof value === 'string' ? Number(value) : value;
  return `₦${n.toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function formatDateTime(iso: string) {
  try {
    return new Date(iso).toLocaleString('en-US', {
      month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

export function statusBadgeClasses(status: string) {
  if (status === 'approved') return 'bg-up-500/10 text-up-500';
  if (status === 'pending') return 'bg-pending-500/10 text-pending-500';
  return 'bg-down-500/10 text-down-500';
}

export function statusLabel(status: string) {
  return status.charAt(0).toUpperCase() + status.slice(1);
}
