import { apiRequest } from './api';

export type TradingCurrency = 'BTC' | 'USDT';
export type OrderSide = 'buy' | 'sell';

export interface OrderPreviewApi {
  side: string;
  currency: string;
  crypto_amount: string;
  rate_applied: string;
  ngn_amount: string;
  fee_percentage: string;
  fee_amount_ngn: string;
  net_ngn_amount: string;
}

export interface OrderApi {
  id: string;
  user_id: string;
  side: string;
  currency: string;
  crypto_amount: string;
  rate_applied: string;
  fee_percentage: string;
  fee_amount_ngn: string;
  ngn_amount: string;
  net_ngn_amount: string;
  status: 'pending' | 'approved' | 'rejected';
  rejection_reason: string | null;
  rejection_action: string | null;
  created_at: string;
  reviewed_by: string | null;
  reviewed_at: string | null;
}

function previewOrder(side: OrderSide, currency: TradingCurrency, cryptoAmount: string) {
  return apiRequest<OrderPreviewApi>(`/trading/${side}/preview`, {
    method: 'POST',
    body: { currency, crypto_amount: cryptoAmount },
    auth: 'customer',
  });
}

function placeOrder(side: OrderSide, currency: TradingCurrency, cryptoAmount: string) {
  return apiRequest<OrderApi>(`/trading/${side}`, {
    method: 'POST',
    body: { currency, crypto_amount: cryptoAmount },
    auth: 'customer',
  });
}

export const previewBuy = (currency: TradingCurrency, cryptoAmount: string) => previewOrder('buy', currency, cryptoAmount);
export const previewSell = (currency: TradingCurrency, cryptoAmount: string) => previewOrder('sell', currency, cryptoAmount);
export const placeBuyOrder = (currency: TradingCurrency, cryptoAmount: string) => placeOrder('buy', currency, cryptoAmount);
export const placeSellOrder = (currency: TradingCurrency, cryptoAmount: string) => placeOrder('sell', currency, cryptoAmount);

export function getMyOrders() {
  return apiRequest<OrderApi[]>('/trading/me/orders', { auth: 'customer' });
}
