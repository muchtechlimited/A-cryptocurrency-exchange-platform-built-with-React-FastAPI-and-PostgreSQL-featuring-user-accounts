import { apiRequest, ApiError, BASE_URL, getCustomerToken } from './api';

export interface GiftCardAdminDetailApi {
  id: string;
  user_id: string;
  brand: string;
  card_type: string;
  card_country: string;
  card_currency: string;
  card_denomination: string;
  payment_method: string;
  much_exchange_rate: string;
  expected_payout: string;
  actual_payout: string | null;
  verification_result: string;
  status: 'pending' | 'approved' | 'rejected';
  rejection_reason: string | null;
  has_card_image: boolean;
  created_at: string;
  vendor: string | null;
  vendor_transaction_id: string | null;
  current_vendor_rate: string | null;
  api_webhook_status: string;
  verification_notes: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  redemption_code_masked: string;
  user_email: string | null;
  user_full_name: string | null;
  user_phone: string | null;
}

const BRAND_COLORS: Record<string, string> = {
  Amazon: '#FF9900',
  iTunes: '#A855F7',
  Steam: '#1B2838',
  'Google Play': '#00C853',
};

export function brandColor(brand: string): string {
  return BRAND_COLORS[brand] ?? '#6B7280';
}

function formatMoney(value: string): string {
  const n = Number(value);
  if (!Number.isFinite(n)) return value;
  return `₦${n.toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
}

function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleString('en-US', {
      month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

const PAYMENT_METHOD_LABEL: Record<string, string> = {
  bank_transfer: 'Bank Transfer',
  wallet_balance: 'Wallet Balance',
};

const STATUS_LABEL: Record<string, 'Pending' | 'Approved' | 'Rejected'> = {
  pending: 'Pending',
  approved: 'Approved',
  rejected: 'Rejected',
};

/**
 * Adapts the backend's raw admin detail shape into the display-ready
 * shape the existing gift-card UI (rows, cards, modal) was built around —
 * so those components don't need to change, only where their data comes from.
 */
export function toUiSubmission(s: GiftCardAdminDetailApi) {
  return {
    id: s.id,
    userName: s.user_full_name || 'Unknown user',
    email: s.user_email || '—',
    phone: s.user_phone || '—',
    brand: s.brand,
    brandColor: brandColor(s.brand),
    brandLetter: s.brand.charAt(0).toUpperCase(),
    value: `${s.card_currency}${Number(s.card_denomination).toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
    offeredRate: `₦${Number(s.much_exchange_rate).toLocaleString(undefined, { maximumFractionDigits: 0 })}/${s.card_currency === 'USD' ? '$' : s.card_currency}`,
    payoutNaira: formatMoney(s.actual_payout ?? s.expected_payout),
    paymentMethod: PAYMENT_METHOD_LABEL[s.payment_method] ?? s.payment_method,
    cardCode: s.redemption_code_masked,
    submitted: formatDate(s.created_at),
    status: STATUS_LABEL[s.status] ?? 'Pending',
    // extra fields the mock never had, kept for the extended detail view
    vendor: s.vendor,
    vendorTransactionId: s.vendor_transaction_id,
    currentVendorRate: s.current_vendor_rate,
    verificationResult: s.verification_result,
    apiWebhookStatus: s.api_webhook_status,
    hasCardImage: s.has_card_image,
    rejectionReason: s.rejection_reason,
  };
}

export type UiGiftCardSubmission = ReturnType<typeof toUiSubmission>;

export interface GiftCardStatsApi {
  pending_count: number;
  approved_count: number;
  rejected_count: number;
  total_value_ngn: string;
}

export function listGiftCardSubmissions(statusFilter?: 'pending' | 'approved' | 'rejected') {
  return apiRequest<GiftCardAdminDetailApi[]>('/gift-cards/admin/pending', {
    query: statusFilter ? { status_filter: statusFilter } : undefined,
  });
}

export function getGiftCardStats() {
  return apiRequest<GiftCardStatsApi>('/gift-cards/admin/stats');
}

export function revealRedemptionCode(submissionId: string) {
  return apiRequest<{ redemption_code: string }>(`/gift-cards/admin/${submissionId}/redemption-code`);
}

export function reviewGiftCardSubmission(
  submissionId: string,
  payload: { approve: boolean; actual_payout?: number; rejection_reason?: string },
) {
  return apiRequest<GiftCardAdminDetailApi>(`/gift-cards/admin/${submissionId}/review`, {
    method: 'POST',
    body: payload,
  });
}

export function cardImageUrl(submissionId: string) {
  // Not directly fetchable via <img src> since it needs an Authorization
  // header — components should fetch this as a blob and create an object URL.
  return `/gift-cards/documents/${submissionId}/card-image`;
}

// --- Customer-facing (buy from us / sell to us) ---

export interface GiftCardCatalogEntryApi {
  brand: string;
  card_type: string;
  card_country: string;
  card_currency: string;
  card_denomination: string;
  sell_rate_ngn: string;
  price_ngn: string;
  quantity_available: number;
}

export interface GiftCardPurchaseApi {
  id: string;
  user_id: string;
  brand: string;
  card_type: string;
  card_country: string;
  card_currency: string;
  card_denomination: string;
  sell_rate_ngn: string;
  total_cost_ngn: string;
  payment_method: string;
  status: string;
  delivered_code: string | null;
  created_at: string;
}

export interface GiftCardMineApi {
  id: string;
  brand: string;
  card_type: string;
  card_country: string;
  card_currency: string;
  card_denomination: string;
  payment_method: string;
  much_exchange_rate: string;
  expected_payout: string;
  actual_payout: string | null;
  verification_result: string;
  status: 'pending' | 'approved' | 'rejected';
  rejection_reason: string | null;
  has_card_image: boolean;
  created_at: string;
}

export interface GiftCardRateApi {
  brand: string;
  buy_rate_ngn: string;
  sell_rate_ngn: string;
  updated_at: string;
}

export function getGiftCardRates() {
  return apiRequest<GiftCardRateApi[]>('/gift-cards/rates', { auth: 'customer' });
}

export function getGiftCardCatalog() {
  return apiRequest<GiftCardCatalogEntryApi[]>('/gift-cards/catalog', { auth: 'customer' });
}

export function buyGiftCard(payload: {
  brand: string;
  card_type: string;
  card_country: string;
  card_currency: string;
  card_denomination: number;
  payment_method?: string;
}) {
  return apiRequest<GiftCardPurchaseApi>('/gift-cards/buy', {
    method: 'POST',
    body: { payment_method: 'wallet_balance', ...payload },
    auth: 'customer',
  });
}

export function getMyGiftCardPurchases() {
  return apiRequest<GiftCardPurchaseApi[]>('/gift-cards/purchases/me', { auth: 'customer' });
}

export function getMyGiftCardSubmissions() {
  return apiRequest<GiftCardMineApi[]>('/gift-cards/me', { auth: 'customer' });
}

export function submitGiftCardForSale(fields: {
  brand: string;
  card_type: string;
  card_country: string;
  card_currency: string;
  card_denomination: number;
  redemption_code: string;
  payment_method: string;
}) {
  // The backend endpoint takes these as query params (plus an optional
  // multipart file we're not sending here), so this bypasses apiRequest's
  // JSON-body handling and builds the query string directly.
  const url = new URL('gift-cards/submit', BASE_URL.endsWith('/') ? BASE_URL : `${BASE_URL}/`);
  Object.entries(fields).forEach(([key, value]) => url.searchParams.set(key, String(value)));

  const token = getCustomerToken();
  return fetch(url.toString(), {
    method: 'POST',
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  }).then(async (res) => {
    const body = await res.json().catch(() => null);
    if (!res.ok) {
      const message =
        body && typeof body === 'object' && 'detail' in body
          ? typeof (body as { detail: unknown }).detail === 'string'
            ? (body as { detail: string }).detail
            : JSON.stringify((body as { detail: unknown }).detail)
          : `Request failed (${res.status})`;
      throw new ApiError(message, res.status);
    }
    return body as GiftCardMineApi;
  });
}
