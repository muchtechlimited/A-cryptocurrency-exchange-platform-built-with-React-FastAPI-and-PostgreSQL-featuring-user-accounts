/**
 * Admin audit log API (`/audit-log/admin`).
 *
 * Read-only by design — entries are written server-side by
 * log_admin_action() whenever an admin action changes state (KYC
 * approvals, rate changes, wallet credits/debits, withdrawal
 * completions, order reviews, deposit reviews, user status changes,
 * support replies, company wallet/bank config changes). There is no
 * create/edit/delete here on purpose.
 */

import { apiRequest } from './api';

export interface AuditLogEntryApi {
  id: string;
  actor_id: string;
  action: string;
  target_type: string;
  target_id: string | null;
  target_user_id: string | null;
  summary: string;
  details: string | null;
  created_at: string;
  actor_email: string | null;
  actor_full_name: string | null;
  target_user_email: string | null;
  target_user_full_name: string | null;
}

export interface AuditLogFilters {
  action?: string;
  target_type?: string;
  actor_id?: string;
  target_user_id?: string;
  limit?: number;
  [key: string]: string | number | boolean | undefined;
}

export function listAuditLog(filters: AuditLogFilters = {}) {
  return apiRequest<AuditLogEntryApi[]>('/audit-log/admin', { query: filters });
}

export function listAuditLogActions() {
  return apiRequest<string[]>('/audit-log/admin/actions');
}

/** Turns an action slug like "kyc.approved" into a readable "KYC Approved" for filter dropdowns and badges. */
export function formatActionLabel(action: string): string {
  return action
    .split('.')
    .map((part) => part.replace(/_/g, ' '))
    .join(' \u2014 ')
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

/** Broad category for grouping/coloring — derived from the action slug's prefix. */
export function actionCategory(action: string): string {
  return action.split('.')[0] ?? action;
}
