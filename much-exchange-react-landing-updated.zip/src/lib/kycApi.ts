import { apiRequest, ApiError, BASE_URL, getCustomerToken } from './api';

export interface KYCSubmissionApi {
  id: string;
  user_id: string;
  document_type: string;
  document_number: string;
  status: 'pending' | 'approved' | 'rejected';
  rejection_reason: string | null;
  created_at: string;
  reviewed_at: string | null;
  has_back_document: boolean;
  has_selfie: boolean;
}

/** The user's own submission history, most recent first. */
export function getMyKycSubmissions() {
  return apiRequest<KYCSubmissionApi[]>('/kyc/me', { auth: 'customer' });
}

export interface SubmitKycFields {
  document_type: string;
  document_number: string;
  document_front: File;
  document_back?: File | null;
  selfie?: File | null;
}

/**
 * Submits a new KYC application. The backend takes document_type and
 * document_number as query params (not a JSON body) plus a multipart file
 * upload for the documents themselves, so this bypasses apiRequest (which
 * only knows how to send JSON) and builds the request by hand.
 */
export function submitKyc(fields: SubmitKycFields): Promise<KYCSubmissionApi> {
  const url = new URL('kyc/submit', BASE_URL.endsWith('/') ? BASE_URL : `${BASE_URL}/`);
  url.searchParams.set('document_type', fields.document_type);
  url.searchParams.set('document_number', fields.document_number);

  const formData = new FormData();
  formData.append('document_front', fields.document_front);
  if (fields.document_back) formData.append('document_back', fields.document_back);
  if (fields.selfie) formData.append('selfie', fields.selfie);

  const token = getCustomerToken();

  return fetch(url.toString(), {
    method: 'POST',
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    body: formData,
  }).then(async (res) => {
    const body = await res.json().catch(() => null);
    if (!res.ok) {
      const message =
        body && typeof body === 'object' && 'detail' in body
          ? typeof (body as { detail: unknown }).detail === 'string'
            ? (body as { detail: string }).detail
            : JSON.stringify((body as { detail: unknown }).detail)
          : `Request failed (${res.status})`;
      throw new ApiError(message, res.status);
    }
    return body as KYCSubmissionApi;
  });
}

/**
 * Fetches one of the current user's own uploaded KYC documents as an
 * authenticated blob (the endpoint requires a Bearer token, so a plain
 * <img src> can't be used) and returns an object URL. Remember to
 * URL.revokeObjectURL() it when done with it. Returns null if this
 * submission has no document of that kind.
 */
export async function fetchMyKycDocumentBlobUrl(
  submissionId: string,
  which: 'front' | 'back' | 'selfie',
): Promise<string | null> {
  const url = new URL(`kyc/documents/${submissionId}/${which}`, BASE_URL.endsWith('/') ? BASE_URL : `${BASE_URL}/`);
  const token = getCustomerToken();

  let response: Response;
  try {
    response = await fetch(url.toString(), {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
  } catch {
    throw new ApiError('Could not reach the server. Is the backend running?', 0);
  }

  if (response.status === 404) return null;

  if (!response.ok) {
    let message = `Request failed (${response.status})`;
    try {
      const body = await response.json();
      if (body && typeof body.detail === 'string') message = body.detail;
    } catch {
      /* non-JSON error body — keep the generic message */
    }
    throw new ApiError(message, response.status);
  }

  const blob = await response.blob();
  return URL.createObjectURL(blob);
}
