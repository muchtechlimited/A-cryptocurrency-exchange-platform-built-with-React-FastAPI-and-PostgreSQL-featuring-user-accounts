import { apiRequest } from './api';

// --- Crypto withdrawals ---

export interface CryptoWithdrawalPreviewApi {
  currency: string;
  wallet_balance: string;
  amount: string;
  destination_address: string;
  network_fee_amount: string;
  service_fee_amount: string;
  total_fees: string;
  net_amount: string;
}

export interface CryptoWithdrawalApi {
  id: string;
  user_id: string;
  currency: string;
  amount: string;
  network_fee_amount: string;
  service_fee_amount: string;
  net_amount: string;
  destination_address: string;
  status: 'pending' | 'approved' | 'rejected' | 'completed';
  rejection_reason: string | null;
  rejection_action: string | null;
  admin_tx_hash: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  completed_at: string | null;
  created_at: string;
}

export function previewCryptoWithdrawal(payload: { currency: 'BTC' | 'USDT'; amount: string; destination_address: string }) {
  return apiRequest<CryptoWithdrawalPreviewApi>('/withdrawals/crypto/preview', {
    method: 'POST',
    body: payload,
    auth: 'customer',
  });
}

export function submitCryptoWithdrawal(payload: { currency: 'BTC' | 'USDT'; amount: string; destination_address: string }) {
  return apiRequest<CryptoWithdrawalApi>('/withdrawals/crypto', {
    method: 'POST',
    body: payload,
    auth: 'customer',
  });
}

export function getMyCryptoWithdrawals() {
  return apiRequest<CryptoWithdrawalApi[]>('/withdrawals/crypto/me', { auth: 'customer' });
}

// --- NGN withdrawals (always pay out to the bank account on file) ---

export interface NGNWithdrawalPreviewApi {
  wallet_balance: string;
  amount: string;
  service_fee_amount: string;
  net_amount: string;
  destination_bank_name: string;
  destination_account_number: string;
  destination_account_name: string;
}

export interface NGNWithdrawalApi {
  id: string;
  user_id: string;
  amount: string;
  service_fee_amount: string;
  net_amount: string;
  destination_bank_name: string;
  destination_account_number: string;
  destination_account_name: string;
  status: 'pending' | 'approved' | 'rejected' | 'completed';
  rejection_reason: string | null;
  rejection_action: string | null;
  admin_reference: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  completed_at: string | null;
  created_at: string;
}

export function previewNgnWithdrawal(amount: string) {
  return apiRequest<NGNWithdrawalPreviewApi>('/withdrawals/ngn/preview', {
    method: 'POST',
    body: { amount },
    auth: 'customer',
  });
}

export function submitNgnWithdrawal(amount: string) {
  return apiRequest<NGNWithdrawalApi>('/withdrawals/ngn', {
    method: 'POST',
    body: { amount },
    auth: 'customer',
  });
}

export function getMyNgnWithdrawals() {
  return apiRequest<NGNWithdrawalApi[]>('/withdrawals/ngn/me', { auth: 'customer' });
}

// --- Shared formatting/status helpers for withdrawal history lists ---
// Crypto withdrawals have 4 real states (pending/approved/rejected/completed —
// "approved" means admin signed off but hasn't sent funds yet). NGN
// withdrawals only ever reach pending/rejected/completed in practice since
// approval finalizes them immediately, but the type allows all four so one
// helper can serve both lists.

export function withdrawalStatusBadgeClasses(status: string) {
  if (status === 'completed') return 'bg-up-500/10 text-up-500';
  if (status === 'approved') return 'bg-brand-500/10 text-brand-600 dark:text-brand-400';
  if (status === 'pending') return 'bg-pending-500/10 text-pending-500';
  return 'bg-down-500/10 text-down-500';
}

export function withdrawalStatusLabel(status: string) {
  if (status === 'approved') return 'Approved — processing';
  return status.charAt(0).toUpperCase() + status.slice(1);
}
