import { apiRequest, ApiError, BASE_URL, getAdminToken } from './api';

// --- Dashboard / Overview ---

export interface DashboardStatsApi {
  total_users: number;
  verified_users: number;
  pending_kyc: number;
  pending_orders: number;
  pending_crypto_deposits: number;
  pending_crypto_withdrawals: number;
  total_transactions: number;
}

export interface DailyActivityPointApi {
  date: string;
  new_users: number;
  transactions: number;
}

export interface DashboardAnalyticsApi {
  stats: DashboardStatsApi;
  daily_activity: DailyActivityPointApi[];
}

export function getDashboardAnalytics(days = 7) {
  return apiRequest<DashboardAnalyticsApi>('/admin/dashboard', { query: { days } });
}

// --- Users ---

export interface AdminUserListItemApi {
  id: string;
  email: string;
  full_name: string;
  is_active: boolean;
  is_verified: boolean;
  is_admin: boolean;
  kyc_status: string;
  created_at: string;
}

export interface AdminUserDetailApi extends AdminUserListItemApi {
  phone_number: string | null;
  country: string | null;
  wallets: { currency: string; available_balance: string; frozen_balance: string; total_balance: string }[];
  total_orders: number;
  total_deposits: number;
  total_withdrawals: number;
}

export function listUsers(search?: string) {
  return apiRequest<AdminUserListItemApi[]>('/admin/users', { query: search ? { search } : undefined });
}

export function getUserDetail(userId: string) {
  return apiRequest<AdminUserDetailApi>(`/admin/users/${userId}`);
}

export function setUserActiveStatus(userId: string, isActive: boolean) {
  return apiRequest<AdminUserListItemApi>(`/admin/users/${userId}/status`, {
    method: 'PATCH',
    body: { is_active: isActive },
  });
}

// --- KYC ---

export interface KYCSubmissionApi {
  id: string;
  user_id: string;
  document_type: string;
  document_number: string;
  status: 'pending' | 'approved' | 'rejected';
  rejection_reason: string | null;
  created_at: string;
  reviewed_at: string | null;
  has_back_document: boolean;
  has_selfie: boolean;
  user_email?: string | null;
  user_full_name?: string | null;
}

export function listPendingKyc(statusFilter?: 'pending' | 'approved' | 'rejected') {
  return apiRequest<KYCSubmissionApi[]>('/kyc/admin/pending', {
    query: statusFilter ? { status_filter: statusFilter } : undefined,
  });
}

export function reviewKyc(submissionId: string, payload: { approve: boolean; rejection_reason?: string }) {
  return apiRequest<KYCSubmissionApi>(`/kyc/admin/${submissionId}/review`, { method: 'POST', body: payload });
}

/**
 * The KYC document endpoint requires a Bearer token, so it can't be used
 * directly as an <img src>. This fetches the image as a blob (attaching the
 * admin token like apiRequest does) and hands back an object URL the caller
 * can put in an <img> — remember to URL.revokeObjectURL() it when done.
 * Returns null if this submission has no document of that kind (404), and
 * throws ApiError for anything else (401/403/network).
 */
export async function fetchKycDocumentBlobUrl(
  submissionId: string,
  which: 'front' | 'back' | 'selfie',
): Promise<string | null> {
  const url = new URL(`kyc/documents/${submissionId}/${which}`, BASE_URL.endsWith('/') ? BASE_URL : `${BASE_URL}/`);
  const token = getAdminToken();

  let response: Response;
  try {
    response = await fetch(url.toString(), {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
  } catch {
    throw new ApiError('Could not reach the server. Is the backend running?', 0);
  }

  if (response.status === 404) return null;

  if (!response.ok) {
    let message = `Request failed (${response.status})`;
    try {
      const body = await response.json();
      if (body && typeof body.detail === 'string') message = body.detail;
    } catch {
      /* non-JSON error body — keep the generic message */
    }
    throw new ApiError(message, response.status);
  }

  const blob = await response.blob();
  return URL.createObjectURL(blob);
}

// --- Transactions (unified queue: buy/sell orders, crypto deposits/withdrawals, NGN bank transfers) ---

export interface OrderApi {
  id: string;
  user_id: string;
  side: 'buy' | 'sell';
  currency: string;
  crypto_amount: string;
  ngn_amount: string;
  status: string;
  created_at: string;
}

export interface CryptoDepositApi {
  id: string;
  user_id: string;
  currency: string;
  amount: string;
  tx_hash: string;
  status: string;
  created_at: string;
}

export interface CryptoWithdrawalApi {
  id: string;
  user_id: string;
  currency: string;
  amount: string;
  net_amount: string;
  destination_address: string;
  status: string;
  created_at: string;
}

export interface NGNBankTransferApi {
  id: string;
  user_id: string;
  amount: string;
  reference_number: string;
  status: string;
  created_at: string;
}

export interface LedgerTransactionApi {
  id: string;
  user_id: string;
  type: string;
  status: string;
  currency: string;
  amount: string;
  fee_amount: string;
  description: string | null;
  created_at: string;
}

export function listPendingOrders() {
  return apiRequest<OrderApi[]>('/trading/admin/pending');
}

export function reviewOrder(orderId: string, payload: { approve: boolean; rejection_reason?: string; rejection_action?: 'unfreeze' | 'keep_frozen' }) {
  return apiRequest<OrderApi>(`/trading/admin/${orderId}/review`, { method: 'POST', body: payload });
}

export function listPendingDeposits() {
  return apiRequest<CryptoDepositApi[]>('/deposits/crypto/admin/pending');
}

export function reviewDeposit(depositId: string, payload: { approve: boolean; rejection_reason?: string }) {
  return apiRequest<CryptoDepositApi>(`/deposits/crypto/admin/${depositId}/review`, { method: 'POST', body: payload });
}

export function listPendingWithdrawals() {
  return apiRequest<CryptoWithdrawalApi[]>('/withdrawals/crypto/admin/pending');
}

export function reviewWithdrawal(withdrawalId: string, payload: { approve: boolean; rejection_reason?: string; rejection_action?: 'unfreeze' | 'keep_frozen' }) {
  return apiRequest<CryptoWithdrawalApi>(`/withdrawals/crypto/admin/${withdrawalId}/review`, { method: 'POST', body: payload });
}

/**
 * Approved-but-not-yet-completed crypto withdrawals. Approving a withdrawal
 * does NOT send the crypto or debit the wallet — only `completeWithdrawal`
 * (below) does that, once the admin has actually sent the funds externally
 * and has a TxID. Without this queue there was previously no way to ever
 * finish an approved withdrawal — the frozen balance would stay frozen
 * forever. See PROJECT_STATUS.md session 6/7 notes.
 */
export function listApprovedWithdrawals() {
  return apiRequest<CryptoWithdrawalApi[]>('/withdrawals/crypto/admin/approved');
}

export function completeWithdrawal(withdrawalId: string, payload: { admin_tx_hash: string }) {
  return apiRequest<CryptoWithdrawalApi>(`/withdrawals/crypto/admin/${withdrawalId}/complete`, { method: 'POST', body: payload });
}

export function listPendingBankTransfers() {
  return apiRequest<NGNBankTransferApi[]>('/deposits/ngn/bank-transfer/admin/pending');
}

export function reviewBankTransfer(transferId: string, payload: { approve: boolean; rejection_reason?: string }) {
  return apiRequest<NGNBankTransferApi>(`/deposits/ngn/bank-transfer/admin/${transferId}/review`, { method: 'POST', body: payload });
}

export interface NGNWithdrawalApi {
  id: string;
  user_id: string;
  amount: string;
  net_amount: string;
  destination_bank_name: string;
  destination_account_number: string;
  destination_account_name: string;
  status: string;
  created_at: string;
}

export function listPendingNgnWithdrawals() {
  return apiRequest<NGNWithdrawalApi[]>('/withdrawals/ngn/admin/pending');
}

export function reviewNgnWithdrawal(withdrawalId: string, payload: { approve: boolean; rejection_reason?: string; rejection_action?: 'unfreeze' | 'keep_frozen'; admin_reference?: string }) {
  return apiRequest<NGNWithdrawalApi>(`/withdrawals/ngn/admin/${withdrawalId}/review`, { method: 'POST', body: payload });
}

export function listAllLedgerTransactions() {
  return apiRequest<LedgerTransactionApi[]>('/wallets/admin/transactions');
}

// --- Rates ---

export interface ExchangeRateApi {
  currency: string;
  buy_rate_ngn: string;
  sell_rate_ngn: string;
  buy_fee_percentage: string;
  sell_fee_percentage: string;
  withdrawal_network_fee: string;
  withdrawal_service_fee: string;
  updated_at: string;
}

export function listExchangeRates() {
  return apiRequest<ExchangeRateApi[]>('/rates');
}

export function setExchangeRate(currency: string, payload: {
  buy_rate_ngn: number;
  sell_rate_ngn: number;
  buy_fee_percentage?: number;
  sell_fee_percentage?: number;
  withdrawal_network_fee?: number;
  withdrawal_service_fee?: number;
}) {
  return apiRequest<ExchangeRateApi>(`/rates/admin/${currency}`, { method: 'PUT', body: payload });
}
