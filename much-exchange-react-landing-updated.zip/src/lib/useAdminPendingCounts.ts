import { useCallback, useEffect, useState } from 'react';
import { listPendingKyc } from './adminApi';
import { getGiftCardStats } from './giftCardsApi';
import { listAllTickets } from './supportApi';

export function useAdminPendingCounts() {
  const [counts, setCounts] = useState({ kyc: 0, giftCards: 0, tickets: 0 });

  const refresh = useCallback(async () => {
    try {
      const [kyc, giftCardStats, tickets] = await Promise.all([
        listPendingKyc('pending'),
        getGiftCardStats(),
        listAllTickets(),
      ]);
      setCounts({
        kyc: kyc.length,
        giftCards: giftCardStats.pending_count,
        tickets: tickets.filter((t) => t.status === 'open').length,
      });
    } catch {
      // Nav badges are a nice-to-have — a failed fetch just leaves the counts as they were rather than breaking navigation.
    }
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [kyc, giftCardStats, tickets] = await Promise.all([
          listPendingKyc('pending'),
          getGiftCardStats(),
          listAllTickets(),
        ]);
        if (!cancelled) {
          setCounts({
            kyc: kyc.length,
            giftCards: giftCardStats.pending_count,
            tickets: tickets.filter((t) => t.status === 'open').length,
          });
        }
      } catch {
        // Nav badges are a nice-to-have — a failed fetch just leaves them at 0 rather than breaking navigation.
      }
    })();
    return () => { cancelled = true; };
  }, []);

  return { ...counts, refresh };
}
