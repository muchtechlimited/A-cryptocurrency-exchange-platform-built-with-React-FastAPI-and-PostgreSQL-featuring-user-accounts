const wallets = [
  { symbol: 'BTC', amount: '0.04521 BTC', fiat: '₦1,485,010.00', color: '#F59E0B', letter: 'B' },
  { symbol: 'USDT', amount: '1,250.50 USDT', fiat: '₦1,301,000.00', color: '#14B8A6', letter: 'T' },
  { symbol: 'NGN', amount: '', fiat: '₦610,000.00', color: '#22C55E', letter: 'N' },
];

export default function PhoneMockup() {
  return (
    <div className="relative mx-auto w-full max-w-[300px] py-6">
      {/* ambient glow behind everything */}
      <div
        className="pointer-events-none absolute -inset-10 -z-10"
        style={{ background: 'radial-gradient(circle at 65% 45%, rgba(245,181,22,.25), transparent 60%)' }}
      />

      {/* floating bitcoin coin */}
      <div
        className="absolute -right-8 top-[38%] z-20 flex h-[72px] w-[72px] -translate-y-1/2 items-center justify-center rounded-full sm:-right-10 sm:h-20 sm:w-20"
        style={{
          background: 'radial-gradient(circle at 35% 28%, #FBD46B, #DE9E0A 65%, #B37E08 100%)',
          boxShadow: '0 0 50px 6px rgba(245,181,22,.55), inset 0 2px 4px rgba(255,255,255,.4), inset 0 -3px 6px rgba(0,0,0,.35)',
          animation: 'float 5s ease-in-out infinite',
        }}
      >
        <span className="font-display text-[30px] font-bold text-white/95" style={{ textShadow: '0 1px 2px rgba(0,0,0,.35)' }}>
          ₿
        </span>
      </div>

      {/* phone frame */}
      <div className="relative rounded-[2.6rem] border-[7px] border-zinc-900 bg-[#0B0C0E] shadow-2xl">
        {/* notch */}
        <div className="absolute left-1/2 top-0 z-10 h-[22px] w-[86px] -translate-x-1/2 rounded-b-2xl bg-zinc-900" />

        <div className="px-4 pb-5 pt-3.5">
          {/* status bar */}
          <div className="mb-4 flex items-center justify-between px-1 text-[10px] font-semibold text-white">
            <span>9:41</span>
            <div className="flex items-center gap-1 opacity-90">
              <svg width="13" height="9" viewBox="0 0 16 11" fill="none"><path d="M1 9L1 7M5 9V5M9 9V3M13 9V1" stroke="white" strokeWidth="1.6" strokeLinecap="round"/></svg>
              <svg width="14" height="10" viewBox="0 0 16 12" fill="none"><path d="M2 5a8 8 0 0112 0M4.5 7.5a4.5 4.5 0 017 0M7 10a1.4 1.4 0 012 0" stroke="white" strokeWidth="1.4" strokeLinecap="round"/></svg>
              <svg width="20" height="10" viewBox="0 0 24 12" fill="none"><rect x="1" y="1.5" width="19" height="9" rx="2" stroke="white" strokeWidth="1.2"/><rect x="2.5" y="3" width="14" height="6" rx="1" fill="white"/><rect x="21" y="4" width="2" height="4" rx="1" fill="white"/></svg>
            </div>
          </div>

          {/* icon row */}
          <div className="mb-4 flex items-center justify-between px-1">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8A8D93" strokeWidth="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3" strokeLinecap="round"/></svg>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8A8D93" strokeWidth="2"><path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </div>

          <p className="px-1 text-[11px] font-medium text-zinc-400">Portfolio Balance</p>
          <p className="mb-4 px-1 pt-0.5 font-display text-[27px] font-bold tracking-tight text-white">₦2,450,000.00</p>

          <div className="mb-5 flex gap-2 px-1">
            <button className="flex-1 rounded-full bg-gradient-to-b from-brand-400 to-brand-500 py-2 text-[12px] font-bold text-zinc-900">
              Deposit
            </button>
            <button className="flex-1 rounded-full border border-white/20 py-2 text-[12px] font-semibold text-white">
              Withdraw
            </button>
          </div>

          <div className="space-y-3 px-1">
            {wallets.map((w) => (
              <div key={w.symbol} className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <span
                    className="flex h-8 w-8 items-center justify-center rounded-full text-[11px] font-bold text-white"
                    style={{ backgroundColor: w.color }}
                  >
                    {w.letter}
                  </span>
                  <div className="leading-tight">
                    <p className="text-[12.5px] font-semibold text-white">{w.symbol}</p>
                    <p className="text-[9.5px] text-zinc-500">Balance</p>
                  </div>
                </div>
                <div className="text-right leading-tight">
                  {w.amount && <p className="text-[11.5px] font-semibold text-zinc-100">{w.amount}</p>}
                  <p className="text-[10px] text-zinc-500">{w.fiat}</p>
                </div>
              </div>
            ))}
          </div>

          <svg className="mt-4" width="100%" height="34" viewBox="0 0 244 34" fill="none" preserveAspectRatio="none">
            <polyline
              points="0,26 20,22 38,27 56,15 74,19 92,9 110,14 128,6 146,12 164,4 182,10 200,8 218,13 244,3"
              stroke="#F5B516"
              strokeWidth="1.6"
              strokeLinecap="round"
              strokeLinejoin="round"
              fill="none"
              opacity="0.85"
            />
          </svg>
        </div>
      </div>

      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(-50%); }
          50% { transform: translateY(calc(-50% - 14px)); }
        }
      `}</style>
    </div>
  );
}
