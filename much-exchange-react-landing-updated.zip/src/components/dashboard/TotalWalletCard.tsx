import { Link } from 'react-router-dom';
import { Wallet } from 'lucide-react';
import { walletBalances } from '../../data/dashboardMock';

export default function TotalWalletCard() {
  const total = walletBalances[0];

  return (
    <div className="flex items-center justify-between rounded-2xl border border-zinc-200 bg-white p-4 dark:border-white/[0.08] dark:bg-[#101113] sm:p-5">
      <div>
        <p className="text-[12.5px] font-medium text-zinc-500 dark:text-zinc-400">Total Wallet Value</p>
        <p className="mt-1.5 font-display text-[22px] font-bold text-zinc-900 dark:text-white sm:text-[26px]">
          {total.amount}
        </p>
        <p className="mt-1 text-[11.5px] text-zinc-400 dark:text-zinc-500">≈ $1,560.35</p>
      </div>
      <Link
        to="/wallets"
        className="flex flex-col items-center gap-1.5 rounded-xl bg-gradient-to-b from-brand-400 to-brand-500 px-4 py-3 text-zinc-900 shadow-[0_1px_0_0_rgba(255,255,255,.35)_inset]"
      >
        <Wallet size={18} />
        <span className="text-[11px] font-semibold">Wallets</span>
      </Link>
    </div>
  );
}
