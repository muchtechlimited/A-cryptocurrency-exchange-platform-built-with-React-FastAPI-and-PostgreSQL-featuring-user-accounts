import { giftCardBrands } from '../../data/giftCardsMock';
import type { GiftCardBrand } from '../../data/giftCardsMock';

interface Props {
  selectedId: string;
  onSelect: (brand: GiftCardBrand) => void;
}

export default function GiftCardBrandSelector({ selectedId, onSelect }: Props) {
  return (
    <div className="mb-4 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
      {giftCardBrands.map((brand) => {
        const active = brand.id === selectedId;
        return (
          <button
            key={brand.id}
            type="button"
            onClick={() => onSelect(brand)}
            className={`flex flex-col items-center gap-2 rounded-xl border px-3 py-3.5 transition-colors ${
              active
                ? 'border-brand-500 bg-brand-500/10'
                : 'border-zinc-200 hover:bg-zinc-50 dark:border-white/10 dark:hover:bg-white/[0.04]'
            }`}
          >
            <span
              className="flex h-9 w-9 items-center justify-center rounded-full text-[13px] font-bold text-white"
              style={{ backgroundColor: brand.color }}
            >
              {brand.letter}
            </span>
            <span className="text-[12px] font-medium text-zinc-700 dark:text-zinc-200">{brand.name}</span>
          </button>
        );
      })}
    </div>
  );
}
