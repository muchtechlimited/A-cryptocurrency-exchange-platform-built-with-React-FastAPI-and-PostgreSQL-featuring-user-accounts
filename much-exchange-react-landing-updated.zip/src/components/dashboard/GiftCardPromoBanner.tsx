import { Link } from 'react-router-dom';
import { Gift } from 'lucide-react';
import { giftCardBrands } from '../../data/giftCardsMock';

export default function GiftCardPromoBanner() {
  return (
    <div className="flex items-center justify-between gap-4 rounded-2xl border border-zinc-200 bg-white p-4 dark:border-white/[0.08] dark:bg-[#101113] sm:p-5">
      <div className="min-w-0">
        <p className="text-[14px] font-bold text-zinc-900 dark:text-white">Buy &amp; Sell Gift Cards</p>
        <p className="mt-1 text-[12px] text-zinc-500 dark:text-zinc-400">Get the best rates for 500+ gift cards</p>

        <div className="mt-3 flex items-center gap-2">
          {giftCardBrands.map((brand) => (
            <span
              key={brand.id}
              className="flex h-7 w-7 items-center justify-center rounded-full text-[10px] font-bold text-white"
              style={{ backgroundColor: brand.color }}
            >
              {brand.letter}
            </span>
          ))}
        </div>
      </div>

      <Link
        to="/gift-cards"
        className="flex shrink-0 items-center gap-2 rounded-xl bg-gradient-to-b from-brand-400 to-brand-500 px-4 py-2.5 text-[12.5px] font-semibold text-zinc-900 shadow-[0_1px_0_0_rgba(255,255,255,.35)_inset]"
      >
        <Gift size={15} />
        Get Started
      </Link>
    </div>
  );
}
