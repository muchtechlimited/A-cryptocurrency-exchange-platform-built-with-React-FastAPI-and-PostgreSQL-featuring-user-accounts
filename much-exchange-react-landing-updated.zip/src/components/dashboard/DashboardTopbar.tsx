import { useState } from 'react';
import { Bell } from 'lucide-react';
import ThemeToggle from '../ThemeToggle';
import Logo from '../Logo';
import { avatarSrc } from '../../lib/profileApi';

interface DashboardTopbarProps {
  title: string;
  subtitle?: string;
  userName?: string;
  avatarUrl?: string | null;
}

export default function DashboardTopbar({ title, subtitle, userName, avatarUrl }: DashboardTopbarProps) {
  const displayName = userName?.trim() ? userName.trim().split(' ')[0] : 'User';
  const initial = displayName.charAt(0).toUpperCase();
  // Falls back to the initial if the image 404s (e.g. the file was removed
  // server-side) rather than showing a broken-image icon.
  const [imageFailed, setImageFailed] = useState(false);
  const src = imageFailed ? null : avatarSrc(avatarUrl ?? null);

  return (
    <header className="flex items-center justify-between gap-3 border-b border-zinc-200 bg-white/80 px-4 py-3.5 backdrop-blur-lg dark:border-white/[0.08] dark:bg-[#08090B]/80 sm:px-8 sm:py-4">
      <div className="flex min-w-0 items-center gap-2.5">
        <Logo withWordmark={false} size={26} className="shrink-0 md:hidden" />
        <div className="min-w-0">
          <h1 className="truncate font-display text-[16px] font-semibold text-zinc-900 dark:text-white sm:text-[18px] md:text-[20px]">
            {title}
          </h1>
          {subtitle && (
            <p className="mt-0.5 hidden truncate text-[12.5px] text-zinc-500 dark:text-zinc-400 sm:block">
              {subtitle}
            </p>
          )}
        </div>
      </div>

      <div className="flex shrink-0 items-center gap-2.5 sm:gap-3">
        <ThemeToggle className="hidden sm:inline-flex" />

        <button
          type="button"
          aria-label="Notifications"
          className="relative inline-flex h-9 w-9 items-center justify-center rounded-lg border border-zinc-200 bg-white text-zinc-600 transition-colors hover:text-zinc-900 dark:border-white/10 dark:bg-white/5 dark:text-zinc-300 dark:hover:text-white"
        >
          <Bell size={16} />
          <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-down-500" />
        </button>

        <div className="flex items-center gap-2.5 rounded-lg border border-zinc-200 py-1.5 pl-1.5 pr-3 dark:border-white/10">
          {src ? (
            <img src={src} alt="" onError={() => setImageFailed(true)} className="h-7 w-7 rounded-full object-cover" />
          ) : (
            <div className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-b from-brand-400 to-brand-500 text-[12px] font-bold text-zinc-900">
              {initial}
            </div>
          )}
          <span className="hidden text-[13px] font-medium text-zinc-700 dark:text-zinc-200 sm:inline">
            {displayName}
          </span>
        </div>
      </div>
    </header>
  );
}
