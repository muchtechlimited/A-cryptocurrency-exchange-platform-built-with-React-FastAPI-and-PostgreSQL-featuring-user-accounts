import { NavLink } from 'react-router-dom';
import Logo from '../Logo';
import { primaryNav, secondaryNav, logoutNav } from './dashboardNav';
import type { NavItem } from './dashboardNav';

function NavRow({ item }: { item: NavItem }) {
  const Icon = item.icon;
  return (
    <NavLink
      to={item.href}
      className={({ isActive }) =>
        `group relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-[13px] font-medium transition-colors ${
          isActive
            ? 'bg-brand-500/10 text-brand-600 dark:bg-brand-400/10 dark:text-brand-400'
            : 'text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900 dark:text-zinc-400 dark:hover:bg-white/[0.06] dark:hover:text-white'
        }`
      }
    >
      {({ isActive }) => (
        <>
          <span
            className={`absolute left-0 h-5 w-[3px] rounded-r-full transition-opacity ${
              isActive ? 'bg-brand-500 opacity-100' : 'opacity-0'
            }`}
          />
          <Icon size={16} strokeWidth={2} />
          <span>{item.label}</span>
        </>
      )}
    </NavLink>
  );
}

export default function DashboardSidebar() {
  return (
    <aside className="hidden h-full w-[248px] shrink-0 flex-col border-r border-zinc-200 bg-white px-3 py-5 dark:border-white/[0.08] dark:bg-[#0B0C0E] md:flex">
      <div className="mb-6 px-2">
        <Logo />
      </div>

      <nav className="relative flex-1 space-y-1 overflow-y-auto">
        {primaryNav.map((item) => (
          <div key={item.href} className="relative">
            <NavRow item={item} />
          </div>
        ))}
      </nav>

      <div className="mt-3 space-y-1 border-t border-zinc-200 pt-3 dark:border-white/[0.08]">
        {secondaryNav.map((item) => (
          <div key={item.href} className="relative">
            <NavRow item={item} />
          </div>
        ))}
        <div className="relative">
          <NavRow item={logoutNav} />
        </div>
      </div>
    </aside>
  );
}
