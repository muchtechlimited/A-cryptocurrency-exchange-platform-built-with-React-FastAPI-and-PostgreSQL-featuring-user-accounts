import { useState } from 'react';
import { AreaChart, Area, XAxis, ResponsiveContainer, Tooltip } from 'recharts';
import Card from '../ui/Card';
import { chartRanges, portfolioSeries } from '../../data/dashboardMock';
import type { ChartRange } from '../../data/dashboardMock';

export default function PortfolioChart() {
  const [range, setRange] = useState<ChartRange>('1M');
  const data = portfolioSeries[range];

  return (
    <Card className="!p-0">
      <div className="flex items-center justify-between border-b border-zinc-200 px-5 py-4 dark:border-white/[0.08]">
        <h3 className="text-[14px] font-semibold text-zinc-900 dark:text-white">Portfolio Overview</h3>
        <div className="flex items-center gap-1 rounded-lg bg-zinc-100 p-1 dark:bg-white/[0.05]">
          {chartRanges.map((r) => (
            <button
              key={r}
              onClick={() => setRange(r)}
              className={`rounded-md px-2 py-1 text-[11px] font-semibold transition-colors ${
                range === r
                  ? 'bg-gradient-to-b from-brand-400 to-brand-500 text-zinc-900'
                  : 'text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-white'
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      <div className="h-[220px] px-2 py-4 sm:h-[260px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 8, right: 12, left: 4, bottom: 0 }}>
            <defs>
              <linearGradient id="portfolioGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#F5B516" stopOpacity={0.35} />
                <stop offset="100%" stopColor="#F5B516" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis
              dataKey="label"
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 11, fill: '#8A8D93' }}
              interval="preserveStartEnd"
            />
            <Tooltip
              contentStyle={{
                background: '#101113',
                border: '1px solid rgba(255,255,255,0.08)',
                borderRadius: 10,
                fontSize: 12,
              }}
              labelStyle={{ color: '#8A8D93' }}
              itemStyle={{ color: '#F5B516' }}
              formatter={(value: number) => [`₦${(value * 1000).toLocaleString()}`, 'Balance']}
            />
            <Area
              type="monotone"
              dataKey="value"
              stroke="#F5B516"
              strokeWidth={2}
              fill="url(#portfolioGradient)"
              dot={false}
              activeDot={{ r: 4, fill: '#F5B516', stroke: '#08090B', strokeWidth: 2 }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}
