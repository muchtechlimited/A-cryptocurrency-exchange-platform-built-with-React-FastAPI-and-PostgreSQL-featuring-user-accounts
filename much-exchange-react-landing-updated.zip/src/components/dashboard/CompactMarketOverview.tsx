import { Link } from 'react-router-dom';
import { TrendingUp, TrendingDown } from 'lucide-react';
import Card from '../ui/Card';
import { marketRows } from '../../data/dashboardMock';

export default function CompactMarketOverview() {
  return (
    <Card className="!p-0">
      <div className="flex items-center justify-between border-b border-zinc-200 px-5 py-4 dark:border-white/[0.08]">
        <h3 className="text-[14px] font-semibold text-zinc-900 dark:text-white">Market Overview</h3>
        <Link to="/markets" className="text-[12px] font-semibold text-brand-600 dark:text-brand-400">
          See All
        </Link>
      </div>

      <div className="px-2 py-2">
        {marketRows.map((row) => {
          const positive = row.changePct >= 0;
          return (
            <div
              key={row.pair}
              className="flex items-center justify-between rounded-lg px-3 py-2.5 transition-colors hover:bg-zinc-50 dark:hover:bg-white/[0.03]"
            >
              <div className="flex items-center gap-2.5">
                <span
                  className="flex h-8 w-8 items-center justify-center rounded-full text-[11px] font-bold text-white"
                  style={{ backgroundColor: row.color }}
                >
                  {row.letter}
                </span>
                <div>
                  <p className="text-[13px] font-medium text-zinc-800 dark:text-zinc-100">{row.symbol}</p>
                  <p className="font-mono text-[11.5px] text-zinc-500 dark:text-zinc-400">{row.price}</p>
                </div>
              </div>
              <span
                className={`flex items-center gap-1 text-[12.5px] font-semibold ${
                  positive ? 'text-up-500' : 'text-down-500'
                }`}
              >
                {positive ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                {positive ? '+' : ''}
                {row.changePct}%
              </span>
            </div>
          );
        })}
      </div>
    </Card>
  );
}
