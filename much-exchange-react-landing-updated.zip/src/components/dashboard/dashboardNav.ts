import type { LucideIcon } from 'lucide-react';
import {
  LayoutDashboard,
  Wallet,
  ArrowDownCircle,
  ArrowUpCircle,
  Download,
  Upload,
  ShieldCheck,
  Repeat,
  Bell,
  Gift,
  CreditCard,
  User,
  Settings,
  HelpCircle,
  LogOut,
} from 'lucide-react';

export interface NavItem {
  label: string;
  href: string;
  icon: LucideIcon;
}

export const primaryNav: NavItem[] = [
  { label: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { label: 'Wallets', href: '/wallets', icon: Wallet },
  { label: 'Buy Crypto', href: '/buy', icon: ArrowDownCircle },
  { label: 'Sell Crypto', href: '/sell', icon: ArrowUpCircle },
  { label: 'Gift Cards', href: '/gift-cards', icon: CreditCard },
  { label: 'Deposit', href: '/deposit', icon: Download },
  { label: 'Withdraw', href: '/withdraw', icon: Upload },
  { label: 'KYC Verification', href: '/kyc', icon: ShieldCheck },
  { label: 'Transactions', href: '/transactions', icon: Repeat },
  { label: 'Notifications', href: '/notifications', icon: Bell },
  { label: 'Referral', href: '/referral', icon: Gift },
  { label: 'Support', href: '/support', icon: HelpCircle },
];

export const secondaryNav: NavItem[] = [
  { label: 'Profile', href: '/profile', icon: User },
  { label: 'Settings', href: '/settings', icon: Settings },
];

export const logoutNav: NavItem = { label: 'Logout', href: '/logout', icon: LogOut };

/* ---- Mobile-only groupings ---- */

/** Tabs that sit directly in the bottom bar (excludes the raised center Trade action). */
export const mobileTabNav: NavItem[] = [
  { label: 'Home', href: '/dashboard', icon: LayoutDashboard },
  { label: 'Wallets', href: '/wallets', icon: Wallet },
  { label: 'Cards', href: '/gift-cards', icon: CreditCard },
];

/** Actions surfaced in the raised center "Trade" bottom-sheet. */
export const tradeActions: NavItem[] = [
  { label: 'Buy Crypto', href: '/buy', icon: ArrowDownCircle },
  { label: 'Sell Crypto', href: '/sell', icon: ArrowUpCircle },
  { label: 'Deposit', href: '/deposit', icon: Download },
  { label: 'Withdraw', href: '/withdraw', icon: Upload },
];

/** Everything else, surfaced in the "Menu" slide-in drawer. */
export const moreNav: NavItem[] = [
  { label: 'KYC Verification', href: '/kyc', icon: ShieldCheck },
  { label: 'Transactions', href: '/transactions', icon: Repeat },
  { label: 'Notifications', href: '/notifications', icon: Bell },
  { label: 'Referral', href: '/referral', icon: Gift },
  { label: 'Support', href: '/support', icon: HelpCircle },
];
