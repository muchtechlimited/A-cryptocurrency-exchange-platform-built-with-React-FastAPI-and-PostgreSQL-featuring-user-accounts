import { Repeat } from 'lucide-react';
import { useDashboardChrome } from './DashboardChromeContext';

export default function TradeConfidenceBanner() {
  const { openTrade } = useDashboardChrome();

  return (
    <button
      type="button"
      onClick={openTrade}
      className="flex w-full items-center gap-3 rounded-2xl bg-gradient-to-br from-brand-400 to-brand-600 px-4 py-4 text-left shadow-[0_1px_0_0_rgba(255,255,255,.35)_inset,0_10px_24px_-10px_rgba(245,181,22,.55)]"
    >
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-black/10 text-zinc-900">
        <Repeat size={18} />
      </span>
      <div>
        <p className="text-[13.5px] font-bold text-zinc-900">Trade Crypto with Confidence</p>
        <p className="text-[11.5px] font-medium text-zinc-900/70">Fast, Secure, Reliable.</p>
      </div>
    </button>
  );
}
