import Card from '../ui/Card';
import { marketRows } from '../../data/dashboardMock';

export default function MarketOverview() {
  return (
    <Card className="!p-0">
      <div className="flex items-center justify-between border-b border-zinc-200 px-5 py-4 dark:border-white/[0.08]">
        <h3 className="text-[14px] font-semibold text-zinc-900 dark:text-white">Market Overview</h3>
      </div>

      <div className="px-2 py-2">
        <div className="grid grid-cols-3 px-3 py-2 text-[11px] font-medium uppercase tracking-wide text-zinc-400 dark:text-zinc-500">
          <span>Coin</span>
          <span className="text-right">Price</span>
          <span className="text-right">24h Change</span>
        </div>

        {marketRows.map((row) => {
          const positive = row.changePct >= 0;
          return (
            <div
              key={row.pair}
              className="grid grid-cols-3 items-center rounded-lg px-3 py-2.5 text-[13px] transition-colors hover:bg-zinc-50 dark:hover:bg-white/[0.03]"
            >
              <div className="flex items-center gap-2.5">
                <span
                  className="flex h-7 w-7 items-center justify-center rounded-full text-[11px] font-bold text-white"
                  style={{ backgroundColor: row.color }}
                >
                  {row.letter}
                </span>
                <span className="font-medium text-zinc-800 dark:text-zinc-100">{row.pair}</span>
              </div>
              <span className="text-right font-mono text-[12.5px] text-zinc-700 dark:text-zinc-300">
                {row.price}
              </span>
              <span
                className={`text-right text-[12.5px] font-semibold ${
                  positive ? 'text-up-500' : 'text-down-500'
                }`}
              >
                {positive ? '+' : ''}
                {row.changePct}%
              </span>
            </div>
          );
        })}
      </div>
    </Card>
  );
}
