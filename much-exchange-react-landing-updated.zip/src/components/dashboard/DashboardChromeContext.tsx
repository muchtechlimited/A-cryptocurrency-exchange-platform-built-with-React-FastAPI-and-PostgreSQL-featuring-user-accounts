import { createContext, useContext } from 'react';

interface DashboardChromeValue {
  openTrade: () => void;
  openMore: () => void;
}

export const DashboardChromeContext = createContext<DashboardChromeValue | undefined>(undefined);

export function useDashboardChrome() {
  const ctx = useContext(DashboardChromeContext);
  if (!ctx) {
    // Safe no-op fallback so components can be used outside the layout (e.g. in isolation/tests)
    return { openTrade: () => {}, openMore: () => {} };
  }
  return ctx;
}
