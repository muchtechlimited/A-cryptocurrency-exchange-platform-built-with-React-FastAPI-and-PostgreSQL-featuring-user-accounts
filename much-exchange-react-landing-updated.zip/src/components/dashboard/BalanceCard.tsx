import Card from '../ui/Card';
import type { WalletBalance } from '../../data/dashboardMock';

export default function BalanceCard({ wallet }: { wallet: WalletBalance }) {
  const positive = wallet.changePct >= 0;
  return (
    <Card className="flex flex-col justify-between">
      <p className="text-[12.5px] font-medium text-zinc-500 dark:text-zinc-400">{wallet.label}</p>
      <p className="mt-2 font-display text-[19px] font-bold text-zinc-900 dark:text-white sm:text-[21px]">
        {wallet.amount}
      </p>
      <div className="mt-2 flex items-center justify-between">
        {wallet.fiat ? (
          <p className="text-[11.5px] text-zinc-400 dark:text-zinc-500">≈ {wallet.fiat}</p>
        ) : (
          <span />
        )}
        <span
          className={`text-[11.5px] font-semibold ${
            positive ? 'text-up-500' : 'text-down-500'
          }`}
        >
          {positive ? '+' : ''}
          {wallet.changePct}%
        </span>
      </div>
    </Card>
  );
}
