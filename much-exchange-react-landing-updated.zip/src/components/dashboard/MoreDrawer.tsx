import { NavLink } from 'react-router-dom';
import { X } from 'lucide-react';
import Logo from '../Logo';
import ThemeToggle from '../ThemeToggle';
import { moreNav, secondaryNav, logoutNav } from './dashboardNav';
import type { NavItem } from './dashboardNav';
import { useAuth } from '../../context/AuthContext';
import { avatarSrc } from '../../lib/profileApi';

interface Props {
  open: boolean;
  onClose: () => void;
}

function DrawerRow({ item, onClose }: { item: NavItem; onClose: () => void }) {
  const Icon = item.icon;
  return (
    <NavLink
      to={item.href}
      onClick={onClose}
      className={({ isActive }) =>
        `flex items-center gap-3 rounded-lg px-3 py-3 text-[13.5px] font-medium transition-colors ${
          isActive
            ? 'bg-brand-500/10 text-brand-600 dark:bg-brand-400/10 dark:text-brand-400'
            : 'text-zinc-600 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-white/[0.06]'
        }`
      }
    >
      <Icon size={17} strokeWidth={2} />
      <span>{item.label}</span>
    </NavLink>
  );
}

export default function MoreDrawer({ open, onClose }: Props) {
  const { user } = useAuth();
  const displayName = user?.full_name?.trim() || 'User';
  const initial = displayName.charAt(0).toUpperCase();
  const avatar = avatarSrc(user?.avatar_url ?? null);
  return (
    <div className={`fixed inset-0 z-50 md:hidden ${open ? '' : 'pointer-events-none'}`} aria-hidden={!open}>
      <div
        onClick={onClose}
        className={`absolute inset-0 bg-black/40 backdrop-blur-[2px] transition-opacity duration-200 ${
          open ? 'opacity-100' : 'opacity-0'
        }`}
      />

      <div
        className={`absolute inset-y-0 right-0 flex w-[82%] max-w-[320px] flex-col bg-white pb-[env(safe-area-inset-bottom)] shadow-2xl transition-transform duration-250 dark:bg-[#0B0C0E] ${
          open ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between border-b border-zinc-200 px-5 py-4 dark:border-white/[0.08]">
          <Logo size={28} />
          <button
            onClick={onClose}
            aria-label="Close menu"
            className="flex h-8 w-8 items-center justify-center rounded-lg text-zinc-500 hover:bg-zinc-100 dark:text-zinc-400 dark:hover:bg-white/[0.06]"
          >
            <X size={18} />
          </button>
        </div>

        <div className="flex items-center gap-3 border-b border-zinc-200 px-5 py-4 dark:border-white/[0.08]">
          {avatar ? (
            <img src={avatar} alt="" className="h-10 w-10 shrink-0 rounded-full object-cover" />
          ) : (
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-b from-brand-400 to-brand-500 text-[14px] font-bold text-zinc-900">
              {initial}
            </div>
          )}
          <div>
            <p className="text-[13.5px] font-semibold text-zinc-900 dark:text-white">{displayName}</p>
            <NavLink
              to="/profile"
              onClick={onClose}
              className="text-[12px] font-medium text-brand-600 dark:text-brand-400"
            >
              View profile
            </NavLink>
          </div>
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
          {moreNav.map((item) => (
            <DrawerRow key={item.href} item={item} onClose={onClose} />
          ))}
          <div className="my-2 border-t border-zinc-200 dark:border-white/[0.08]" />
          {secondaryNav.map((item) => (
            <DrawerRow key={item.href} item={item} onClose={onClose} />
          ))}
        </nav>

        <div className="space-y-3 border-t border-zinc-200 px-3 py-4 dark:border-white/[0.08]">
          <div className="flex items-center justify-between px-3">
            <span className="text-[13px] font-medium text-zinc-600 dark:text-zinc-300">Appearance</span>
            <ThemeToggle />
          </div>
          <DrawerRow item={logoutNav} onClose={onClose} />
        </div>
      </div>
    </div>
  );
}
