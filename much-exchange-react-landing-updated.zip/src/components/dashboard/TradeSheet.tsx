import { Link } from 'react-router-dom';
import { X } from 'lucide-react';
import { tradeActions } from './dashboardNav';

interface Props {
  open: boolean;
  onClose: () => void;
}

export default function TradeSheet({ open, onClose }: Props) {
  return (
    <div
      className={`fixed inset-0 z-50 md:hidden ${open ? '' : 'pointer-events-none'}`}
      aria-hidden={!open}
    >
      {/* backdrop */}
      <div
        onClick={onClose}
        className={`absolute inset-0 bg-black/40 backdrop-blur-[2px] transition-opacity duration-200 ${
          open ? 'opacity-100' : 'opacity-0'
        }`}
      />

      {/* sheet */}
      <div
        className={`absolute inset-x-0 bottom-0 rounded-t-3xl border-t border-zinc-200 bg-white pb-[calc(env(safe-area-inset-bottom)+12px)] pt-3 shadow-2xl transition-transform duration-250 dark:border-white/10 dark:bg-[#101113] ${
          open ? 'translate-y-0' : 'translate-y-full'
        }`}
      >
        <div className="mx-auto mb-3 h-1 w-9 rounded-full bg-zinc-200 dark:bg-white/15" />

        <div className="flex items-center justify-between px-5 pb-3">
          <h3 className="font-display text-[15px] font-semibold text-zinc-900 dark:text-white">Trade</h3>
          <button
            onClick={onClose}
            aria-label="Close"
            className="flex h-8 w-8 items-center justify-center rounded-lg text-zinc-500 hover:bg-zinc-100 dark:text-zinc-400 dark:hover:bg-white/[0.06]"
          >
            <X size={17} />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3 px-5 pb-2">
          {tradeActions.map((action) => {
            const Icon = action.icon;
            return (
              <Link
                key={action.href}
                to={action.href}
                onClick={onClose}
                className="flex flex-col items-center gap-2.5 rounded-2xl border border-zinc-200 px-3 py-5 text-center transition-colors active:bg-zinc-50 dark:border-white/[0.08] dark:active:bg-white/[0.04]"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-brand-500/10 text-brand-600 dark:text-brand-400">
                  <Icon size={20} />
                </span>
                <span className="text-[13px] font-semibold text-zinc-800 dark:text-zinc-100">
                  {action.label}
                </span>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
