import { NavLink } from 'react-router-dom';
import { Home, BarChart2, Repeat, Receipt, User } from 'lucide-react';

interface TabItem {
  label: string;
  href: string;
  icon: typeof Home;
}

const leftTabs: TabItem[] = [
  { label: 'Home', href: '/dashboard', icon: Home },
  { label: 'Markets', href: '/markets', icon: BarChart2 },
];

const rightTabs: TabItem[] = [
  { label: 'Orders', href: '/transactions', icon: Receipt },
  { label: 'Profile', href: '/profile', icon: User },
];

interface Props {
  onTradeClick: () => void;
}

function TabButton({ item }: { item: TabItem }) {
  const Icon = item.icon;
  return (
    <NavLink
      to={item.href}
      className={({ isActive }) =>
        `flex flex-1 flex-col items-center justify-center gap-1 py-1.5 text-[10.5px] font-medium transition-colors ${
          isActive ? 'text-brand-600 dark:text-brand-400' : 'text-zinc-500 dark:text-zinc-400'
        }`
      }
    >
      {({ isActive }) => (
        <>
          <Icon size={20} strokeWidth={isActive ? 2.4 : 2} />
          <span>{item.label}</span>
        </>
      )}
    </NavLink>
  );
}

export default function MobileBottomNav({ onTradeClick }: Props) {
  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-40 border-t border-zinc-200 bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-lg dark:border-white/[0.08] dark:bg-[#0B0C0E]/95 md:hidden"
      aria-label="Primary mobile navigation"
    >
      <div className="relative mx-auto flex h-[64px] max-w-lg items-stretch px-1">
        {leftTabs.map((item) => (
          <TabButton key={item.href} item={item} />
        ))}

        {/* Raised center Trade action */}
        <div className="flex flex-1 items-center justify-center">
          <button
            type="button"
            onClick={onTradeClick}
            aria-label="Trade"
            className="relative -top-5 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-b from-brand-400 to-brand-500 text-zinc-900 shadow-[0_1px_0_0_rgba(255,255,255,.35)_inset,0_10px_24px_-8px_rgba(245,181,22,.65)] transition-transform active:scale-95"
          >
            <Repeat size={22} strokeWidth={2.4} />
          </button>
        </div>

        {rightTabs.map((item) => (
          <TabButton key={item.href} item={item} />
        ))}
      </div>
    </nav>
  );
}
