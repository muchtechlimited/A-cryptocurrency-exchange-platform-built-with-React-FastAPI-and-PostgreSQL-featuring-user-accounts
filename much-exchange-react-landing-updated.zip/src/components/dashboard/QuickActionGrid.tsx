import { Link } from 'react-router-dom';
import {
  ArrowDownCircle,
  ArrowUpCircle,
  Download,
  Upload,
  Gift,
  CreditCard,
  ClipboardList,
  MoreHorizontal,
  type LucideIcon,
} from 'lucide-react';
import { useDashboardChrome } from './DashboardChromeContext';

export interface QuickAction {
  label: string;
  href?: string;
  icon: LucideIcon;
  iconClass: string;
  action?: 'more';
}

export const buyCrypto: QuickAction = {
  label: 'Buy Crypto',
  href: '/buy',
  icon: ArrowDownCircle,
  iconClass: 'bg-up-500/10 text-up-500',
};
export const sellCrypto: QuickAction = {
  label: 'Sell Crypto',
  href: '/sell',
  icon: ArrowUpCircle,
  iconClass: 'bg-blue-500/10 text-blue-500',
};
export const deposit: QuickAction = {
  label: 'Deposit',
  href: '/deposit',
  icon: Download,
  iconClass: 'bg-cyan-500/10 text-cyan-500',
};
export const withdraw: QuickAction = {
  label: 'Withdraw',
  href: '/withdraw',
  icon: Upload,
  iconClass: 'bg-violet-500/10 text-violet-500',
};
export const buyGiftCards: QuickAction = {
  label: 'Buy Gift Cards',
  href: '/gift-cards',
  icon: Gift,
  iconClass: 'bg-pink-500/10 text-pink-500',
};
export const sellGiftCards: QuickAction = {
  label: 'Sell Gift Cards',
  href: '/gift-cards',
  icon: CreditCard,
  iconClass: 'bg-brand-500/10 text-brand-600 dark:text-brand-400',
};
export const giftCardOrders: QuickAction = {
  label: 'Gift Card Orders',
  href: '/transactions',
  icon: ClipboardList,
  iconClass: 'bg-sky-500/10 text-sky-500',
};
export const moreAction: QuickAction = {
  label: 'More',
  icon: MoreHorizontal,
  iconClass: 'bg-zinc-200/60 text-zinc-500 dark:bg-white/10 dark:text-zinc-300',
  action: 'more',
};

export const mobileQuickActions: QuickAction[] = [
  buyCrypto,
  sellCrypto,
  deposit,
  withdraw,
  buyGiftCards,
  sellGiftCards,
  giftCardOrders,
  moreAction,
];

export const tabletQuickActions: QuickAction[] = [
  buyCrypto,
  sellCrypto,
  buyGiftCards,
  sellGiftCards,
  deposit,
  withdraw,
];

interface QuickActionGridProps {
  actions: QuickAction[];
  columns?: string;
}

export default function QuickActionGrid({ actions, columns = 'grid-cols-4' }: QuickActionGridProps) {
  const { openMore } = useDashboardChrome();

  return (
    <div className={`grid gap-3 ${columns}`}>
      {actions.map((item) => {
        const Icon = item.icon;
        const content = (
          <>
            <span className={`flex h-10 w-10 items-center justify-center rounded-xl ${item.iconClass}`}>
              <Icon size={18} />
            </span>
            <span className="text-center text-[11.5px] font-medium leading-tight text-zinc-700 dark:text-zinc-200">
              {item.label}
            </span>
          </>
        );

        if (item.action === 'more') {
          return (
            <button
              key={item.label}
              type="button"
              onClick={openMore}
              className="flex flex-col items-center justify-center gap-2 rounded-xl border border-zinc-200 bg-white px-2 py-3.5 transition-colors active:bg-zinc-50 dark:border-white/[0.08] dark:bg-[#101113] dark:active:bg-white/[0.04]"
            >
              {content}
            </button>
          );
        }

        return (
          <Link
            key={item.label}
            to={item.href!}
            className="flex flex-col items-center justify-center gap-2 rounded-xl border border-zinc-200 bg-white px-2 py-3.5 transition-colors active:bg-zinc-50 dark:border-white/[0.08] dark:bg-[#101113] dark:active:bg-white/[0.04]"
          >
            {content}
          </Link>
        );
      })}
    </div>
  );
}
