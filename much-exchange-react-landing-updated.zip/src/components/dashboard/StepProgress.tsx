interface Props {
  steps: string[];
  activeIndex: number;
}

export default function StepProgress({ steps, activeIndex }: Props) {
  return (
    <div className="mb-5 flex items-center gap-2 text-[11.5px] font-medium">
      {steps.map((label, i) => (
        <div key={label} className="flex items-center gap-2">
          <span className={i === activeIndex ? 'text-brand-600 dark:text-brand-400' : 'text-zinc-400 dark:text-zinc-500'}>
            {i + 1}. {label}
          </span>
          {i < steps.length - 1 && <span className="text-zinc-300 dark:text-zinc-700">›</span>}
        </div>
      ))}
    </div>
  );
}
