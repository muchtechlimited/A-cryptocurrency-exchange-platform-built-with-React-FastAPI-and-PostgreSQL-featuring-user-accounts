import { ChevronDown } from 'lucide-react';
import { useState } from 'react';
import { coins as allCoins } from '../../data/cryptoMock';
import type { Coin } from '../../data/cryptoMock';

interface Props {
  selectedId: string;
  onSelect: (coin: Coin) => void;
  /** Restrict the dropdown to a subset (e.g. only currencies the backend actually supports for this flow). Defaults to the full mock list. */
  coins?: Coin[];
}

export default function CoinSelect({ selectedId, onSelect, coins = allCoins }: Props) {
  const [open, setOpen] = useState(false);
  const selected = coins.find((c) => c.id === selectedId) ?? coins[0];

  return (
    <div className="relative mb-4">
      <label className="mb-1.5 block text-[13px] font-medium text-zinc-700 dark:text-zinc-300">
        Select Crypto
      </label>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex h-[46px] w-full items-center justify-between rounded-lg border border-zinc-200 bg-zinc-50 px-3.5 text-[13.5px] text-zinc-900 dark:border-white/10 dark:bg-white/[0.04] dark:text-white"
      >
        <span className="flex items-center gap-2.5">
          <span
            className="flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-bold text-white"
            style={{ backgroundColor: selected.color }}
          >
            {selected.letter}
          </span>
          {selected.name} ({selected.symbol})
        </span>
        <ChevronDown size={16} className="text-zinc-400" />
      </button>

      {open && (
        <div className="absolute z-10 mt-1.5 w-full overflow-hidden rounded-lg border border-zinc-200 bg-white shadow-lg dark:border-white/10 dark:bg-[#101113]">
          {coins.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => {
                onSelect(c);
                setOpen(false);
              }}
              className="flex w-full items-center gap-2.5 px-3.5 py-2.5 text-left text-[13px] text-zinc-700 hover:bg-zinc-50 dark:text-zinc-200 dark:hover:bg-white/[0.06]"
            >
              <span
                className="flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-bold text-white"
                style={{ backgroundColor: c.color }}
              >
                {c.letter}
              </span>
              {c.name} ({c.symbol})
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
