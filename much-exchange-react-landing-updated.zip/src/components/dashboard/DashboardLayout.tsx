import { useState, type ReactNode } from 'react';
import { useLocation } from 'react-router-dom';
import DashboardSidebar from './DashboardSidebar';
import DashboardTopbar from './DashboardTopbar';
import MobileBottomNav from './MobileBottomNav';
import TradeSheet from './TradeSheet';
import MoreDrawer from './MoreDrawer';
import { DashboardChromeContext } from './DashboardChromeContext';
import { useAuth } from '../../context/AuthContext';

interface DashboardLayoutProps {
  title: string;
  subtitle?: string;
  children: ReactNode;
}

export default function DashboardLayout({ title, subtitle, children }: DashboardLayoutProps) {
  const [tradeOpen, setTradeOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const { user } = useAuth();
  useLocation(); // ensures the layout re-renders on route change (drawers auto-close via NavLink clicks)

  return (
    <DashboardChromeContext.Provider
      value={{ openTrade: () => setTradeOpen(true), openMore: () => setMoreOpen(true) }}
    >
      <div className="flex h-screen bg-zinc-50 dark:bg-[#08090B]">
        <DashboardSidebar />
        <div className="flex min-w-0 flex-1 flex-col">
          <DashboardTopbar title={title} subtitle={subtitle} userName={user?.full_name} avatarUrl={user?.avatar_url} />
          <main className="flex-1 overflow-y-auto px-5 py-6 pb-28 sm:px-8 md:pb-6">{children}</main>
        </div>

        <MobileBottomNav onTradeClick={() => setTradeOpen(true)} />
        <TradeSheet open={tradeOpen} onClose={() => setTradeOpen(false)} />
        <MoreDrawer open={moreOpen} onClose={() => setMoreOpen(false)} />
      </div>
    </DashboardChromeContext.Provider>
  );
}
