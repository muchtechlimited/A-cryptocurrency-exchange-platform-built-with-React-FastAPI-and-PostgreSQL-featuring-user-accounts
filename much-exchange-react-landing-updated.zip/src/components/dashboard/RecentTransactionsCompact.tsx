import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowDownCircle, ArrowUpCircle, Download, Upload, Repeat, Loader2 } from 'lucide-react';
import Card from '../ui/Card';
import { getMyTransactions, toUiTransaction } from '../../lib/walletApi';
import type { Transaction, TxStatus } from '../../data/activityMock';

function iconFor(type: string) {
  if (type.startsWith('Buy')) return { Icon: ArrowDownCircle, cls: 'bg-up-500/10 text-up-500' };
  if (type.startsWith('Sell')) return { Icon: ArrowUpCircle, cls: 'bg-blue-500/10 text-blue-500' };
  if (type.startsWith('Deposit')) return { Icon: Download, cls: 'bg-cyan-500/10 text-cyan-500' };
  if (type.startsWith('Withdraw')) return { Icon: Upload, cls: 'bg-violet-500/10 text-violet-500' };
  return { Icon: Repeat, cls: 'bg-zinc-200/60 text-zinc-500 dark:bg-white/10 dark:text-zinc-300' };
}

function statusClasses(status: TxStatus) {
  if (status === 'Completed') return 'text-up-500';
  if (status === 'Pending') return 'text-pending-500';
  return 'text-down-500';
}

export default function RecentTransactionsCompact() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    getMyTransactions()
      .then((txs) => setTransactions(txs.map(toUiTransaction)))
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }, []);

  return (
    <Card className="!p-0">
      <div className="flex items-center justify-between border-b border-zinc-200 px-5 py-4 dark:border-white/[0.08]">
        <h3 className="text-[14px] font-semibold text-zinc-900 dark:text-white">Recent Transactions</h3>
        <Link to="/transactions" className="text-[12px] font-semibold text-brand-600 dark:text-brand-400">
          See All
        </Link>
      </div>

      <div className="px-2 py-2">
        {loading ? (
          <div className="flex items-center justify-center gap-2 py-8 text-[12.5px] text-zinc-400 dark:text-zinc-500">
            <Loader2 size={14} className="animate-spin" /> Loading…
          </div>
        ) : error ? (
          <p className="px-3 py-6 text-center text-[12.5px] text-zinc-400 dark:text-zinc-500">
            Couldn't load recent transactions.
          </p>
        ) : transactions.length === 0 ? (
          <p className="px-3 py-6 text-center text-[12.5px] text-zinc-400 dark:text-zinc-500">
            No transactions yet.
          </p>
        ) : (
          transactions.slice(0, 5).map((t) => {
            const { Icon, cls } = iconFor(t.type);
            return (
              <div
                key={t.id}
                className="flex items-center justify-between rounded-lg px-3 py-2.5 transition-colors hover:bg-zinc-50 dark:hover:bg-white/[0.03]"
              >
                <div className="flex items-center gap-2.5">
                  <span className={`flex h-8 w-8 items-center justify-center rounded-full ${cls}`}>
                    <Icon size={15} />
                  </span>
                  <p className="text-[13px] font-medium text-zinc-800 dark:text-zinc-100">{t.type}</p>
                </div>
                <div className="text-right">
                  <p className="font-mono text-[12.5px] text-zinc-700 dark:text-zinc-300">{t.amount}</p>
                  <p className={`text-[11px] font-semibold ${statusClasses(t.status)}`}>{t.status}</p>
                </div>
              </div>
            );
          })
        )}
      </div>
    </Card>
  );
}

