import { Link } from 'react-router-dom';
import Button from '../ui/Button';
import type { WalletRowData } from '../../data/walletsMock';

export default function WalletRow({ wallet }: { wallet: WalletRowData }) {
  return (
    <div className="flex flex-col gap-3 border-b border-zinc-200 py-4 last:border-0 dark:border-white/[0.08] sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-center gap-3">
        <span
          className="flex h-10 w-10 items-center justify-center rounded-full text-[13px] font-bold text-white"
          style={{ backgroundColor: wallet.color }}
        >
          {wallet.letter}
        </span>
        <div>
          <p className="text-[13.5px] font-semibold text-zinc-900 dark:text-white">{wallet.name}</p>
          <p className="text-[12px] text-zinc-500 dark:text-zinc-400">{wallet.balance}</p>
          {wallet.fiatEquivalent && (
            <p className="text-[11px] text-zinc-400 dark:text-zinc-500">{wallet.fiatEquivalent}</p>
          )}
        </div>
      </div>

      <div className="flex gap-2">
        <Link to="/deposit">
          <Button variant="secondary" size="sm">Deposit</Button>
        </Link>
        <Link to="/withdraw">
          <Button variant="secondary" size="sm">Withdraw</Button>
        </Link>
      </div>
    </div>
  );
}
