interface LogoProps {
  withWordmark?: boolean;
  size?: number;
  className?: string;
}

/** Standalone angular gold "M" glyph — no circle backing, matches reference exactly. */
export default function Logo({ withWordmark = true, size = 34, className = '' }: LogoProps) {
  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <svg width={size} height={size * 0.87} viewBox="0 0 46 40" fill="none" xmlns="http://www.w3.org/2000/svg">
        <polyline
          points="7,33 7,8 23,25 39,8 39,33"
          stroke="url(#much-m-gradient)"
          strokeWidth="6.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />
        <defs>
          <linearGradient id="much-m-gradient" x1="7" y1="8" x2="39" y2="33" gradientUnits="userSpaceOnUse">
            <stop offset="0" stopColor="#FCE08A" />
            <stop offset="0.5" stopColor="#F5B516" />
            <stop offset="1" stopColor="#B37E08" />
          </linearGradient>
        </defs>
      </svg>
      {withWordmark && (
        <span className="leading-none">
          <span className="block font-display font-extrabold tracking-tight text-[17px] text-zinc-900 dark:text-white">
            MUCH
          </span>
          <span className="block font-display text-[8.5px] font-semibold tracking-[0.28em] text-zinc-500 dark:text-zinc-400">
            EXCHANGE
          </span>
        </span>
      )}
    </div>
  );
}
