import { useState, type InputHTMLAttributes, type ReactNode } from 'react';
import { Eye, EyeOff } from 'lucide-react';

interface FieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  hint?: string;
  error?: string;
  rightSlot?: ReactNode;
}

export default function Field({ label, hint, error, rightSlot, id, type, className = '', ...rest }: FieldProps) {
  const [show, setShow] = useState(false);
  const isPassword = type === 'password';
  const inputType = isPassword ? (show ? 'text' : 'password') : type;

  return (
    <div className="mb-4">
      {label && (
        <label htmlFor={id} className="mb-1.5 block text-[13px] font-medium text-zinc-700 dark:text-zinc-300">
          {label}
        </label>
      )}
      <div
        className={`flex items-center rounded-lg border bg-zinc-50 transition-colors focus-within:border-brand-500 dark:bg-white/[0.04] ${
          error ? 'border-down-500/60' : 'border-zinc-200 dark:border-white/10'
        }`}
      >
        <input
          id={id}
          type={inputType}
          className={`h-[42px] w-full flex-1 bg-transparent px-3.5 text-[13.5px] text-zinc-900 outline-none placeholder:text-zinc-400 dark:text-white dark:placeholder:text-zinc-500 ${className}`}
          {...rest}
        />
        {isPassword && (
          <button
            type="button"
            onClick={() => setShow((s) => !s)}
            aria-label={show ? 'Hide password' : 'Show password'}
            className="flex items-center px-3 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200"
          >
            {show ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
        )}
        {rightSlot}
      </div>
      {error ? (
        <p className="mt-1.5 text-[11.5px] text-down-500">{error}</p>
      ) : hint ? (
        <p className="mt-1.5 text-[11.5px] text-zinc-400 dark:text-zinc-500">{hint}</p>
      ) : null}
    </div>
  );
}
