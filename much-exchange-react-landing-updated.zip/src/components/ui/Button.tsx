import type { ButtonHTMLAttributes, ReactNode } from 'react';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';
type Size = 'md' | 'lg' | 'sm';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  children: ReactNode;
  fullWidth?: boolean;
}

const variantClasses: Record<Variant, string> = {
  primary:
    'bg-gradient-to-b from-brand-400 to-brand-500 text-zinc-900 font-semibold shadow-[0_1px_0_0_rgba(255,255,255,.35)_inset,0_8px_20px_-8px_rgba(245,181,22,.55)] hover:from-brand-300 hover:to-brand-400 active:translate-y-px',
  secondary:
    'bg-zinc-100 text-zinc-900 hover:bg-zinc-200 dark:bg-white/[0.06] dark:text-white dark:hover:bg-white/[0.1] border border-zinc-200 dark:border-white/10',
  ghost:
    'bg-transparent text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:text-white dark:hover:bg-white/[0.06]',
  danger:
    'bg-down-500/10 text-down-500 border border-down-500/25 hover:bg-down-500/15',
};

const sizeClasses: Record<Size, string> = {
  sm: 'h-8 px-3 text-[12.5px] rounded-lg',
  md: 'h-11 px-5 text-[13.5px] rounded-xl',
  lg: 'h-12 px-6 text-[14.5px] rounded-xl',
};

export default function Button({
  variant = 'primary',
  size = 'md',
  fullWidth,
  className = '',
  children,
  ...rest
}: ButtonProps) {
  return (
    <button
      className={`inline-flex items-center justify-center gap-2 font-medium transition-all disabled:opacity-50 disabled:pointer-events-none whitespace-nowrap ${variantClasses[variant]} ${sizeClasses[size]} ${fullWidth ? 'w-full' : ''} ${className}`}
      {...rest}
    >
      {children}
    </button>
  );
}
