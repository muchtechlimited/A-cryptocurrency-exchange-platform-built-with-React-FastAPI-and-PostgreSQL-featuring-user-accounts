import { Link } from 'react-router-dom';
import { Menu } from 'lucide-react';
import { useState } from 'react';
import Logo from './Logo';
import ThemeToggle from './ThemeToggle';
import Button from './ui/Button';

const links = [
  { label: 'Home', href: '#' },
  { label: 'Features', href: '#features' },
  { label: 'Markets', href: '#markets' },
  { label: 'Fees', href: '#fees' },
  { label: 'About', href: '#about' },
  { label: 'Contact', href: '#contact' },
];

export default function PublicNavbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-30 border-b border-zinc-200 bg-white/80 backdrop-blur-lg dark:border-white/10 dark:bg-[#08090B]/80">
      <div className="mx-auto flex h-[68px] max-w-7xl items-center justify-between px-5 sm:px-8">
        <Logo />

        <nav className="hidden items-center gap-8 lg:flex">
          {links.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className="text-[13.5px] font-medium text-zinc-600 transition-colors hover:text-zinc-900 dark:text-zinc-300 dark:hover:text-white"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <ThemeToggle className="hidden sm:inline-flex" />
          <Link to="/login" className="hidden sm:block">
            <Button variant="secondary" size="sm">
              Log In
            </Button>
          </Link>
          <Link to="/signup" className="hidden sm:block">
            <Button size="sm">Sign Up</Button>
          </Link>
          <button
            onClick={() => setOpen((o) => !o)}
            className="rounded-lg border border-zinc-200 p-2 text-zinc-600 dark:border-white/10 dark:text-zinc-300 lg:hidden"
            aria-label="Toggle menu"
          >
            <Menu size={18} />
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-zinc-200 bg-white px-5 py-4 dark:border-white/10 dark:bg-[#08090B] lg:hidden">
          <nav className="flex flex-col gap-3">
            {links.map((l) => (
              <a key={l.label} href={l.href} className="text-[14px] font-medium text-zinc-700 dark:text-zinc-300">
                {l.label}
              </a>
            ))}
            <div className="mt-2 flex gap-3">
              <Link to="/login" className="flex-1">
                <Button variant="secondary" fullWidth size="sm">Log In</Button>
              </Link>
              <Link to="/signup" className="flex-1">
                <Button fullWidth size="sm">Sign Up</Button>
              </Link>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
