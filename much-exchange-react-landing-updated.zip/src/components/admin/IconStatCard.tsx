import type { LucideIcon } from 'lucide-react';
import Card from '../ui/Card';

interface IconStatCardProps {
  icon: LucideIcon;
  iconBg: string;
  iconColor: string;
  value: string;
  label: string;
  hint: string;
}

export default function IconStatCard({ icon: Icon, iconBg, iconColor, value, label, hint }: IconStatCardProps) {
  return (
    <Card className="flex items-center gap-3 p-3.5 sm:gap-3.5 sm:p-5">
      <div
        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl sm:h-11 sm:w-11"
        style={{ backgroundColor: iconBg }}
      >
        <Icon size={18} className="sm:hidden" style={{ color: iconColor }} />
        <Icon size={20} className="hidden sm:block" style={{ color: iconColor }} />
      </div>
      <div className="min-w-0">
        <p className="truncate font-display text-[16px] font-bold leading-tight text-zinc-900 dark:text-white sm:text-[19px] lg:text-[21px]">
          {value}
        </p>
        <p className="truncate text-[12px] font-semibold text-zinc-700 dark:text-zinc-200 sm:text-[12.5px]">{label}</p>
        <p className="truncate text-[10.5px] text-zinc-400 dark:text-zinc-500 sm:text-[11px]">{hint}</p>
      </div>
    </Card>
  );
}
