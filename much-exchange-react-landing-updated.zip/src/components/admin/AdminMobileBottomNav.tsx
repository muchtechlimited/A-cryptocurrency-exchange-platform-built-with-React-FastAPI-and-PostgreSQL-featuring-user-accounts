import { NavLink } from 'react-router-dom';
import { Menu } from 'lucide-react';
import { adminMobileTabNav } from './adminNav';
import type { AdminNavItem } from './adminNav';
import { useAdminChrome } from './AdminChromeContext';

interface Props {
  onMoreClick: () => void;
}

function TabButton({ item, liveBadge }: { item: AdminNavItem; liveBadge?: number }) {
  const Icon = item.icon;
  const badge = liveBadge ?? item.badge;
  return (
    <NavLink
      to={item.href}
      end={item.href === '/admin'}
      className={({ isActive }) =>
        `relative flex flex-1 flex-col items-center justify-center gap-1 py-1.5 text-[10.5px] font-medium transition-colors ${
          isActive ? 'text-brand-600 dark:text-brand-400' : 'text-zinc-500 dark:text-zinc-400'
        }`
      }
    >
      {({ isActive }) => (
        <>
          <span className="relative">
            <Icon size={20} strokeWidth={isActive ? 2.4 : 2} />
            {!!badge && (
              <span className="absolute -right-1.5 -top-1.5 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-down-500 text-[8.5px] font-bold text-white">
                {badge}
              </span>
            )}
          </span>
          <span>{item.label}</span>
        </>
      )}
    </NavLink>
  );
}

export default function AdminMobileBottomNav({ onMoreClick }: Props) {
  const { pendingCounts: { kyc } } = useAdminChrome();

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-40 border-t border-zinc-200 bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-lg dark:border-white/[0.08] dark:bg-[#0B0C0E]/95 md:hidden"
      aria-label="Primary admin navigation"
    >
      <div className="mx-auto flex h-[64px] max-w-lg items-stretch px-1">
        {adminMobileTabNav.map((item) => (
          <TabButton key={item.href} item={item} liveBadge={item.href === '/admin/kyc' ? kyc : undefined} />
        ))}

        <button
          type="button"
          onClick={onMoreClick}
          className="flex flex-1 flex-col items-center justify-center gap-1 py-1.5 text-[10.5px] font-medium text-zinc-500 dark:text-zinc-400"
        >
          <Menu size={20} strokeWidth={2} />
          <span>More</span>
        </button>
      </div>
    </nav>
  );
}
