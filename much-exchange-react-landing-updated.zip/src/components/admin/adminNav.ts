import type { LucideIcon } from 'lucide-react';
import {
  LayoutDashboard,
  Users,
  Repeat,
  ShieldCheck,
  CreditCard,
  Percent,
  Settings,
  ArrowLeftRight,
  LogOut,
  HelpCircle,
  History,
} from 'lucide-react';

export interface AdminNavItem {
  label: string;
  href: string;
  icon: LucideIcon;
  badge?: number;
}

export const adminPrimaryNav: AdminNavItem[] = [
  { label: 'Overview', href: '/admin', icon: LayoutDashboard },
  { label: 'Users', href: '/admin/users', icon: Users },
  { label: 'Transactions', href: '/admin/transactions', icon: Repeat },
  { label: 'KYC Requests', href: '/admin/kyc', icon: ShieldCheck },
  { label: 'Gift Cards', href: '/admin/gift-cards', icon: CreditCard },
  { label: 'Support', href: '/admin/support', icon: HelpCircle },
  { label: 'Rates', href: '/admin/rates', icon: Percent },
];

export const adminSecondaryNav: AdminNavItem[] = [
  { label: 'Audit Log', href: '/admin/audit-log', icon: History },
  { label: 'Settings', href: '/admin/settings', icon: Settings },
];

export const backToAppNav: AdminNavItem = { label: 'Back to App', href: '/dashboard', icon: ArrowLeftRight };
export const adminLogoutNav: AdminNavItem = { label: 'Logout', href: '/logout', icon: LogOut };

/** Tabs that sit directly in the admin bottom bar — no raised center action, admin has no single default task. */
export const adminMobileTabNav: AdminNavItem[] = [
  { label: 'Overview', href: '/admin', icon: LayoutDashboard },
  { label: 'Users', href: '/admin/users', icon: Users },
  { label: 'Txns', href: '/admin/transactions', icon: Repeat },
  { label: 'KYC', href: '/admin/kyc', icon: ShieldCheck },
];

/** Everything else, surfaced in the "More" slide-in drawer on mobile. */
export const adminMoreNav: AdminNavItem[] = [
  { label: 'Gift Cards', href: '/admin/gift-cards', icon: CreditCard },
  { label: 'Support', href: '/admin/support', icon: HelpCircle },
  { label: 'Rates', href: '/admin/rates', icon: Percent },
  { label: 'Audit Log', href: '/admin/audit-log', icon: History },
  { label: 'Settings', href: '/admin/settings', icon: Settings },
];
