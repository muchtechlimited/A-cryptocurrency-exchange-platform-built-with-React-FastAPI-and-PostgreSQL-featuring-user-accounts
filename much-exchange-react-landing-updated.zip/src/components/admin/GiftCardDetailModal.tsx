import { useState } from 'react';
import { X, Eye, EyeOff, Copy, Check, User, Phone, Mail, Wallet, Landmark, Loader2 } from 'lucide-react';
import Button from '../ui/Button';
import StatusPill from './StatusPill';
import type { ReviewStatus } from '../../data/adminMock';
import type { UiGiftCardSubmission } from '../../lib/giftCardsApi';
import { revealRedemptionCode } from '../../lib/giftCardsApi';
import { ApiError } from '../../lib/api';

interface Props {
  submission: UiGiftCardSubmission | null;
  onClose: () => void;
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
}

/** Card visual + redemption code, revealed on demand from the backend (audit-logged server-side). */
function UploadedCardPhoto({ submission }: { submission: UiGiftCardSubmission }) {
  const [revealed, setRevealed] = useState(false);
  const [copied, setCopied] = useState(false);
  const [revealedCode, setRevealedCode] = useState<string | null>(null);
  const [revealing, setRevealing] = useState(false);
  const [revealError, setRevealError] = useState('');

  async function handleToggleReveal() {
    if (revealed) {
      setRevealed(false);
      return;
    }
    if (revealedCode) {
      setRevealed(true);
      return;
    }
    setRevealing(true);
    setRevealError('');
    try {
      const { redemption_code } = await revealRedemptionCode(submission.id);
      setRevealedCode(redemption_code);
      setRevealed(true);
    } catch (err) {
      setRevealError(err instanceof ApiError ? err.message : 'Could not reveal code.');
    } finally {
      setRevealing(false);
    }
  }

  function handleCopy() {
    if (!revealedCode) return;
    navigator.clipboard?.writeText(revealedCode).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  return (
    <div>
      <div
        className="relative flex aspect-[16/10] w-full flex-col justify-between overflow-hidden rounded-2xl p-5 text-white shadow-inner"
        style={{
          background: `linear-gradient(135deg, ${submission.brandColor} 0%, rgba(0,0,0,0.55) 145%)`,
        }}
      >
        <div className="flex items-start justify-between">
          <span className="text-[15px] font-bold tracking-wide">{submission.brand}</span>
          <span className="rounded-md bg-white/15 px-2 py-0.5 text-[11px] font-semibold backdrop-blur-sm">
            GIFT CARD
          </span>
        </div>
        <div>
          <p className="text-[11px] font-medium uppercase tracking-wide text-white/70">Card Value</p>
          <p className="font-display text-[24px] font-bold">{submission.value}</p>
        </div>
      </div>

      {!submission.hasCardImage && (
        <p className="mt-2 text-[11px] text-zinc-400 dark:text-zinc-500">No card photo was uploaded with this submission.</p>
      )}

      <div className="mt-3 flex items-center justify-between rounded-xl border border-zinc-200 bg-zinc-50 px-3.5 py-2.5 dark:border-white/10 dark:bg-white/[0.04]">
        <div className="min-w-0">
          <p className="text-[10.5px] font-medium uppercase tracking-wide text-zinc-400 dark:text-zinc-500">
            Redemption Code
          </p>
          <p className="mt-0.5 truncate font-mono text-[13px] font-semibold text-zinc-800 dark:text-zinc-100">
            {revealed && revealedCode ? revealedCode : submission.cardCode}
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-1.5">
          <button
            onClick={handleToggleReveal}
            disabled={revealing}
            aria-label={revealed ? 'Hide code' : 'Reveal code'}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-zinc-500 hover:bg-zinc-200 disabled:opacity-40 dark:text-zinc-400 dark:hover:bg-white/10"
          >
            {revealing ? <Loader2 size={15} className="animate-spin" /> : revealed ? <EyeOff size={15} /> : <Eye size={15} />}
          </button>
          <button
            onClick={handleCopy}
            disabled={!revealed}
            aria-label="Copy code"
            className="flex h-8 w-8 items-center justify-center rounded-lg text-zinc-500 hover:bg-zinc-200 disabled:opacity-40 dark:text-zinc-400 dark:hover:bg-white/10"
          >
            {copied ? <Check size={15} className="text-up-500" /> : <Copy size={15} />}
          </button>
        </div>
      </div>
      {revealError && <p className="mt-1.5 text-[11.5px] text-down-500">{revealError}</p>}
      <p className="mt-2 text-[11px] text-zinc-400 dark:text-zinc-500">
        Revealing the code is logged against your admin account for accountability.
      </p>
    </div>
  );
}

export default function GiftCardDetailModal({ submission, onClose, onApprove, onReject }: Props) {
  if (!submission) return null;
  const s = submission;

  function act(status: ReviewStatus) {
    if (status === 'Approved') onApprove(s.id);
    else onReject(s.id);
    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-[2px]" onClick={onClose} />

      <div className="relative flex max-h-[92vh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-white shadow-2xl dark:bg-[#101113] sm:rounded-2xl">
        <div className="flex items-center justify-between border-b border-zinc-200 px-5 py-4 dark:border-white/[0.08]">
          <div>
            <h3 className="text-[15px] font-semibold text-zinc-900 dark:text-white">Submission Details</h3>
            <p className="text-[11.5px] text-zinc-400 dark:text-zinc-500">Submitted {s.submitted}</p>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="flex h-8 w-8 items-center justify-center rounded-lg text-zinc-500 hover:bg-zinc-100 dark:text-zinc-400 dark:hover:bg-white/[0.06]"
          >
            <X size={18} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-5">
          <UploadedCardPhoto submission={s} />

          <div className="mt-5 space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-[12.5px] font-semibold text-zinc-800 dark:text-zinc-100">Seller</p>
              <StatusPill status={s.status} />
            </div>
            <div className="space-y-2 rounded-xl border border-zinc-200 px-3.5 py-3 dark:border-white/10">
              <div className="flex items-center gap-2.5 text-[12.5px] text-zinc-600 dark:text-zinc-300">
                <User size={14} className="shrink-0 text-zinc-400" /> {s.userName}
              </div>
              <div className="flex items-center gap-2.5 text-[12.5px] text-zinc-600 dark:text-zinc-300">
                <Mail size={14} className="shrink-0 text-zinc-400" /> {s.email}
              </div>
              <div className="flex items-center gap-2.5 text-[12.5px] text-zinc-600 dark:text-zinc-300">
                <Phone size={14} className="shrink-0 text-zinc-400" /> {s.phone}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-xl border border-zinc-200 px-3.5 py-3 dark:border-white/10">
                <p className="text-[11px] font-medium uppercase tracking-wide text-zinc-400 dark:text-zinc-500">
                  Offered Rate
                </p>
                <p className="mt-1 text-[13px] font-semibold text-zinc-800 dark:text-zinc-100">{s.offeredRate}</p>
              </div>
              <div className="rounded-xl border border-brand-500/30 bg-brand-500/5 px-3.5 py-3">
                <p className="text-[11px] font-medium uppercase tracking-wide text-brand-600 dark:text-brand-400">
                  Seller Gets
                </p>
                <p className="mt-1 text-[13px] font-bold text-zinc-900 dark:text-white">{s.payoutNaira}</p>
              </div>
            </div>

            {(s.vendor || s.verificationResult) && (
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-xl border border-zinc-200 px-3.5 py-3 dark:border-white/10">
                  <p className="text-[11px] font-medium uppercase tracking-wide text-zinc-400 dark:text-zinc-500">
                    Vendor
                  </p>
                  <p className="mt-1 text-[13px] font-semibold text-zinc-800 dark:text-zinc-100">{s.vendor || 'Not verified yet'}</p>
                </div>
                <div className="rounded-xl border border-zinc-200 px-3.5 py-3 dark:border-white/10">
                  <p className="text-[11px] font-medium uppercase tracking-wide text-zinc-400 dark:text-zinc-500">
                    Verification
                  </p>
                  <p className="mt-1 text-[13px] font-semibold capitalize text-zinc-800 dark:text-zinc-100">
                    {s.verificationResult?.replace(/_/g, ' ') || 'pending'}
                  </p>
                </div>
              </div>
            )}

            {s.rejectionReason && (
              <div className="rounded-xl border border-down-500/30 bg-down-500/5 px-3.5 py-3">
                <p className="text-[11px] font-medium uppercase tracking-wide text-down-500">Rejection Reason</p>
                <p className="mt-1 text-[12.5px] text-zinc-700 dark:text-zinc-200">{s.rejectionReason}</p>
              </div>
            )}

            <div className="flex items-center gap-2.5 rounded-xl border border-zinc-200 px-3.5 py-3 text-[12.5px] text-zinc-600 dark:border-white/10 dark:text-zinc-300">
              {s.paymentMethod === 'Bank Transfer' ? (
                <Landmark size={14} className="shrink-0 text-zinc-400" />
              ) : (
                <Wallet size={14} className="shrink-0 text-zinc-400" />
              )}
              Payout via <span className="font-semibold text-zinc-800 dark:text-zinc-100">{s.paymentMethod}</span>
            </div>
          </div>
        </div>

        {s.status === 'Pending' && (
          <div className="flex gap-2.5 border-t border-zinc-200 px-5 py-4 dark:border-white/[0.08]">
            <Button variant="danger" fullWidth onClick={() => act('Rejected')}>
              Reject
            </Button>
            <Button variant="primary" fullWidth onClick={() => act('Approved')}>
              Approve &amp; Pay Out
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
