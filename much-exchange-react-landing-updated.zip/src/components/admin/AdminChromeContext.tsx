import { createContext, useContext, useState, type ReactNode } from 'react';
import { useAdminPendingCounts } from '../../lib/useAdminPendingCounts';

interface PendingCounts {
  kyc: number;
  giftCards: number;
  tickets: number;
}

interface AdminChromeValue {
  openMore: () => void;
  closeMore: () => void;
  moreOpen: boolean;
  pendingCounts: PendingCounts;
  refreshPendingCounts: () => void;
}

export const AdminChromeContext = createContext<AdminChromeValue | undefined>(undefined);

/**
 * Wraps a single admin page (see App.tsx's admin routes). Deliberately sits
 * OUTSIDE the page component, not inside AdminLayout, so that a page's own
 * hook calls — e.g. `const { refreshPendingCounts } = useAdminChrome()` at
 * the top of AdminKyc/AdminGiftCards/AdminSupport — actually resolve against
 * a real Provider ancestor instead of the no-op fallback below.
 *
 * (AdminLayout used to own this Provider itself. That looked right — the
 * sidebar/topbar/drawer it renders are genuine descendants and always
 * worked — but a page component that renders `<AdminLayout>{...}</AdminLayout>`
 * is AdminLayout's *parent* in the tree, so a hook call made in the page's
 * own function body, before that JSX is returned, sits outside any Provider
 * AdminLayout goes on to create. Confirmed live: clicking "Approve" or
 * "Send Reply" never fired the refetch network calls at all — the count
 * only ever updated on a full page reload.)
 */
export function AdminChromeProvider({ children }: { children: ReactNode }) {
  const [moreOpen, setMoreOpen] = useState(false);
  const { kyc, giftCards, tickets, refresh } = useAdminPendingCounts();

  return (
    <AdminChromeContext.Provider
      value={{
        openMore: () => setMoreOpen(true),
        closeMore: () => setMoreOpen(false),
        moreOpen,
        pendingCounts: { kyc, giftCards, tickets },
        refreshPendingCounts: refresh,
      }}
    >
      {children}
    </AdminChromeContext.Provider>
  );
}

export function useAdminChrome() {
  const ctx = useContext(AdminChromeContext);
  if (!ctx) {
    // Safe no-op fallback so components can be used outside the provider (e.g. in isolation/tests).
    return {
      openMore: () => {},
      closeMore: () => {},
      moreOpen: false,
      pendingCounts: { kyc: 0, giftCards: 0, tickets: 0 },
      refreshPendingCounts: () => {},
    };
  }
  return ctx;
}
