import { Circle } from 'lucide-react';
import Card from '../ui/Card';
import type { LedgerTransactionApi } from '../../lib/adminApi';

const TYPE_LABEL: Record<string, string> = {
  deposit: 'Deposit',
  withdrawal: 'Withdrawal',
  buy_btc: 'BTC purchase',
  sell_btc: 'BTC sale',
  buy_usdt: 'USDT purchase',
  sell_usdt: 'USDT sale',
  gift_card_sell: 'Gift card sale',
  buy_gift_card: 'Gift card purchase',
  admin_credit: 'Admin credit',
  admin_debit: 'Admin debit',
};

function formatTime(iso: string) {
  try {
    return new Date(iso).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  } catch {
    return iso;
  }
}

export default function RecentActivityFeed({ transactions }: { transactions: LedgerTransactionApi[] }) {
  const recent = [...transactions]
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .slice(0, 10);

  return (
    <Card className="!p-0">
      <div className="border-b border-zinc-200 px-5 py-4 dark:border-white/[0.08]">
        <h3 className="text-[14px] font-semibold text-zinc-900 dark:text-white">Recent Activity</h3>
      </div>
      <div className="divide-y divide-zinc-100 dark:divide-white/[0.06]">
        {recent.map((tx) => (
          <div key={tx.id} className="flex items-start gap-3 px-5 py-3.5">
            <Circle size={6} className="mt-1.5 shrink-0 fill-brand-500 text-brand-500" />
            <div className="min-w-0">
              <p className="text-[12.5px] leading-snug text-zinc-700 dark:text-zinc-300">
                {TYPE_LABEL[tx.type] ?? tx.type} — {tx.amount} {tx.currency}
                {tx.description ? ` (${tx.description})` : ''}
              </p>
              <p className="mt-0.5 text-[11px] text-zinc-400 dark:text-zinc-500">{formatTime(tx.created_at)}</p>
            </div>
          </div>
        ))}
        {recent.length === 0 && (
          <p className="px-5 py-8 text-center text-[13px] text-zinc-400 dark:text-zinc-500">No activity yet.</p>
        )}
      </div>
    </Card>
  );
}
