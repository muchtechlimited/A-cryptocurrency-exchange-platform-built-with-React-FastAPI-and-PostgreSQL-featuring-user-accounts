import { useEffect, useState } from 'react';
import { X, Loader2, ImageOff, Mail, User, FileText, ZoomIn } from 'lucide-react';
import Button from '../ui/Button';
import StatusPill from './StatusPill';
import { fetchKycDocumentBlobUrl, type KYCSubmissionApi } from '../../lib/adminApi';
import { ApiError } from '../../lib/api';

interface Props {
  submission: KYCSubmissionApi | null;
  onClose: () => void;
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
  actingOnId: string | null;
}

const DOC_LABEL: Record<string, string> = {
  national_id: 'National ID',
  passport: 'Passport',
  drivers_license: "Driver's License",
  voters_card: "Voter's Card",
};

const STATUS_LABEL: Record<string, 'Pending' | 'Approved' | 'Rejected'> = {
  pending: 'Pending',
  approved: 'Approved',
  rejected: 'Rejected',
};

type DocKind = 'front' | 'back' | 'selfie';

interface DocSlot {
  kind: DocKind;
  label: string;
  url: string | null;
  loading: boolean;
  error: string | null;
}

function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  } catch {
    return iso;
  }
}

/** A single document tile: loading state, missing state, or the image (click to lightbox). */
function DocTile({ slot, onExpand }: { slot: DocSlot; onExpand: () => void }) {
  return (
    <div>
      <p className="mb-1.5 text-[11px] font-medium uppercase tracking-wide text-zinc-400 dark:text-zinc-500">
        {slot.label}
      </p>
      <div className="relative flex aspect-[4/3] w-full items-center justify-center overflow-hidden rounded-xl border border-zinc-200 bg-zinc-50 dark:border-white/10 dark:bg-white/[0.04]">
        {slot.loading ? (
          <Loader2 size={20} className="animate-spin text-zinc-400" />
        ) : slot.error ? (
          <div className="flex flex-col items-center gap-1.5 px-3 text-center">
            <ImageOff size={18} className="text-zinc-400" />
            <p className="text-[11px] text-zinc-400 dark:text-zinc-500">{slot.error}</p>
          </div>
        ) : slot.url ? (
          <button
            type="button"
            onClick={onExpand}
            className="group relative h-full w-full"
            aria-label={`Expand ${slot.label}`}
          >
            <img src={slot.url} alt={slot.label} className="h-full w-full object-cover" />
            <span className="absolute inset-0 flex items-center justify-center bg-black/0 opacity-0 transition-opacity group-hover:bg-black/30 group-hover:opacity-100">
              <ZoomIn size={20} className="text-white" />
            </span>
          </button>
        ) : (
          <p className="px-3 text-center text-[11px] text-zinc-400 dark:text-zinc-500">
            Not provided with this submission
          </p>
        )}
      </div>
    </div>
  );
}

export default function KycDocumentModal({ submission, onClose, onApprove, onReject, actingOnId }: Props) {
  const [slots, setSlots] = useState<DocSlot[]>([]);
  const [lightbox, setLightbox] = useState<string | null>(null);

  useEffect(() => {
    if (!submission) {
      setSlots([]);
      return;
    }

    const kinds: { kind: DocKind; label: string; present: boolean }[] = [
      { kind: 'front', label: 'ID — Front', present: true },
      { kind: 'back', label: 'ID — Back', present: submission.has_back_document },
      { kind: 'selfie', label: 'Selfie', present: submission.has_selfie },
    ];

    let cancelled = false;
    const objectUrls: string[] = [];

    setSlots(
      kinds.map((k) => ({
        kind: k.kind,
        label: k.label,
        url: null,
        loading: k.present,
        error: k.present ? null : 'Not provided with this submission',
      })),
    );

    kinds
      .filter((k) => k.present)
      .forEach((k) => {
        fetchKycDocumentBlobUrl(submission.id, k.kind)
          .then((url) => {
            if (cancelled) {
              if (url) URL.revokeObjectURL(url);
              return;
            }
            if (url) objectUrls.push(url);
            setSlots((prev) =>
              prev.map((s) =>
                s.kind === k.kind
                  ? { ...s, loading: false, url, error: url ? null : 'Not provided with this submission' }
                  : s,
              ),
            );
          })
          .catch((err) => {
            if (cancelled) return;
            setSlots((prev) =>
              prev.map((s) =>
                s.kind === k.kind
                  ? {
                      ...s,
                      loading: false,
                      url: null,
                      error: err instanceof ApiError ? err.message : 'Failed to load image.',
                    }
                  : s,
              ),
            );
          });
      });

    return () => {
      cancelled = true;
      objectUrls.forEach((u) => URL.revokeObjectURL(u));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [submission?.id]);

  if (!submission) return null;
  const s = submission;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-[2px]" onClick={onClose} />

      <div className="relative flex max-h-[92vh] w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-white shadow-2xl dark:bg-[#101113] sm:rounded-2xl">
        <div className="flex items-center justify-between border-b border-zinc-200 px-5 py-4 dark:border-white/[0.08]">
          <div>
            <h3 className="text-[15px] font-semibold text-zinc-900 dark:text-white">KYC Submission</h3>
            <p className="text-[11.5px] text-zinc-400 dark:text-zinc-500">Submitted {formatDate(s.created_at)}</p>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="flex h-8 w-8 items-center justify-center rounded-lg text-zinc-500 hover:bg-zinc-100 dark:text-zinc-400 dark:hover:bg-white/[0.06]"
          >
            <X size={18} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-5">
          <div className="mb-5 flex items-center justify-between">
            <p className="text-[12.5px] font-semibold text-zinc-800 dark:text-zinc-100">Applicant</p>
            <StatusPill status={STATUS_LABEL[s.status] ?? 'Pending'} />
          </div>

          <div className="space-y-2 rounded-xl border border-zinc-200 px-3.5 py-3 dark:border-white/10">
            <div className="flex items-center gap-2.5 text-[12.5px] text-zinc-600 dark:text-zinc-300">
              <User size={14} className="shrink-0 text-zinc-400" /> {s.user_full_name || 'Unknown user'}
            </div>
            <div className="flex items-center gap-2.5 text-[12.5px] text-zinc-600 dark:text-zinc-300">
              <Mail size={14} className="shrink-0 text-zinc-400" /> {s.user_email || '—'}
            </div>
            <div className="flex items-center gap-2.5 text-[12.5px] text-zinc-600 dark:text-zinc-300">
              <FileText size={14} className="shrink-0 text-zinc-400" />
              {DOC_LABEL[s.document_type] || s.document_type} · {s.document_number}
            </div>
          </div>

          <div className="mt-5 grid grid-cols-2 gap-3">
            {slots.map((slot) => (
              <DocTile key={slot.kind} slot={slot} onExpand={() => slot.url && setLightbox(slot.url)} />
            ))}
          </div>

          {s.status === 'rejected' && s.rejection_reason && (
            <div className="mt-5 rounded-xl border border-down-500/30 bg-down-500/5 px-3.5 py-3">
              <p className="text-[11px] font-medium uppercase tracking-wide text-down-500">Rejection Reason</p>
              <p className="mt-1 text-[12.5px] text-zinc-700 dark:text-zinc-200">{s.rejection_reason}</p>
            </div>
          )}
        </div>

        {s.status === 'pending' && (
          <div className="flex gap-2.5 border-t border-zinc-200 px-5 py-4 dark:border-white/[0.08]">
            <Button variant="danger" fullWidth disabled={actingOnId === s.id} onClick={() => onReject(s.id)}>
              Reject
            </Button>
            <Button variant="primary" fullWidth disabled={actingOnId === s.id} onClick={() => onApprove(s.id)}>
              Approve
            </Button>
          </div>
        )}
      </div>

      {lightbox && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-black/85 p-4"
          onClick={() => setLightbox(null)}
        >
          <img src={lightbox} alt="Full size document" className="max-h-full max-w-full rounded-lg object-contain" />
          <button
            onClick={() => setLightbox(null)}
            aria-label="Close preview"
            className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-lg bg-white/10 text-white hover:bg-white/20"
          >
            <X size={20} />
          </button>
        </div>
      )}
    </div>
  );
}
