import { AreaChart, Area, XAxis, ResponsiveContainer, Tooltip } from 'recharts';
import Card from '../ui/Card';
import type { DailyActivityPointApi } from '../../lib/adminApi';

export default function PlatformVolumeChart({ data }: { data: DailyActivityPointApi[] }) {
  const chartData = data.map((d) => ({
    label: new Date(d.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    transactions: d.transactions,
    new_users: d.new_users,
  }));

  return (
    <Card className="!p-0">
      <div className="flex items-center justify-between border-b border-zinc-200 px-5 py-4 dark:border-white/[0.08]">
        <h3 className="text-[14px] font-semibold text-zinc-900 dark:text-white">Daily Activity (7D)</h3>
        <span className="text-[11.5px] font-medium text-zinc-400 dark:text-zinc-500">transactions</span>
      </div>

      <div className="h-[200px] px-2 py-4 sm:h-[240px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData} margin={{ top: 8, right: 12, left: 4, bottom: 0 }}>
            <defs>
              <linearGradient id="platformVolumeGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#F5B516" stopOpacity={0.35} />
                <stop offset="100%" stopColor="#F5B516" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis
              dataKey="label"
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 11, fill: '#8A8D93' }}
              interval="preserveStartEnd"
            />
            <Tooltip
              contentStyle={{
                background: '#101113',
                border: '1px solid rgba(255,255,255,0.08)',
                borderRadius: 10,
                fontSize: 12,
              }}
              labelStyle={{ color: '#8A8D93' }}
              itemStyle={{ color: '#F5B516' }}
              formatter={(value: number, name: string) => [value, name === 'transactions' ? 'Transactions' : 'New Users']}
            />
            <Area
              type="monotone"
              dataKey="transactions"
              stroke="#F5B516"
              strokeWidth={2}
              fill="url(#platformVolumeGradient)"
              dot={false}
              activeDot={{ r: 4, fill: '#F5B516', stroke: '#08090B', strokeWidth: 2 }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}
