const styles: Record<string, string> = {
  Completed: 'bg-up-500/10 text-up-500',
  Approved: 'bg-up-500/10 text-up-500',
  Active: 'bg-up-500/10 text-up-500',
  Verified: 'bg-up-500/10 text-up-500',
  Resolved: 'bg-up-500/10 text-up-500',
  Pending: 'bg-pending-500/10 text-pending-500',
  Open: 'bg-brand-500/10 text-brand-600 dark:text-brand-400',
  Failed: 'bg-down-500/10 text-down-500',
  Rejected: 'bg-down-500/10 text-down-500',
  Suspended: 'bg-down-500/10 text-down-500',
  Unverified: 'bg-zinc-400/10 text-zinc-500 dark:text-zinc-400',
};

export default function StatusPill({ status }: { status: string }) {
  return (
    <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10.5px] font-semibold ${styles[status] ?? 'bg-zinc-400/10 text-zinc-500'}`}>
      {status}
    </span>
  );
}
