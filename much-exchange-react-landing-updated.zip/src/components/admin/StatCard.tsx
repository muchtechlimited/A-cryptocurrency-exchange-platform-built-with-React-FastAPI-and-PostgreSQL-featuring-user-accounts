import Card from '../ui/Card';

export default function StatCard({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <Card className="flex flex-col justify-between">
      <p className="text-[12.5px] font-medium text-zinc-500 dark:text-zinc-400">{label}</p>
      <p className="mt-2 font-display text-[19px] font-bold text-zinc-900 dark:text-white sm:text-[21px]">
        {value}
      </p>
      {hint && <p className="mt-2 truncate text-[11.5px] text-zinc-400 dark:text-zinc-500">{hint}</p>}
    </Card>
  );
}
