import { NavLink, useNavigate } from 'react-router-dom';
import Logo from '../Logo';
import { adminPrimaryNav, adminSecondaryNav, backToAppNav, adminLogoutNav } from './adminNav';
import type { AdminNavItem } from './adminNav';
import { useAdminAuth } from '../../context/AdminAuthContext';
import { useAdminChrome } from './AdminChromeContext';

function NavRow({ item, liveBadge }: { item: AdminNavItem; liveBadge?: number }) {
  const Icon = item.icon;
  const badge = liveBadge ?? item.badge;
  return (
    <NavLink
      to={item.href}
      end={item.href === '/admin'}
      className={({ isActive }) =>
        `group relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-[13px] font-medium transition-colors ${
          isActive
            ? 'bg-brand-500/10 text-brand-600 dark:bg-brand-400/10 dark:text-brand-400'
            : 'text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900 dark:text-zinc-400 dark:hover:bg-white/[0.06] dark:hover:text-white'
        }`
      }
    >
      {({ isActive }) => (
        <>
          <span
            className={`absolute left-0 h-5 w-[3px] rounded-r-full transition-opacity ${
              isActive ? 'bg-brand-500 opacity-100' : 'opacity-0'
            }`}
          />
          <Icon size={16} strokeWidth={2} />
          <span className="flex-1">{item.label}</span>
          {!!badge && (
            <span className="flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-down-500/15 px-1 text-[10.5px] font-semibold text-down-500">
              {badge}
            </span>
          )}
        </>
      )}
    </NavLink>
  );
}

function LogoutRow() {
  const { logout } = useAdminAuth();
  const navigate = useNavigate();
  const Icon = adminLogoutNav.icon;

  function handleLogout() {
    logout();
    navigate('/admin/login', { replace: true });
  }

  return (
    <button
      type="button"
      onClick={handleLogout}
      className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-[13px] font-medium text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 dark:text-zinc-400 dark:hover:bg-white/[0.06] dark:hover:text-white"
    >
      <Icon size={16} strokeWidth={2} />
      <span className="flex-1 text-left">{adminLogoutNav.label}</span>
    </button>
  );
}

export default function AdminSidebar() {
  const { pendingCounts: { kyc, giftCards, tickets } } = useAdminChrome();
  const liveBadgeFor = (href: string) => {
    if (href === '/admin/kyc') return kyc;
    if (href === '/admin/gift-cards') return giftCards;
    if (href === '/admin/support') return tickets;
    return undefined;
  };

  return (
    <aside className="hidden h-full w-[248px] shrink-0 flex-col border-r border-zinc-200 bg-white px-3 py-5 dark:border-white/[0.08] dark:bg-[#0B0C0E] md:flex">
      <div className="mb-1 flex items-center justify-between px-2">
        <Logo />
      </div>
      <div className="mb-5 px-2">
        <span className="inline-flex items-center rounded-md bg-zinc-100 px-2 py-0.5 text-[10.5px] font-semibold uppercase tracking-wide text-zinc-500 dark:bg-white/[0.06] dark:text-zinc-400">
          Admin Panel
        </span>
      </div>

      <nav className="relative flex-1 space-y-1 overflow-y-auto">
        {adminPrimaryNav.map((item) => (
          <div key={item.href} className="relative">
            <NavRow item={item} liveBadge={liveBadgeFor(item.href)} />
          </div>
        ))}
      </nav>

      <div className="mt-3 space-y-1 border-t border-zinc-200 pt-3 dark:border-white/[0.08]">
        {adminSecondaryNav.map((item) => (
          <div key={item.href} className="relative">
            <NavRow item={item} />
          </div>
        ))}
        <div className="relative">
          <NavRow item={backToAppNav} />
        </div>
        <div className="relative">
          <LogoutRow />
        </div>
      </div>
    </aside>
  );
}
