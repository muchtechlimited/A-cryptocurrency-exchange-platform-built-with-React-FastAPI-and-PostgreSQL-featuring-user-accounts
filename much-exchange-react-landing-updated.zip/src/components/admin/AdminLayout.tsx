import { type ReactNode } from 'react';
import { useLocation } from 'react-router-dom';
import AdminSidebar from './AdminSidebar';
import AdminTopbar from './AdminTopbar';
import AdminMobileBottomNav from './AdminMobileBottomNav';
import AdminMoreDrawer from './AdminMoreDrawer';
import { useAdminChrome } from './AdminChromeContext';

interface AdminLayoutProps {
  title: string;
  subtitle?: string;
  children: ReactNode;
}

export default function AdminLayout({ title, subtitle, children }: AdminLayoutProps) {
  // moreOpen/pendingCounts now come from AdminChromeProvider, which wraps
  // the page at the route level (see App.tsx) — not from state owned here.
  const { moreOpen, openMore, closeMore } = useAdminChrome();
  useLocation(); // ensures the layout re-renders on route change (drawer auto-closes via NavLink clicks)

  return (
    <div className="flex h-screen bg-zinc-50 dark:bg-[#08090B]">
      <AdminSidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <AdminTopbar title={title} subtitle={subtitle} />
        <main className="flex-1 overflow-y-auto px-5 py-6 pb-24 sm:px-8 md:pb-6">{children}</main>
      </div>

      <AdminMobileBottomNav onMoreClick={openMore} />
      <AdminMoreDrawer open={moreOpen} onClose={closeMore} />
    </div>
  );
}
