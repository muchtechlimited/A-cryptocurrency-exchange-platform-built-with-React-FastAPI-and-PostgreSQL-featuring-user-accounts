# Much Exchange — React + TypeScript rewrite

## Run locally
```
npm install
npm run dev
```
Then open the printed localhost URL. Toggle light/dark with the sun/moon icon top-right.

## What's in this pass
- Landing page (`/`)
- Login (`/login`) — split-screen layout matching your reference
- Sign up (`/signup`) — centered card layout
- Forgot password (`/forgot-password`) — centered card layout
- Full light/dark theme system (persisted, respects OS preference on first visit)
- Shared design tokens (brand gold, up/down colors) sampled from your screenshots
- Reusable Button, Field/Input, Card, Logo, ThemeToggle components

## Not built yet (next passes)
Dashboard, Wallets, Buy/Sell Crypto, Deposit, Withdraw, KYC, Transactions,
Notifications, Profile, Settings, Referral, Admin panel.
